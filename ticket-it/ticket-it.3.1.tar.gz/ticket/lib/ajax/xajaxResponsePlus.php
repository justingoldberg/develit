<?

class xajaxResponsePlus extends xajaxResponse {  
	function addCreateOption( $sSelectId, $sOptionText, $sOptionValue ) {  
		$this->addScript(utf8_encode("addOption('".$sSelectId."', '".$sOptionText."', '".$sOptionValue."');"));
	}
	
	function addCreateOptions($sSelectId, $aOptions) {
		foreach($aOptions as $sOptionValue => $sOptionText){
	    	$this->addCreateOption($sSelectId, $sOptionText, $sOptionValue);
		}
	}
}

?>