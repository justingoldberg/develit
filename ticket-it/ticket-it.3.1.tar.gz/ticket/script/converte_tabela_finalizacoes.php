<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 15/04/2003
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 006
#
# Fun��o:
#    P�gina principal (index) da aplica��o

# Carregar Sessoes para informa��es de usuario
session_start();
session_register("sessLogin", "sessNavegacao");

# Verifica se sess�o deve ser matada
if($modulo=='logoff' && session_is_registered("sessLogin")) {
	session_destroy();
	$sessLogin[login]='';
	$sessLogin[senha]='';
}

# Carregar configura��es
include('config/config.php');
include('config/custom.php');
include('config/db.php');
include('config/html.php');

# Vari�veis globais
global $configHostMySQL, $configUserMySQL, $configPasswdMySQL, $configDBMySQL, $configAppName, $configAppVersion, $corFundo, $corBorda;

# Carregar fun��es
include('includes/db.php');
include('includes/html.php');
include('includes/menu.php');
include('lib/data.php');

# Valida��o de Formul�rios
include('includes/valida_form.php');

# Fun��es de E-mail
include('includes/mail.php');

# Fun��es de Usuario
include('includes/usuarios.php');

# Fun��es de Grupos
include('includes/grupos.php');
include('includes/usuarios_grupos.php');

# Paginador
include('includes/paginador.php');

# Formul�rios
include('includes/form.php');

# Categorias
include('includes/categorias.php');

# Categorias Grupos
include('includes/categorias_grupos.php');

# Configura��es
include('includes/configuracoes.php');

# Prioridades
include('includes/prioridades.php');

# Status
include('includes/status.php');

# Tickets
include('includes/ticket.php');

# Tickets Grupos
include('includes/ticket_grupo.php');

# Processos dos Tickets
include('includes/processos_ticket.php');

# Coment�rios
include('includes/comentarios.php');

# Perfil
include('includes/perfil.php');

# Protocolo
include('includes/protocolo.php');


### CARRETAMENTO DE VALORES PARA SESSION - Valida��o
if($matValida) $sessLogin=usuariosValidaForm($matValida);
### CARRETAMENTO DE VALORES PARA SESSION - Navega��o
if($matriz) $sessNavegacao=alimentaForm($matriz, $sessNavegacao);
### 

###########################################
# Conectar com banco de dados
$conn=conectaMySQL($configHostMySQL, $configUserMySQL, $configPasswdMySQL);
$db=selecionaDB($configDBMySQL);
###########################################


$sql="SELECT idTicket FROM ticket_finalizacoes group by idTicket";
$consulta=consultaSQL($sql,$conn);

for($a=0;$a<contaConsulta($consulta);$a++) {

	$idTicket=resultadoSQL($consulta, $a, 'idTicket');
	
	# Consulta status do ticket
	$sqlTicket="select * from ticket_finalizacoes where idTicket=$idTicket";
	$consultaTicket=consultaSQL($sqlTicket, $conn);

	$dbData='';
	for($b=0;$b<contaConsulta($consultaTicket);$b++) {
		
		$parametro=resultadoSQL($consultaTicket, $b, 'parametro');
		$valor=resultadoSQL($consultaTicket, $b, 'valor');
		
		$dbData[$parametro]=$valor;
	}
	
	if($dbData[expediente] && $dbData[duracao]) {
		echo _("Updating record").":". $idTicket." - ".$dbData[duracao] - $dbData[expediente]."<br>";
		$sql2="INSERT INTO ticket_tempo values (0, $idTicket, '$dbData[duracao]', '$dbData[expediente]')";
		$consulta2=consultaSQL($sql2, $conn);
	}
}

echo _("Updated record").": ".$a." \n";


?>
