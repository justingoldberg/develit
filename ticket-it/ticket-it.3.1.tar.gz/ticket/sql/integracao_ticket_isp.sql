-- Querys com as altera��es nas tabelas Empresas e M�quinas

ALTER TABLE Empresas ADD COLUMN bloqueio char(1) default 'N';
ALTER TABLE Maquinas ADD COLUMN idSuporte INT(11);