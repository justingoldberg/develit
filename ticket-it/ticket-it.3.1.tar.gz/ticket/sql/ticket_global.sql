-- MySQL dump 9.09
--
-- Host: localhost    Database: Ticket_IT
---------------------------------------------------------
-- Server version	4.0.15

--
-- Table structure for table `Empresas`
--

CREATE TABLE Empresas (
  id int(11) NOT NULL auto_increment,
  idPessoaTipo int(11) default NULL,
  nome varchar(200) default NULL,
  dominio varchar(200) default NULL,
  status  char(1) default 'A',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Table structure for table `Parametros`
--

CREATE TABLE Parametros (
  id int(11) NOT NULL auto_increment,
  descricao varchar(200) default NULL,
  parametro varchar(20) default NULL,
  valor text default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Table structure for table `grupos`
--

CREATE TABLE grupos (
  id int(9) NOT NULL auto_increment,
  nome varchar(50) NOT NULL default '',
  admin char(1) default NULL,
  incluir char(1) default NULL,
  excluir char(1) default NULL,
  visualizar char(1) default NULL,
  alterar char(1) default NULL,
  abrir char(1) default NULL,
  fechar char(1) default NULL,
  comentar char(1) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Table structure for table `usuarios`
--

CREATE TABLE usuarios (
  id int(9) NOT NULL auto_increment,
  login varchar(20) NOT NULL default '',
  senha varchar(40) NOT NULL default '',
  status char(1) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Table structure for table `usuarios_grupos`
--

CREATE TABLE usuarios_grupos (
  idUsuario int(9) NOT NULL default '0',
  idGrupo int(9) NOT NULL default '0',
  PRIMARY KEY  (idUsuario,idGrupo),
  KEY idUsuario (idUsuario),
  KEY idGrupo (idGrupo)
) TYPE=MyISAM;

CREATE TABLE Maquinas (
  id int(11) NOT NULL auto_increment,
  nome varchar(200) default NULL,
  ip varchar(15) default NULL,
  cliente varchar(200) default NULL,
  idEmpresa int(11) default NULL,
  data datetime default NULL,
  obs text,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

CREATE TABLE Programas (
  id int(11) NOT NULL auto_increment,
  idMaquina int(11) default NULL,
  nome varchar(200) default NULL,
  versao varchar(60) default NULL,
  data datetime default NULL,
  idUsuario int(11) default NULL,
  comentarios text,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

CREATE TABLE Users (
  id int(11) NOT NULL auto_increment,
  idMaquina int(11) default NULL,
  usuario varchar(60) default NULL,
  senha varchar(200) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

INSERT INTO Parametros VALUES (1,'Authentication Passphrase for password view','passphrase','YmF0YXRpbmhhIHF1YW5kbyBuYXNjZQ==');
INSERT INTO Parametros VALUES (2,'PassPhrase`s validation timeout (in seconds)','passphrase_timeout','MzA=');
INSERT INTO Parametros VALUES (3,'Ticket-IT - URL','ticket_url','aHR0cDovL3RpY2tldC5kZXZlbC5pdA==');
INSERT INTO Parametros VALUES (4,'Welcome to the Chat','boas_vindas_chat','SG93IGNhbiBJIGhlbHAgeW91Pw==');
INSERT INTO Parametros VALUES (5,'Integration between Ticket and Invent applications','ticket_invent','dGlja2V0X2FuZF9pbnZlbnQ=');
INSERT INTO Parametros VALUES (6,'Integration between Ticket and ISP applications','ticket_isp','dGlja2V0X2FuZF9pc3A=');

INSERT INTO usuarios VALUES (1,'admin','$1$$CoERg7ynjYLsj2j4glJ34.','A');
INSERT INTO usuarios VALUES (2,'guest','$1$Ou6tpaef$N1JF7ZRnhVATotUtJW/Xy1','A');
INSERT INTO usuarios_grupos VALUES (1,1);
INSERT INTO grupos VALUES (1,'Administrators','S','','','','','','','');
