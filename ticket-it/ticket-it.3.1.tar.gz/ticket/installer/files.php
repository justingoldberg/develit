<?
/**
 * Enter description here...
 *
 * @param unknown_type $modulo
 * @return unknown
 */
function phpIni( $modulo ){
	# Verificar a diretiva do php.ini
	$retorno=1;
	if ( !$modulo ){
		$register_globals = ini_get('register_globals');
		if ( $register_globals != 1 ){
			$retorno=0;
			echo "<br>";
			$titulo = _("Warning: An error has been ocurred");
			$mensagem = "<span class=txtaviso>
						"._("ATTENTION: Edit the archive php.ini")."</span><br>";
			$msgInicial = 	_("Set the register_globals line to On")."<br>".
							_("So, restart apache webserver")."<br><br>";
			$msgFinal = _("So, click here =>");
			$form ="<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=''>
					<input type='submit' name=matriz[bntNext] value="._("Next")." class='submit'>
					</form>";
			montarTabela( $titulo, $mensagem, $msgInicial, '', '', $msgFinal, $form );
		}
	}
	return $retorno;
}
function phpApache(){
	$retorno=1;
	# Pego os charset's setados
	$apache = apache_getenv("HTTP_ACCEPT_CHARSET");
	$variavel = split( "[,;]", $apache );
	if ( !in_array("ISO-8859-1", $variavel)) {
		$retorno=0;
		echo "<br>";
		$titulo = _("Warning: An error has been ocurred");
		$mensagem = "<span class=txtaviso>
					"._("ATTENTION: Edit the Charset")."<br></span>";
		$msgInicial =	_("Edit the charset to ISO")."<br>".
						"<br>";
		$msgFinal = _("So, click here =>");
		$form ="<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=''>
				<input type='submit' name=matriz[bntNext] value="._("Next")." class='submit'>
				</form>";
		montarTabela( $titulo, $mensagem, $msgInicial, '', '', $msgFinal, $form );
	}
	return $retorno;
}
function logo( $matriz ){
	global $corBorda, $corFundo, $_FILES;
	$retorno=1;
	# analisa: extens�o, dimens�o, copiar p/ imagens, config/html.php e custom.php
	$info = getimagesize( $_FILES[arquivo][tmp_name] );
	if (ereg("[][><}{}():;,!?*%&#@]", $_FILES['arquivo']['name'])){
		$erro = _("The file has invalid characters")."<br>";
	}
	else{
		if (!$info = getimagesize( $_FILES[arquivo][tmp_name] ) ){
			$erro.= _("It is not an image file or the field is empty")."<br>";
		}
		if ($info['2']>3){ // Aceitando apenas jpeg, gif e png
			$erro.= _("File is not of format: PNG, GIF or JPG")."<br>";
		}
		if  ( !( $info[0]==104 && $info[1]==50 ) && !empty($info) ){
			$erro.= _("The file does not have the dimension of 104x50 pixels")."<br>";
		}
		if ( empty( $erro ) ){
			if ( !copy( $_FILES['arquivo']['tmp_name'], "../imagens/".$matriz['nomeArquivo'] ) ){
				$erro.= _("Error when copying the file");
			}
		}
	}
	if ( !empty($erro) ){
		#nova tabela para mostrar informa��es
		$titulo = _("Warning: An error has been ocurred");
		$mensagem = "<span class=txtaviso>
					"._("ATTENTION: The file cannot be used")."<br>".
					_("Please, send it again")."<br><br>
					</span>";
		$msgFinal = _("So, click here =>");
		$form ="<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=formLogo>
				<input type='submit' name=matriz[] value="._("Back")." class='submit'>
				</form>";
		montarTabela( $titulo, $mensagem, $erro, '', '', $msgFinal, $form );
		$retorno=0;
	}
	else{
		# gravar em (html e custom).php
		file_html_custom($matriz);
	}
	return $retorno;
}

function file_html_custom($matriz){
	# Alterando o arquivo html.php
	$arquivophp="html.php";
	$find = "logoRelatorio";
	$replace=$matriz[nomeArquivo];
	$conexaophp = fopen( "../config/".$arquivophp, "r" );
	$totalBuffer='';
	while ( !feof( $conexaophp ) ){
		# verifica linha por linha.
		$buffer = rtrim( fgets( $conexaophp, 4096 ) );
		# prepara p/ procurar pela linha do que tem o conteudo de find[0] (no buffer)
		# a ocorrencia de $find, est� na posi�ao 0 (zero), o mesmo pode ser interpretado como false, ent�o pergunto se trata-se..
		#de um valor numerico
		if ( is_numeric( strpos( $buffer, $find ) ) ){
			#procurou por " (aspa dupla);
			$length=strpos($buffer,"\"");
			$buffer=substr( $buffer, 0, $length ) . "\$htmlDirImagem.\"/" . $replace . "\";";
			$txt = "# Logo da janela principal"."\n".
					$buffer;
		}
		$totalBuffer.=$buffer."\n";
	}# fim do while
	fclose($conexaophp);
	# Abro o arquivo pra sobreescrever
	$conexaophp = fopen( "../config/".$arquivophp, "w");
	if ( !fwrite( $conexaophp, $totalBuffer ) ){
		echo "Erro<br>";
	}
	fclose($conexaophp);
	
	# Adicionando uma linha no arquivo custom.php.txt
	$arquivotxt="custom.php.txt";
	$find = "\$config";
	$i=0;
	$y=0;
	$totalBuffer='';
	$conexaotxt = fopen( "../config/".$arquivotxt, "r" );
	while ( !feof( $conexaotxt ) ){
		# verifica linha por linha.
		$buffer = rtrim( fgets( $conexaotxt, 4096 ) );
		# prepara p/ procurar pela linha do que tem o conteudo de find[0] (no buffer)
		# a ocorrencia de $find, est� na posi�ao 0 (zero), o mesmo pode ser interpretado como false, ent�o pergunto se trata-se..
		#de um valor numerico
		if ( is_numeric( strpos( $buffer, $find ) ) ){
			$i++;
			if ( $i == 5 ){
				$y++;
			}
		}
		if ( $y > 0 ){
			$y++;
		}
		if ( $y == 4 ){
			$buffer = $txt;
		}
		$totalBuffer.=$buffer."\n";
	}# fim do while
	fclose($conexaotxt);
	# Abro o arquivo pra sobreescrever
	$conexaotxt = fopen( "../config/".$arquivotxt, "w");
	if ( !fwrite( $conexaotxt, $totalBuffer ) ){
		echo "Error<br>";
	}
	fclose($conexaotxt);
}

function montarTmp( $matriz ){
//	global $sessPath;
	$retorno=0;
	if (file_exists("../tmp")){
		$retorno=1;
	}
	elseif ( mkdir("../tmp", 0755) ){
		if (mkdir("../tmp/html", 0755)){
			chmod("../tmp/html", 0777);
			if (mkdir("../tmp/pdf", 0755)){
				if (chmod("../tmp/pdf", 0777) ) $retorno=1;
			}
		}
	}
	return $retorno;
}
function file_custom( $modulo, $matriz ){
	global $sessBanco, $sessPath;
	$arquivophp="custom.php";
	$arquivotxt="custom.php.txt";
	$dirPath = dirRaiz( $sessPath[path] );
	$conexaotxt = fopen( "../config/".$arquivotxt, "r");
	$find = array ( "configHostMySQL"	,
					"configUserMySQL"	,
					"configPasswdMySQL"	,
					"configDBMySQL"		,
					"configAppHost"		);
	$replace=array( "dbhost"	,
					"dbuser"	,
					"dbpassword",
					"dbdatabase",
					"");
	$i=0;
	# Criando o arquivo.php 
	$conexaophp = fopen( "../config/".$arquivophp, "w" );
	if ( !file_exists( "../config/".$arquivophp ) ){
		$msg=_("Probably permission problem.")."&nbsp;"._("It did not create a file.");
		$url="?modulo=$modulo&sub=$sub&acao=$acao";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	else{
		$totalBuffer='';
		while ( !feof( $conexaotxt ) ){
			
			# verifica linha por linha.
			$buffer = trim( fgets( $conexaotxt, 4096 ) );
			if ( !empty( $totalBuffer ) ) $totalBuffer.="\n";
			# prepara p/ procurar pela linha do que tem o conteudo de find[0] (no buffer)
			# a ocorrencia de $find, est� na posi�ao 0 (zero), o mesmo pode ser interpretado como false, ent�o pergunto se trata-se..
			#de um valor numerico
			if ( is_numeric( strpos( $buffer, $find[$i] ) ) ){
				#procurou por " (aspa dupla);
				$length=strpos($buffer,"\"");
				if ( $find[$i] != 'configAppHost' ){
					$buffer=substr( $buffer, 0, $length + 1) . $sessBanco[$replace[$i]] . "\";";
				}else{
					$buffer=substr( $buffer, 0, $length + 1) . "localhost/$dirPath" . "\";";
				}
				$i++;
			}
			# Acumulando o buffer para gravar;
			$totalBuffer.=$buffer;
		}# fim do while - varrendo o custom.php.txt
		if ( !fwrite( $conexaophp, $totalBuffer ) ){
			echo _("Error when writing in the file") . "&nbsp;(".$arquivophp.")";
		}
		fclose($conexaophp);
	}
	fclose ($conexaotxt);	
}

function file_isp( $modulo, $matriz ){
	$arquivophp="isp-it.php";
	$arquivotxt="isp-it.php.txt";
	$conexaotxt = fopen( "../config/".$arquivotxt, "r");
	$totalBuffer='';
	while ( !feof( $conexaotxt ) ){		
		# verifica linha por linha.
		$buffer = trim( fgets( $conexaotxt, 4096 ) );
		if ( !empty( $totalBuffer ) ) $totalBuffer.="\n";
		# prepara p/ procurar pela linha do que tem o conteudo de find[0] (no buffer)
		# a ocorrencia de $find, est� na posi�ao 0 (zero), o mesmo pode ser interpretado como false, ent�o pergunto se trata-se..
		#de um valor numerico
		# Acumulando o buffer para gravar;
		$totalBuffer.=$buffer;
	}# fim do while - varrendo o custom.php.txt
	fclose ($conexaotxt);
	# Criando o arquivo.php
	$conexaophp = fopen( "../config/".$arquivophp, "w" );
	fwrite( $conexaophp, $totalBuffer );
	fclose($conexaophp);
}
/**
 * Lendo os arquivos SQL, e retirando os comentarios que o mysqldump inclui
 *
 * @param string $conexaosql
 * @return string
 */
function semComentarioSQL($conexaosql){
	$conteudo='';
	while ( !feof( $conexaosql ) ){
		
		# verifica linha por linha.
		$buffer = fgets( $conexaosql, 4096 );
		# ver se come�a com -- que significa comentario em linguagem SQL. E retira-os.
		if ( is_numeric( strpos( $buffer, "--" ) ) ){
			$buffer = "";
		}
		# Acumulando o buffer;
		$conteudo.=$buffer;
	}# fim do while
	return $conteudo;
}
function file_email( $matriz ){
	global $lang;
	$arquivo="../includes/mail.php";
	$lang_find = "noreply";
	$lang_replace= _("noreply");
	$findEmpresa="Devel-IT";
	$conexao = fopen( $arquivo, "r+");
	$totalBuffer='';
	while ( !feof( $conexao ) ){	
		# verifica linha por linha.
		$buffer = rtrim( fgets( $conexao, 4096 ) );
		# prepara p/ procurar pela linha do que tem o conteudo de find[0] (no buffer)
		# a ocorrencia de $find, est� na posi�ao 0 (zero), o mesmo pode ser interpretado como false, ent�o pergunto se trata-se..
		#de um valor numerico
		if ( $lang != 'en_US' && is_numeric( strpos( $buffer, $lang_find ) ) ){
			$buffer = str_replace( $lang_find, $lang_replace, $buffer );
		}
		elseif( is_numeric( strpos( $buffer, "Devel-IT " ) ) ){
			$buffer = str_replace( $findEmpresa, $matriz[nomeEmpresa], $buffer );
		}
		$totalBuffer.=$buffer."\n";
	}# fim do while
	fclose($conexao);
	# Abro o arquivo pra sobreescrever
	$conexao = fopen( $arquivo, "w");
	if ( !fwrite( $conexao, $totalBuffer ) ){
		echo "Erro<br>";
	}
	fclose($conexao);
}

function validacaoRaiz( $raiz ){
	$retorno = 0;
	$raiz = barra($raiz);
	$compTotal=strlen($raiz);
	if ( "/" == substr($raiz, 0, 1) ){
		for($i=1; $i<=$compTotal; $i++ ){
			if( "/" == ( substr($raiz, $i, 1 ) ) ){				
				$nome = substr($raiz, 0, $i);
				$retorno = is_dir( $nome);
				if ( $retorno == 0 ){
					break;
				}
			}
		}
	}
	return $retorno;
}

function dirRaiz( $raiz ){
	$raiz = barra($raiz);
	$compTotal=strlen($raiz);
	$x=0;
	for($i=1; $i<=$compTotal; $i++ ){
		if( "/" == ( substr($raiz, $i, 1 ) ) ){
			$nome = substr($raiz, $x+1, $i-$x-1);
			$x=$i;
		}
	}
	return $nome;
}

function barra($raiz){
	if ( "/" != substr( $raiz, strlen($raiz) -1 , 1) ){
		$raiz.="/";
	}
	return $raiz;
}
?>