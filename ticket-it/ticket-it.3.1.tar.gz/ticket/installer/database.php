<?
/**
 * Enter description here...
 *
 * @return unknown
 */
function dbCriaBanco(){
	global $configHostMySQL, /*$configUserMySQL, $configPasswdMySQL,*/ $configDBMySQL, $sessBanco;
	
	# Conectar com banco de dados
	$conn=conectaMySQL($configHostMySQL, "root", $sessBanco[dbrootpassword] );
	$retorno=0;
	# Checar conex�o com banco de dados
	if(!$conn)
	{
		aviso(_("Connection with MySQL"), _("Error in the connection with MySQL Database"), "#", 500);
	}
	else{
		$sql = "CREATE DATABASE IF NOT EXISTS $configDBMySQL";
		consultaSQL( $sql, $conn );
		$db=selecionaDB($configDBMySQL);
		if(!$db){
	        aviso(_("Database"), _("Error when selecting database"), "#", 500);
		}else{
			$retorno=1;
		}
	}
	return $retorno;
}

function dbUserDB(){
	global $configHostMySQL, $configUserMySQL, $configPasswdMySQL, $configDBMySQL, $sessBanco;
	$retorno=0;
	# Conecta com Banco de Dados
	$conn = conectaMySQL($configHostMySQL, "root", $sessBanco[dbrootpassword] );
	if(!$conn)
	{
		aviso(_("Connection with MySQL"), _("Error in the connection with MySQL Database"), "#", 500);
	}
	else{
		$sql = "GRANT ALL ON $configDBMySQL.* TO $configUserMySQL@$configHostMySQL IDENTIFIED BY '$configPasswdMySQL'";
		$consulta = consultaSQL( $sql, $conn );
		$sql = "FLUSH PRIVILEGES";
		$consulta = consultaSQL( $sql, $conn );
		$retorno=1;
	}
}

function dbCriaTabela(){
	global $lang;
	
	#pegar o arquivo ticket_exclusivo.sql e ticket_global.sql
	$origem  = "../sql/";
	$ticket_global = $origem."ticket_global.sql";
	$ticket_exclusivo = $origem."ticket_exclusivo.sql";
	
	# ticket_global
	$conexaosql = fopen( "$ticket_global", "r");
	if ($conexaosql){
		$conteudo = semComentarioSQL($conexaosql);
		fclose ($conexaosql);
		dadosSql( $conteudo );
	}
	
	# ticket_exclusivo
	$conexaosql = fopen( "$ticket_exclusivo", "r");
	if ($conexaosql){
		$conteudo = semComentarioSQL($conexaosql);
		fclose ($conexaosql);
		$retorno = dadosSql( $conteudo );
	}
	
	# Tradu��o do idioma
	if ( $lang != 'en_US' ){
		trocaLang();
	}
}

function dadosSql( $conteudo ){
	global $conn, $lang;
	$retorno=1;
	# Usa o conteudo do arquivo como um array
	$dados = explode ( ";", $conteudo );
	# o ultimo elemento � sempre vazio
//	$dados_limpos = array_pop( $dados );
//	$i=0;
	foreach ( $dados as $sql ){
		$consulta = consultaSQLHide( $sql, $conn );
//		$i++;
	}# fim do foreach
}

function trocaLang(){
	global $tb, $conn;
	# Tab. prioridades
	$consulta = buscaPrioridades( '', '', 'todos', 'id' );
	$i=0;
	while($i < contaConsulta($consulta)) {
		$matriz['id']=resultadoSQL( $consulta, $i, 'id' );
		$name=		resultadoSQL( $consulta, $i, 'nome' );
		$text=		resultadoSQL( $consulta, $i, 'texto' );
		$matriz['cor']=resultadoSQL($consulta, $i, 'cor');
		$matriz['valor']=resultadoSQL($consulta, $i, 'valor');
		$matriz['nome']= _("$name");
		$matriz['texto']=_("$text");
		$grava=dbPrioridade($matriz, 'alterar');
		$i++;
	} #fecha laco de montagem de tabela

	# Tab. status
	$consulta = buscaStatus( '', '', 'todos', 'id' );
	$i=0;
	while($i < contaConsulta($consulta)) {
		$matriz[id]=resultadoSQL( $consulta, $i, 'id' );
		$name=		resultadoSQL( $consulta, $i, 'nome' );
		$text=		resultadoSQL( $consulta, $i, 'texto' );
		$matriz['valor']=resultadoSQL($consulta, $i, 'valor');
		$matriz['nome']= _("$name");
		$matriz['texto']=_("$text");
		$grava=dbStatus($matriz, 'alterar');
		$i++;
	} #fecha laco de montagem de tabela
	
	# Tab. categorias
	$consulta = buscaCategorias( '', '', 'todos', 'id' );
	$i=0;
	while($i < contaConsulta($consulta)) {
		$matriz[id]=resultadoSQL( $consulta, $i, 'id' );
		$name=		resultadoSQL( $consulta, $i, 'nome' );
		$text=		resultadoSQL( $consulta, $i, 'texto' );
		$matriz['nome']= _("$name");
		$matriz['texto']=_("$text");
		$grava=dbCategoria($matriz, 'alterar');
		$i++;
	} #fecha laco de montagem de tabela
	
	#Tab. Parametros
	$consulta = buscaParametros( '', '', 'todos', 'id' );
	$i=0;
	while($i < contaConsulta($consulta)) {
		$matriz[id]=		resultadoSQL( $consulta, $i, 'id' );
		$description=		resultadoSQL( $consulta, $i, 'descricao' );
		$matriz['parametro']=resultadoSQL($consulta,$i,'parametro');
		$matriz['valor'] = 	base64_decode( resultadoSQL( $consulta, $i, 'valor' ) );
		$matriz['descricao']= _("$description");
		$grava=dbParametro($matriz, 'alterar');
		$i++;
	} #fecha laco de montagem de tabela
	
//	#Tab. usuarios
//	$consulta = buscaUsuarios( '', '', 'todos', 'id' );
//	$i=0;
//	while($i < contaConsulta($consulta)) {
//		$matriz[id]=resultadoSQL( $consulta, $i, 'id' );
//		$login =	resultadoSQL( $consulta, $i, 'login' );
//		$usuario = 	_("$login");
//		$sql =		"UPDATE $tb[Usuarios] SET login='$usuario' WHERE id=$matriz[id]";
//		$grava = consultaSQL($sql, $conn);
//		$i++;
//	} #fecha laco de montagem de tabela
	
	#Tab. grupos
	$consulta = buscaGrupos( '', '', 'todos', 'id' );
	$i=0;
	while($i < contaConsulta($consulta)) {
		$matriz[id]=resultadoSQL( $consulta, $i, 'id' );
		$name =		resultadoSQL( $consulta, $i, 'nome' );
		$nome =		_("$name");
		$sql =		"UPDATE $tb[Grupos] SET nome='$nome' WHERE id=$matriz[id]";
		$grava = consultaSQL($sql, $conn);
		$i++;
	} #fecha laco de montagem de tabela
}

?>