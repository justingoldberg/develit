<?
global $protocolo;

# Habilita envio sms
$sms[enabled] = false;

/* 
	Mensagem enviada ao celular do cliente quando um ticket for aberto.
	A palavra reservada #protocolo#, ser� substituida pelo protocolo do
	ticket, antes do sms ser enviado.
*/
$sms["msgTicketAberto"] = "Prezado cliente, seu e-ticket foi aberto com protocolo #protocolo#. Para agilizar seu atendimento, tenha sempre em maos este protocolo.";

/* 
	Mensagem enviada ao celular do cliente quando um ticket for fechado 
	A palavra reservada #protocolo#, ser� substituida pelo protocolo do
	ticket, antes do sms ser enviado.
*/
$sms["msgTicketFechado"] = "Prezado cliente, informamos que seu e-ticket protocolo #protocolo# foi fechado. Agradecemos por utilizar nossos produtos e servicos.";

/* Conta de usu�rio cadastrado na human */
$sms["account"] = "";

/* C�digo do usu�rio cadastrado na human */
$sms["code"] = "";

/* Quem est� enviando a mensagem */
$sms["from"] = "Devel-IT";
?>