<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 02/08/2005
# Ultima altera��o: 02/08/2005
#    Altera��o No.: 001
#
# Fun��o:
#    Configura��es de arquivos

# Arquivo Remessa
$arquivo[tmpDir]="tmp/remessa/";

# Arquivos tempor�rios HTML
$arquivo[tmpHTML]="tmp/html/";

# Arquivos tempor�rios PDF
$arquivo[tmpPDF]="tmp/pdf/";

# template
$template[dir]="templates/";

?>
