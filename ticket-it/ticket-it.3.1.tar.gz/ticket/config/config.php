<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 15/04/2003
# Ultima altera��o: 29/08/2006
#    Altera��o No.: 032
#
# Fun��o:
#    Configura��es utilizadas pela aplica��o

##############################################
# Language settings

if ( $_GET['lang'] ){
	$lang = $_GET['lang'];
	setcookie ( 'lang', $lang, time() + 3600 * 24 * 30 );
}
elseif ( $_POST['lang'] == "" ){
	if (isset($_COOKIE['lang'])){
		$lang=$_COOKIE['lang'];
	}//fim do ENT�O do if(isset
	else{
		# defino como default: en_US
		$lang = 'en_US';
		setcookie('lang',$lang, time() + 3600 * 24 * 30);
	}//fim do if(isset
}//fim do ENTAO
# entra como convidado
else{
	$lang = $_POST['lang'];
	setcookie ('lang',$lang, time() + 3600 * 24 * 30);
} //fim do if
//$lang='pt_BR';	setcookie ('lang',$lang, time() + 3600 * 24 * 30);
//configura a vari�vel de ambiente LANG
putenv("LANG=$lang");
// configura a vari�vel de localidade para A selecionada
setlocale(LC_ALL, $lang);
// Configura o text domain como 'messages'
$domain = 'messages';
bindtextdomain($domain, ( strstr( $_SERVER["SCRIPT_NAME"], 'installer' ) ? "../locale/" : "locale/" ) );
textdomain($domain);  
bind_textdomain_codeset($domain, 'ISO-8859-1');
//echo "GET['lang']: ".$_GET['lang']."<br>X=$x<br>POST['lang']: ".$_POST['lang']."<br>";
#################################################
# Configura��es da Aplica��o
$configAppName=_("Devel-IT - .:Ticket IT:.");
$configAppVersion=_("Version 3.1");
	
# Configura��es de cor
$corFundo="#ffffff";
$corBorda="#223366";
$corBordaLayer="#990000";
$corFundoLayer="#FFFFFF";

#############################################
# Limites de listagens e pagina��es
$limite[lista][usuarios]=10;
$limite[lista][grupos]=5;
$limite[lista][categorias]=5;
$limite[lista][prioridades]=5;
$limite[lista][status]=5;
$limite[lista][tickets]=10;
$limite[lista][ticket_grupo]=50;
$limite[lista][parametros]=50;
$limite[lista][empresas]=50;
$limite[lista][usuariosempresas]=10;

# Limites de listagem de tickets
$limite[ticket][novo]=20;
$limite[ticket][aberto]=200;
$limite[ticket][fechado]=20;

# Limites de listagem em resumos
$limite[resumo][novos]=10;
$limite[resumo][ultimos]=20;

# Status
$statusTicket[novo]='N';
$statusTicket[fechado]='F';
$statusTicket[aberto]='A';
$statusTicket[parado]='P';


# Cores
$cores[Green]="#11c411";
$cores[Red]="#ff723f";
$cores[Beige]="#dddd90";
$cores[Blue]="#aeadff";
$cores[Orange]="#ffb159";
$cores[Yellow]="#f2ef5e";

# Idiomas
$languages[en_US] = _("English (United States)");
$languages[pt_BR] =	_("Portuguese (Brazil)");
?>
