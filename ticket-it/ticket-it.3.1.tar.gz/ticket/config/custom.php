<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 15/04/2003
# Ultima altera��o: 19/01/2005
#    Altera��o No.: 006
#
# Fun��o:
#    Configura��es para Conex�o com banco de dados

$configHostMySQL="localhost";
$configUserMySQL="root";
$configPasswdMySQL="";
$configDBMySQL="ticket";

# Host do servidor
$configAppHost="localhost/ticket";

# Logo da janela principal
$html[imagem][logoRelatorio]=$htmlDirImagem.$htmlDirImagem.$htmlDirImagem.$htmlDirImagem.$htmlDirImagem.$htmlDirImagem.$htmlDirImagem."/logo_fBlanc.gif";
?>

