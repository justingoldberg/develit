<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 04/08/2005
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 002
#
# Fun��o:
#    Fun��es de TicketChatConteudo

# Banco de dados
function dbTicketChatConteudo($matriz, $tipo) {
	
	global $conn, $tb, $modulo, $acao, $sessLogin;
	
	# Data do sistema 
	$data=dataSistema();

	# Busca o ID do usu�rio logado
	if($sessLogin[login]) $idUser=buscaIDUsuario($sessLogin[login], 'login', 'igual', 'login');
	else $idUser=buscaIDUsuario( 'guest', 'login', 'igual', 'login' );
	
	# Incluir Comentarios
	if($tipo=='incluir') {
		
		$matriz[ip]=$_SERVER[REMOTE_ADDR];
		$matriz[mensagem]=addslashes($matriz[mensagem]);
	
		$sql="INSERT INTO $tb[TicketChatConteudo] VALUES (
			0,
			$matriz[chat],
			$idUser,
			'$data[dataBanco]',
			'$matriz[mensagem]',
			'$matriz[ip]'	
		)";
		
	} #fecha abertura

	elseif($tipo=='excluirtodos') {
		$sql="DELETE FROM $tb[TicketChatConteudo] WHERE idChat='$matriz[id]'";
	}
	
	elseif($tipo=='excluir') {
		$sql="DELETE FROM $tb[TicketChatConteudo] WHERE id='$matriz[id]'";
	}
	
	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
}


# Fun��o para grava��o de ChatConteudo em TicketComent�rio
function gravaChatComentario($idChat) {
	
	global $tb;
	
	# Buscar chatConteudo
	$consulta=buscaRegistro($idChat,'idChat','igual','data ASC',$tb[TicketChatConteudo]);
	
	if($consulta && contaConsulta($consulta)>0) {
		
		$linhaComentario=_("Registration of Attendance - Chat Online:")."\n\n";
		for($a=0;$a<contaConsulta($consulta);$a++) {
			$id=resultadoSQL($consulta, $a, 'id');
			$idChat=resultadoSQL($consulta, $a, 'idChat');
			$dadosChat=dadosChat($idChat);
			$idUsuario=resultadoSQL($consulta, $a, 'idUsuario');
			$data=converteData(resultadoSQL($consulta, $a, 'data'),'banco','form');
			$texto=resultadoSQL($consulta, $a, 'texto');
			$ip=resultadoSQL($consulta, $a, 'ip');
			
			$usuario=buscaLoginUsuario($idUsuario,'id','igual','id');
			
			$linhaComentario.="$data $usuario: $texto\n";
			
		}
	}
	
	# Gravar
	if(is_array($dadosChat)) {
		$matriz[ticket]=$dadosChat[idTicket];
		$matriz[descricao]=$linhaComentario;
		dbComentariosTicket($matriz, 'incluir');
	}
}

?>