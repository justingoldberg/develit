<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 24/01/2003
# Ultima altera��o: 18/08/2006
#    Altera��o No.: 005
#
# Fun��o:
#    Fun��es de usuarios de grupos

# Fun��o para listagem de servi�os de Servidores
function listarUsuariosGrupo($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $limite;

	# Sele��o de registros
	$consulta=buscaGrupos($registro, 'id', 'igual', 'id');
	
	if(!$consulta || contaConsulta($consulta)==0) {
		# Servidor n�o encontrado
		itemTabelaNOURL(_('Group not found!'), 'left', $corFundo, 3, 'txtaviso');
	}
	else {
		# Mostrar Informa��es sobre Servidor
		verGrupo($registro);
		
		$consulta=buscaUsuariosGrupos($registro, 'idGrupo','igual','idGrupo');
		
		# Cabe�alho		
		# Motrar tabela de busca
		novaTabela("["._("Users of the Group")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
		$tmpOpcao=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=".$acao."adicionar&registro=$registro>"._("Add")."</a>",'incluir');
		itemTabelaNOURL($tmpOpcao, 'right', $corFundo, 3, 'tabfundo1');

		# Caso n�o hajam servicos para o servidor
		if(!$consulta || contaConsulta($consulta)==0) {
			# N�o h� registros
			itemTabelaNOURL(_('There is no users registered for this group'), 'left', $corFundo, 3, 'txtaviso');
		}
		else {
		
			# Cabe�alho
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela(_('Login'), 'center', '40%', 'tabfundo0');
				itemLinhaTabela(_('Status'), 'center', '20%', 'tabfundo0');
				itemLinhaTabela(_('Options'), 'center', '40%', 'tabfundo0');
			fechaLinhaTabela();

			$i=0;
			
			while($i < contaConsulta($consulta)) {
				# Mostrar registro
				$idUsuario=resultadoSQL($consulta, $i, 'idUsuario');
				
				# Buscar informa��es sobre o servi�o
				$consultaUsuario=buscaUsuarios($idUsuario, 'id','igual','id');
				
				$login=resultadoSQL($consultaUsuario, 0, 'login');
				$status=resultadoSQL($consultaUsuario, 0, 'status');
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=$acao".excluir."&registro=$registro:$idUsuario>"._("Delete")."</a>",'excluir');
		
				/*
				# Verificar status para montar op��o
				if($status=='A') {
					# Op��o desativar
					$opcoes.="&nbsp;";
					$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=$acao".desativar."&registro=$registro:$idUsuario>Desativar</a>",'desativar');
				}
				elseif($status=='D') {
					# Op��o ativar
					$opcoes.="&nbsp;";
					$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=$acao".ativar."&registro=$registro:$idUsuario>Ativar</a>",'ativar');
				} */
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($login, 'left', '40%', 'normal');
					itemLinhaTabela(checaStatus($status), 'center', '20%', 'normal');
					itemLinhaTabela($opcoes, 'left', '40%', 'normal');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
			
			fechaTabela();
		} #fecha servicos encontrados
	} #fecha listagem
}#fecha fun��o de listagem


# Funcao para cadastro de usuarios
function adicionarUsuariosGrupo($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Form de inclusao
	if(!$matriz[bntAdicionar]) {

		# Sele��o de registros
		$consulta=buscaGrupos($registro, 'id', 'igual', 'id');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# Servidor n�o encontrado
			itemTabelaNOURL(_('Group not found!'), 'left', $corFundo, 3, 'txtaviso');
		}
		else {
			# Mostrar Informa��es sobre Servidor
			verGrupo($registro);
	
			# Motrar tabela de busca
			novaTabela2("["._("Add")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=registro value=$registro>
					<input type=hidden name=matriz[grupo] value=$registro>
					<input type=hidden name=acao value=$acao>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("User:")." </b>";
					htmlFechaColuna();
					$item=formListaUsuariosGrupo($registro);
					itemLinhaForm($item, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntAdicionar] value="._("Add")." class=submit>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		} # fecha servidor informado para cadastro
	} #fecha form
	elseif($matriz[bntAdicionar]) {
		# Conferir campos
		if($matriz[grupo] && $matriz[usuario]) {
			# Cadastrar em banco de dados
			$grava=dbUsuarioGrupo($matriz, 'incluir');
				
			# Verificar inclus�o de registro
			if($grava) {
				# acusar falta de parametros
				# Mensagem de aviso
				$msg=_("Data Recorded Success full!");
				$url="?modulo=$modulo&sub=$sub&acao=usuarios&registro=$registro";
				aviso(_("Warning"), $msg, $url, 760);
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
			$url="?modulo=$modulo&sub=$sub&acao=usuarios&registro=$registro";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	}
} # fecha funcao de inclusao de usuarios



# Fun��o para montar campo de formulario
function formListaGruposUsuario($idUsuario, $idGrupo)
{
	global $conn, $tb;
	
	# Buscar Servi�os de servidor (ja cadastrados)
	$sql="
		SELECT
			grupos.id id,
			grupos.nome nome
		FROM
			grupos, 
			usuarios,
			usuarios_grupos
		WHERE
			grupos.id=usuarios_grupos.idGrupo
			AND usuarios.id=usuarios_grupos.idUsuario
			AND usuarios.id=$idUsuario
		ORDER BY
			grupos.nome";
			
	$consulta=consultaSQL($sql, $conn);
	
	$item="<select name=matriz[grupo]>\n";
	
	# Listargem
	$i=0;
	while($i < contaConsulta($consulta)) {
		# Zerar flag de registro j� cadastrado
		$flag=0;
		
		# Valores dos campos
		$id=resultadoSQL($consulta, $i, 'id');
		$nome=resultadoSQL($consulta, $i, 'nome');
		
		$opcSelect='';
		if($id==$idGrupo) $opcSelect='selected';

		# Mostrar servi�o		
		$item.= "<option value=$id $opcSelect>$nome\n";

		#Incrementar contador
		$i++;
	}
	
	$item.="</select>";
	
	return($item);
	
} #fecha funcao de montagem de campo de form



# Fun��o para montar campo de formulario
function formListaUsuariosGrupo($grupo)
{
	global $conn, $tb;
	
	# Buscar Servi�os de servidor (ja cadastrados)
	$consultaGrupo=buscaUsuariosGrupos($grupo, 'idGrupo','igual','idGrupo');
	
	$consulta=buscaUsuarios($texto, $campo, 'todos', 'login');
	
	$item="<select name=matriz[usuario]>\n";
	
	# Listargem
	$i=0;
	while($i < contaConsulta($consulta)) {
		# Zerar flag de registro j� cadastrado
		$flag=0;
		
		# Valores dos campos
		$login=resultadoSQL($consulta, $i, 'login');
		$id=resultadoSQL($consulta, $i, 'id');

		# Verificar se servi�o j� est� cadastrado
		$iGrupo=0;
		while($iGrupo < contaConsulta($consultaGrupo) ) {
		
			# Verificar
			$idUsuario=resultadoSQL($consultaGrupo, $iGrupo, 'idUsuario');
			
			if($idUsuario == $id) {
				# Setar Flag de registro j� cadastrado
				$flag=1;
				break;
			}

			# Incrementar contador
			$iGrupo++;
		}

		if(!$flag) {
			# Mostrar servi�o		
			$item.= "<option value=$id>$login\n";
		}

		#Incrementar contador
		$i++;
	}
	
	$item.="</select>";
	
	return($item);
	
} #fecha funcao de montagem de campo de form



# Fun��o para grava��o em banco de dados
function dbUsuarioGrupo($matriz, $tipo)
{
	global $conn, $tb, $modulo, $sub, $acao;
	
	# Sql de inclus�o
	if($tipo=='incluir') {
		# Verificar se servi�o existe
		$tmpBusca=buscaUsuariosGrupos("idUsuario=$matriz[usuario] AND idGrupo=$matriz[grupo]", $campo, 'custom', 'idGrupo');
		
		# Registro j� existe
		if($tmpBusca && contaConsulta($tmpBusca)>0) {
			# Mensagem de aviso
			$msg=_("Record already exists in the database");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: Error when including record"), $msg, $url, 760);
		}
		else {
			$sql="INSERT INTO $tb[UsuariosGrupos] VALUES ($matriz[usuario], $matriz[grupo])";
		}
	} #fecha inclusao
	
	elseif($tipo=='excluir') {
		# Verificar se servi�o existe
		$tmpGrupo=buscaUsuariosGrupos("idGrupo=$matriz[grupo] AND idUsuario=$matriz[usuario]", 'id', 'custom', 'idUsuario');
		
		# Registro j� existe
		if(!$tmpGrupo || contaConsulta($tmpGrupo)==0) {
			# Mensagem de aviso
			$msg=_("Record doesn't exist in the database");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: Error when changing record"), $msg, $url, 760);
		}
		else {
			$sql="DELETE FROM $tb[UsuariosGrupos] WHERE idUsuario=$matriz[usuario] AND idGrupo=$matriz[grupo]";
		}
	}

	# Excluir todos os usuarios do grupo
	elseif($tipo=='excluirtodos') {
		# Verificar se servi�o existe
		$sql="DELETE FROM $tb[UsuariosGrupos] WHERE idUsuario=$matriz[id]";
	}
	# Excluir todos os usuarios do grupo
	elseif($tipo=='excluirgrupo') {
		# Verificar se servi�o existe
		$sql="DELETE FROM $tb[UsuariosGrupos] WHERE idGrupo=$matriz[id]";
	}

	
	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
	
} # fecha fun��o de grava��o em banco de dados


# Funcao para exclus�o de usuarios
function excluirUsuariosGrupo($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;

	$matTMP=explode(":",$registro);
	$matriz[grupo]=$matTMP[0];
	$matriz[usuario]=$matTMP[1];
	
	$consultaUsuario=buscaUsuarios($matriz[usuario], 'id', 'igual', 'id');
	$login=resultadoSQL($consultaUsuario, 0, 'login');
	$status=resultadoSQL($consultaUsuario, 0, 'status');
	
	$consultaUsuariosGrupos=buscaUsuariosGrupos('idGrupo='.$matriz[grupo].' AND idUsuario='.$matriz[usuario], $campo, 'custom', 'idGrupo');
	
	
	# Form de exclus�o
	if(!$matriz[bntRemover]) {

		# Sele��o de registros
		$consulta=buscaGrupos($matriz[grupo], 'id', 'igual', 'id');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# Servidor n�o encontrado
			itemTabelaNOURL(_('Group not found!'), 'left', $corFundo, 3, 'txtaviso');
		}
		else {
			# Mostrar Informa��es sobre Servidor
			verGrupo($matriz[grupo]);
	
			# Motrar tabela de busca
			novaTabela2("["._("Delete")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=registro value=$registro>
					<input type=hidden name=acao value=$acao>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("User:")." </b>";
					htmlFechaColuna();
					itemLinhaForm($login, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("Status:")." </b>";
					htmlFechaColuna();					
					itemLinhaForm(checaStatus($status), 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntRemover] value="._("Remove")." class=submit>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		} # fecha  formulario
	} #fecha form
	elseif($matriz[bntRemover]) {
		# Conferir campos
		if($matriz[grupo] && $matriz[usuario]) {
		
			# Cadastrar em banco de dados
			$grava=dbUsuarioGrupo($matriz, 'excluir');
				
			# Verificar inclus�o de registro
			if($grava) {
				# acusar falta de parametros
				# Mensagem de aviso
				$msg=_("Record deleted Success Full!");
				$url="?modulo=$modulo&sub=$sub&acao=usuarios&registro=$matriz[grupo]";
				aviso(_("Warning"), $msg, $url, 760);
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
			$url="?modulo=$modulo&sub=$sub&acao=usuarios&registro=$registro";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	}
} # fecha funcao de exclus�o



# fun��o de busca usuarios do grupo
function buscaUsuariosGrupos($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[UsuariosGrupos] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[UsuariosGrupos] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[UsuariosGrupos] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[UsuariosGrupos] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	
} # fecha fun��o de busca usuarios do grupo

?>