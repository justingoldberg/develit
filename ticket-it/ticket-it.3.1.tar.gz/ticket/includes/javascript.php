<?php
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 02/10/2003
# Ultima altera��o: 17/08/2004
#    Altera��o No.: 003
#
# Fun��o:
#    Fun��es JavaScript
$dataInvalida = _("Invalid Date");
$horaInvalida = _("Invalid Hour");
### Javascript ###
$js = <<<JS
<script type="text/javascript" language="JavaScript">
<!--
// detecta o navegador
var ie=(((navigator.userAgent.indexOf("MSIE")>-1)||(navigator.userAgent.indexOf("Mozilla/5.0")>-1))&&navigator.userAgent.indexOf("Opera")==-1?true:false);
var ns=(navigator.userAgent.indexOf("Netscape")>-1&&navigator.userAgent.indexOf("Opera")==-1?true:false);
var agt=navigator.userAgent.toLowerCase();

//here you place the ids of every element you want.
var ids=new Array();

function flipdiv(id ){

	if ( ids[id] == 1 ) {
		ids[id]=0;
		hidediv(id);
	}
	else {
		ids[id]=1;
		showdiv(id);
	}
}
function hidediv(id) {

	//safe function to hide an element with a specified id
	if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById(id).style.display = 'none';
	}
	else {
		if (document.layers) { // Netscape 4
			document.id.display = 'none';
		}
		else { // IE 4
			document.all.id.style.display = 'none';
		}
	}
}

function showdiv(id) {
	//safe function to show an element with a specified id
		  
	if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById(id).style.display = 'block';
	}
	else {
		if (document.layers) { // Netscape 4
			document.id.display = 'block';
		}
		else { // IE 4
			document.all.id.style.display = 'block';
		}
	}
}

//function showtr(id){ changedisplay(id, 'table-row'); }
function showtr(id){ changedisplay(id, 'inline'); }

function changedisplay(id, valor){
	//safe function to show an element with a specified id
	if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById(id).style.display = valor;
	}
	else {
		if (document.layers) { // Netscape 4
			document.id.display = valor;
		}
		else { // IE 4
			document.all.id.style.display = valor;
		}
	}
}

//   ##############  SIMPLE  BROWSER SNIFFER
if (document.layers) {navigator.family = "nn4"}
if (document.all) {navigator.family = "ie4"}
if (window.navigator.userAgent.toLowerCase().match("gecko")) {navigator.family = "gecko"}


function novaJanela(theURL,winName,features) { //v2.0

  window.open(theURL,winName,features);
  
}

function voltar() {
	document.history.back();
}

function verificaData(data, campo) {



	var er = /\//g;
	data=data.replace(er,'');
	
	if(data && !isNaN(data)) {
		
		dia=data.substr(0,2);
		mes=data.substr(2,2);
		ano=data.substr(4,4);
		
		dataFormat=dia+'/'+mes+'/'+ano;

		if( !dia || !mes || !ano || (dia <= 0 || dia > 31) || (mes <=0 || mes > 12) || (ano < 1900) ) {
			alert('$dataInvalida');
			
			nomecampo=document.forms[0].elements[campo].name;
			
			document.forms[0].elements[campo].value='';
			document.forms[0].elements[campo].focus();
			return false;

		}
		else {
			document.forms[0].elements[campo].value=dataFormat;
		}
	}
	else if(data && isNaN(data)) {
		alert('$dataInvalida');
		
		document.forms[0].elements[campo].value='';
		document.forms[0].elements[campo].focus();
	}
}


function verificaHora(data, campo) {

	var er = /\//g;
	data=data.replace(er,'');
	
	if(data && !isNaN(data)) {
		
		hora=data.substr(0,2);
		
		if( !hora || (hora <= 0 || hora > 24) ) {
			alert('$horaInvalida');
			
			nomecampo=document.forms[0].elements[campo].name;
			
			document.forms[0].elements[campo].value='';
			document.forms[0].elements[campo].focus();
			return false;

		}
		else {
			document.forms[0].elements[campo].value=hora;
		}
	}
	else if(data && isNaN(data)) {
		alert('$horaInvalida');
		
		document.forms[0].elements[campo].value='';
		document.forms[0].elements[campo].focus();
	}
}

function verificaDataMesAno2(data, campo) {

	var er = /\//g;
	data=data.replace(er,'');
	
	if(data && !isNaN(data)) {
		mes=data.substr(0,2);
		ano=data.substr(2,4);
		
		dataFormat=mes+'/'+ano;
		
		if( !mes || !ano || (mes < 1 || mes > 12) || (ano < 1900 ) ) {
		
			alert('$dataInvalida');
			
			nomecampo=document.forms[0].elements[campo].name;			
			
			document.forms[0].elements[campo].value='';
			document.forms[0].elements[campo].focus();
		}
		else {
			document.forms[0].elements[campo].value=dataFormat;
		}
	}
	else if(data && isNaN(data)) {
		alert('$dataInvalida');
		
		document.forms[0].elements[campo].value='';
		document.forms[0].elements[campo].focus();
	}
}

function caracteresRestantes(texto, campo, qtd){

	if(texto.value.length >= qtd) {
		var str = texto.value;
		texto.value = str.substr(0, qtd);
	}
	document.getElementById(campo).innerHTML = (qtd - (texto.value.length));
}

// call an ajax combo company
function callComboCompany(obj, isIntegratedInvent){
if(obj.checked){xajax_getAjax('ticket','comboEmpresa','innerHTML',0);}
else{xajax_getAjax('ticket','comboEmpresa','innerHTML','clearAjaxLayer'); if(isIntegratedInvent){xajax_getAjax('ticket','comboMaquina','innerHTML','clearAjaxLayer');}}
}

// call an ajax combo host
function callComboHost(idCompany){
if(idCompany){ xajax_getAjax('ticket','comboMaquina','innerHTML',idCompany); }
else{ xajax_getAjax('ticket','comboMaquina','innerHTML','clearAjaxLayer'); }
}

// add a select option
function addOption(selectId, txt, val){var objOption = new Option(txt, val); document.getElementById(selectId).options.add(objOption);}

//-->
</script>
JS;
### Fim do Javascript ###
?>