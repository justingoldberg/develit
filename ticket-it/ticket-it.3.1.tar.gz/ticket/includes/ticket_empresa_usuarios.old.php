<?

# Fun��o para grava��o em banco de dados
function dbTicketEmpresaUsuarios($matriz, $tipo) {

	global $conn, $tb, $modulo, $sub, $acao;

	$data=dataSistema();

	# Sql de inclus�o
	if( $tipo=='relacionar' ) {

		# Checar se ticket j� esta relacionado
		if( isTicketRelatedWithCompanyUser( $matriz['idTicket']) ) {
			$sql = "UPDATE {$tb['TicketEmpresaUsuarios']} ".
				"SET idTicket='{$matriz['idTicket']}', idEmpresaUsuario='{$matriz['idEmpresaUsuario']}'".
				"WHERE idTicket='".(int)$matriz['idTicket']."'";
		}
		else {
			$sql =	"INSERT INTO ".
						"{$tb['TicketEmpresaUsuarios']} ".
					"VALUES ".
					"(0, '{$matriz['idTicket']}', '{$matriz['idEmpresaUsuario']}');";
		}
	} #fecha inclusao
	elseif($tipo=='excluir' ) {
		$sql="DELETE FROM {$tb['TicketEmpresaUsuarios']} WHERE idTicket='".(int)$matriz['idTicket']."'";
	}
	
	if( $sql ) {
		$retorno=consultaSQL($sql, $conn);
		return($retorno);
	}

} # fecha fun��o de grava��o em banco de dados

function buscaTicketEmpresaUsuario( $texto, $campo, $tipo, $ordem ){
	global $tb;
	return buscaRegistro($texto, $campo, $tipo, $ordem, $tb['TicketEmpresaUsuarios']);
}

/**
 * Checar se ticket j� possui relacionamento com algum us�rio da empresa
 *
 * @param $idTicket
 * @return boolean
 */
function isTicketRelatedWithCompanyUser( $idTicket ) {
	$consulta=buscaTicketEmpresaUsuario($idTicket, 'idTicket', 'igual','id');
	return ( $consulta && contaConsulta($consulta) > 0 );
}

/**
 * Returns the Company User Data who has created the ticket
 *
 * @param integer $idTicket
 * @return unknown
 */
function getCompanyUserByTicket( $idTicket ){
	$ret = false;
	$ticketEmpresaUsuario = buscaTicketEmpresaUsuario($idTicket, 'idTicket', 'igual', 'id' );
	if( $ticketEmpresaUsuario ){
		$idEmpresaUsuario = resultadoSQL( $ticketEmpresaUsuario, 0, 'idEmpresaUsuario' );
		$busca = buscaUsuariosEmpresas( $idEmpresaUsuario, 'id', 'igual', 'id' );
		if( $busca ){
			$ret = mysql_fetch_array($busca);
		}
	}
	return $ret;
}

/**
 * Return every users from company of the ticket $idTicket'.
 *
 * @param integer $idTicket
 * @return array/object
 */
function getCompanyUsersByTicket( $idTicket ){
	global $tb;
	// buscar usu�rios da empresa
	$sql =	"SELECT ".
				"$tb[EmpresasUsuarios].* ".
			"FROM $tb[Ticket]".
				" INNER JOIN $tb[TicketEmpresa] ON ($tb[Ticket].id=$tb[TicketEmpresa].idTicket)".
				" INNER JOIN $tb[Empresas] ON ($tb[TicketEmpresa].idEmpresa=$tb[Empresas].id)".
				" INNER JOIN $tb[UsuariosEmpresas] ON ($tb[Empresas].id=$tb[UsuariosEmpresas].idEmpresa)".
				" INNER JOIN $tb[EmpresasUsuarios] ON ($tb[UsuariosEmpresas].idEmpresaUsuario=$tb[EmpresasUsuarios].id) ".
			"WHERE ".
				"$tb[Ticket].id='$idTicket' AND ".
				"$tb[EmpresasUsuarios].email <> '' AND ".
				"$tb[EmpresasUsuarios].email IS NOT NULL ".
			"GROUP BY $tb[EmpresasUsuarios].id";
	
	return runQuery( $sql );
}

?>