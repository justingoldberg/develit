<?
################################################################################
#       Criado por: Devel IT
#  Data de cria��o: 18/06/2004
# Ultima altera��o: 22/08/2006
#    Altera��o No.: 005
#
# Fun��o:
#    Fun��es de modelos de formul�rio


/**
 * @return void
 * @param unknown $p1
 * @param unknown $p2
 * @param unknown $matriz
 * @desc Exibe no formato padr�o os dados de data para entrada de dados
 p1 = posicao na tela do mes inicial
 p2 = posicao na tela do mes final
 matriz = matriz de dados para exibir dados padrao
*/
function getPeriodo($p1, $p2, $matriz) {
	
	global $corFundo, $corBorda, $html, $sessLogin;
	
	$data=dataSistema();
	
	novaLinhaTabela($corFundo, '100%');
		itemLinhaTMNOURL('<b>'._("Initial Month/Year:").'</b><br><span class=normal10>'._('Inform the initial month/year for consultation').'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
		$texto="<input type=text name=matriz[dtInicial] size=7 value='$matriz[dtInicial]' onBlur=verificaDataMesAno2(this.value,$p1)>&nbsp;<span class=txtaviso>("._("Format:")." $data[mes]/$data[ano])</span>";
	    itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
	fechaLinhaTabela();
	
	novaLinhaTabela($corFundo, '100%');
		itemLinhaTMNOURL('<b>'._('Final Month/Year:').'</b><br><span class=normal10>'._('Inform the last month/year for consultation').'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
		$texto="<input type=text name=matriz[dtFinal] size=7 value='$matriz[dtFinal]'  onBlur=verificaDataMesAno2(this.value,$p2)>&nbsp;<span class=txtaviso>('._('Format:').' $data[mes]/$data[ano])</span>";
	    itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
	fechaLinhaTabela();
	
}

/**
 * @return void
 * @param unknown $matriz
 * @desc Retorna um botao tipo CONFIRMAR
*/
function getBotaoConfirmar($matriz, $label='') {
	if (empty($label)){
		$label=_("Seek");
	}
	getBotao('matriz[bntConfirmar]', $label);
}# fim do function


/**
 * @return void
 * @param unknown $matriz
 * @desc Monta um botao generico
*/
function getBotao($name, $value) {
	novaLinhaTabela($corFundo, '100%');
		$texto="<input type=submit name=$name value='$value' class=submit>";
		itemLinhaForm($texto, 'center', 'top', $corFundo, 2, 'tabfundo1');
	fechaLinhaTabela();	
}

function getOpcao($modulo, $sub, $opcao, $acao="") {
	switch ($opcao) {
		case 'Adicionar':
			$icone='incluir';
			$acao='adicionar';
			break;
		case 'Procurar':
			$icone='procurar';
			$acao='procurar';
			break;
		case 'Listar':
			$icone='listar';
			$acao='listar';
			break;
		case 'Alterar':
			$icone='alterar';
			$acao='alterar';
			break;
		case 'Ver':
			$icone='ver';
			$acao='ver';
			break;
	}
			
	$texto=htmlMontaOpcao("<br>"._("$opcao"), $icone);
	itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=$acao", 'center', $corFundo, 0, 'normal');
}


/**
 * @return void
 * @param unknown $tipo
 * @param unknown $label
 * @param unknown $name
 * @param unknown $value
 * @param unknown $event
 * @param unknown $forma
 * @param unknown $tamanho
 * @desc Retorna um campo de formulario
*/
function getCampo($tipo, $label, $name="", $value="", $event="", $forma="form", $tamanho=60, $classeCSS="") {
	
	global $corFundo, $corBorda, $html;
	
	if($classeCSS) {
		$opcClassON="<span class=$classeCSS>";
		$opcClassOFF="</span>";
	}
	
	novaLinhaTabela($corFundo, '100%');
		itemLinhaTMNOURL($opcClassON.$label.$opcClassOFF, 'right', 'middle', '40%', $corFundo, 0, 'tabfundo1');
		if($tipo) {
			switch ($tipo) {
				case 'text': 
					$texto="<input type=text name=$name size=$tamanho value='$value' $event>";
					break;
				case 'status': 
					$texto=getComboStatus($value, $name, $forma);
					break;
				case 'hidden':
					$texto="<input type=hidden name=$name value=$value>";
					break;
				case 'sotexto':
					$texto="<font size=12 class=txtAviso>$value</font>";
					break;
				case 'area':
					$texto="<textarea name=$name cols=$tamanho rows=6>$value</textarea>";
					break;
				case 'combo':
					$texto=$value;
					break;
				case 'check':
					if($value) $opcNotificar='checked';
					$texto="<input type='checkbox' name=$name $opcNotificar>";
					break;
			}
			itemLinhaForm($texto, 'left', 'top',  $corFundo, 0, 'tabfundo1');
		}
		else {
			itemLinhaForm($value, 'left', 'middle',  $corFundo,  0, 'tabfundo1');
		}
	fechaLinhaTabela();
}


/**
 * @return unknown
 * @param unknown $item
 * @param unknown $campo
 * @param unknown $retorno
 * @param unknown $tipo
 * @param unknown $tabela
 * @param unknown $coluna
 * @desc Retorna um Select com os dados da tabela
 item = valor para selected
 campo = campo da matriz
 retorno = nome do campo select
 tipo = tipo de select (form, formnochange, multi)
 tabela = tabela a ser consultada
 coluna = nome do campo do banco de dados
 exclusoes = Array com valores a serem desconsiderados
*/
function getSelectDados($item, $campo, $retorno, $tipo, $tabela, $coluna="", $exclusoes="") {
	
	global $conn, $tb, $corFundo, $modulo, $sub;

	if(! $coluna) $coluna='nome';
	if(! $exclusoes) $exclusoes=array();
	
	if(($tipo=='form') || $tipo=='formnochange') {
	
		$consulta=buscaRegistros('','','todos',$coluna, $tabela);
		
		if($consulta && contaConsulta($consulta)>0) {
			
			if ($tipo=='formnochange') $retorno="\n<select name=$retorno>";
			else $retorno="\n<select name=$retorno onChange=javascript:submit();>";
			
			for($i=0;$i<contaConsulta($consulta);$i++) {
			
				$id=resultadoSQL($consulta, $i, 'id');
				if (! in_array($id, $exclusoes)) {
					$nome=resultadoSQL($consulta, $i, $coluna);
				
					if($item==$id) $opcSelect='selected';
					else $opcSelect='';
				
					$retorno.="\n<option value=$id $opcSelect>$nome";
				}
			}
			$retorno.="\n</select>\n";
		}
		else {
			$retorno='';
		}
	}
	elseif($tipo=='multi') {
	
		$consulta=buscaRegistros('','','todos',$coluna, $tabela);
		
		if($consulta && contaConsulta($consulta)>0) {
			
			$retorno="<select multiple size=6 name=matriz[$campo][]>";
			
			for($i=0;$i<contaConsulta($consulta);$i++) {
				
				$id=resultadoSQL($consulta, $i, 'id');
				$nome=resultadoSQL($consulta, $i, $coluna);
				
				if($item==$id) $opcSelect='selected';
				else $opcSelect='';
				
				$retorno.="\n<option value=$id $opcSelect>$coluna";
				
			}
			$retorno.="</select>";
		}
	}
	else {
		$retorno='';
	}
	
	return($retorno);
}



#  Fun��o para mostrar form de sele�ao do STATUS
/**
 * @return unknown
 * @param unknown $valor
 * @param unknown $campo
 * @param unknown $tipo
 * @param unknown $itens
 * @param unknown $labels
 * @desc Retorna um campo Select de form
 valor = valor padrao
 campo = nome do campo
 tipo = tipo de retorno: check ou form
 itens = array com os itens de status A, I, B, C. Default A, I
 labels = array com os labels para os itens
*/
function getComboStatus($valor, $campo="", $tipo, $itens="", $labels="") {
	#define os valores padroes
	if (! $itens) {
		$itens=array('A', 'I');
		$label['A']=_("Active");
		$label['I']=_("Inactive");
	}
	
	#pega os itens do array
	foreach ($itens as $item) 
		if($valor==$item) $opcSelect[$item]='selected';
	
	#form ele poe o controle na tela
	if($tipo=='form') {
		$texto="<select name=$campo>";
		foreach ($itens as $item)
			$texto.="<option value=$item $opcSelect[$item]>$label[$item]\n";
		$texto.="</select>";
	}
	elseif($tipo=='check') {
		if($valor=='A') $texto="<span class=txtok>"._("Active")."</span>";
		elseif($valor=='I') $texto="<span class=txtaviso>"._("Inactive")."</span>";
		elseif($valor=='B') $texto="<span class=txtaviso>"._("Blocked")."</span>";
		elseif($valor=='C') $texto="<span class=txtaviso>"._("Frozen")."</span>";
	}
	
	return($texto);
	
}

function getComboSemana($valor, $campo="matriz[diaSemana]", $tipo="form") {
	
	$semana=array(_('Sunday'), _('Monday'), _('Tuesday'), _('Wednesday'), _('Thursday'), _('Friday'), _('Saturday'));
	
	#form poe o controle na tela
	if($tipo=='form') {
		$texto="<select name=$campo>";
		$p=0;
		foreach ($semana as $item) {
			$texto.="<option value=$p";
			#echo "comparando $semana[$valor]==$item<br>";
			if($semana[$valor]==$item) $texto.=" SELECTED";
			$texto.=">".$semana[$p++]."\n";
		}
		$texto.="</select>";
	}
	elseif($tipo=='check') {
		$texto="<span class=txtok>".$semana[$valor]."</span>";
	}
	
	return($texto);
	
}


function exibeSemPermissao($modulo, $acao) {
	# SEM PERMISS�O DE EXECUTAR A FUN��O
	$msg=_("WARNING: You don't have permission to execute this function");
	$url="?modulo=$modulo&sub=$sub";
	aviso(_("Access Denied"), $msg, $url, 760);
}


function getFormProcurar($modulo, $sub, $acao, $matriz, $titulo) {
	
	global $corFundo, $corBorda, $tb;
	
	novaTabela2("["._("Search")." $titulo]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		
		novaLinhaTabela($corFundo, '100%');
		$texto="<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=$acao>
			<input type=hidden name=registro>";
			itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();
		itemTabelaNOURL('&nbsp;', 'center', $corFundo, 2, 'tabfundo1');
		
		#nome
		getCampo('text', _("Name"), 'matriz[nome]');
		
		#botao
		getBotao('matriz[bntProcurar]', _('Search'));
		
	fechaTabela();
}


function getOpcaoAgendar() {
	
	global $corFundo, $corBorda;
	
	#Dados para o agendamento
	novaLinhaTabela($corFundo, '100%');
		htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo '<b class="bold">'._("Schedule:")."</b><br>
		  <span class=normal10>"._("Open the page for schedule")."</span>";
		htmlFechaColuna();
		$texto='<input type="checkbox" name="matriz[agendar]" value="S" />';
		itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
	fechaLinhaTabela();
}


function getOpcaoRelacionar( $ajax=false ) {

	global $corFundo, $corBorda;
	
	$evento = "";
	if( $ajax ){
		$isIntegratedInvent = verificaIntegracaoTicketInvent();
		$evento = ' onclick="callComboCompany(this,'.($isIntegratedInvent ? 'true' : 'false').')"';
	}
	
	novaLinhaTabela($corFundo, '100%');
		htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo '<b class="bold">'._("Relate Ticket with the Company:")." </b><br />".
			'<span class="normal10">' . _("Select the option to relate this ticket with a company/host") . "</span>\n";
		htmlFechaColuna();
		$texto="<input type=\"checkbox\" name=\"matriz[relacionar]\" value=\"S\"".$evento." />";
		itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
	fechaLinhaTabela();
	if( $ajax ) {
		formRelacionarEmpresa( $ajax );
	}
}

function getOpcaoMaquina(){
	global $corFundo, $corBorda;

	novaTabela2SH( '', 100, 0, 0, 0, $corFundo, '', 0 );
		novaLinhaTabela( $corFundo, '100%' );
			htmlAbreColuna( '40%', 'right', $corFundo, 0, 'tabfundo1' );
				echo "&nbsp;";
			htmlFechaColuna();
				$i=0;
				$texto="<select name=matriz[maquina]>";
				while( $i < contaConsulta($consulta) ) {
						$id=resultadoSQL($consulta, $i, 'id');
						$nome=resultadoSQL($consulta, $i, 'nome');
						$texto.="<option value=$id>$nome";
						# Incrementar contador
						$i++;
				} #fecha laco de montagem de tabela
				$texto.="</select>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();
}

/**
 * Returns a empty combo select
 *
 * @param string $name
 * @param string $event
 * @return string
 */
function getEmptyCombo( $name, $id, $event="" ){
	return '<select name="matriz['.$name.']" id="'.$id.'" '.$event."></select>\n";
}

?>