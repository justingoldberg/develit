<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 15/04/2003
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 004
#
# Fun��o:
#    Painel - Fun��es para cadastro de categorias



# Fun��o para listagem 
function listarCategoriasGrupos($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $limite;

	# Sele��o de registros
	$consulta=buscaCategorias($registro, 'id', 'igual', 'id');
	
	if(!$consulta || contaConsulta($consulta)==0) {
		# Servidor n�o encontrado
		itemTabelaNOURL(_('There are no records!'), 'left', $corFundo, 3, 'txtaviso');
	}
	else {
		# Mostrar Informa��es sobre Servidor
		verCategoria($registro);
		
		$consulta=buscaCategoriasGrupos($registro, 'idCategoria','igual','idCategoria');
		
		# Cabe�alho		
		# Motrar tabela de busca
		novaTabela("["._("Groups of the Category")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 10);
		$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=$acao"."adicionar&registro=$registro>"._("Add")."</a>",'incluir');
		itemTabelaNOURL($opcoes, 'right', $corFundo, 10, 'tabfundo1');
		
		
		# Caso n�o hajam servicos para o servidor
		if(!$consulta || contaConsulta($consulta)==0) {
			# N�o h� registros
			itemTabelaNOURL(_('There are no groups registered for this category'), 'left', $corFundo, 10, 'txtaviso');
		}
		else {
		
			# Cabe�alho
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela(_('Group'), 'center', '25%', 'tabfundo0');
				itemLinhaTabela(_('Admin'), 'center', '5%', 'tabfundo0');
				itemLinhaTabela(_('Include'), 'center', '5%', 'tabfundo0');
				itemLinhaTabela(_('Change'), 'center', '5%', 'tabfundo0');
				itemLinhaTabela(_('Delete'), 'center', '5%', 'tabfundo0');
				itemLinhaTabela(_('See'), 'center', '5%', 'tabfundo0');
				itemLinhaTabela(_('Open'), 'center', '5%', 'tabfundo0');
				itemLinhaTabela(_('Close'), 'center', '5%', 'tabfundo0');
				itemLinhaTabela(_('Comment'), 'center', '5%', 'tabfundo0');
				itemLinhaTabela(_('Options'), 'center', '40%', 'tabfundo0');
			fechaLinhaTabela();

			$i=0;
			
			while($i < contaConsulta($consulta)) {
				# Mostrar registro
				$idGrupo=resultadoSQL($consulta, $i, 'idGrupo');
				
				# Buscar informa��es sobre o servi�o
				$consultaGrupo=buscaGrupos($idGrupo, 'id','igual','id');
				
				# Informa��es sobre grupo
				$idGrupo=resultadoSQL($consultaGrupo, 0, 'id');
				$nome=resultadoSQL($consultaGrupo, 0, 'nome');
				$admin="&nbsp;".resultadoSQL($consultaGrupo, 0, 'admin');
				$incluir="&nbsp;".resultadoSQL($consultaGrupo, 0, 'incluir');
				$alterar="&nbsp;".resultadoSQL($consultaGrupo, 0, 'alterar');
				$excluir="&nbsp;".resultadoSQL($consultaGrupo, 0, 'excluir');
				$visualizar="&nbsp;".resultadoSQL($consultaGrupo, 0, 'visualizar');
				$abrir="&nbsp;".resultadoSQL($consultaGrupo, 0, 'abrir');
				$fechar="&nbsp;".resultadoSQL($consultaGrupo, 0, 'fechar');
				$comentar="&nbsp;".resultadoSQL($consultaGrupo, 0, 'comentar');

				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=$acao".excluir."&registro=$registro:$idGrupo>"._("Delete")."</a>",'excluir');

				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($nome, 'left', '40%', 'normal10');
					itemLinhaTabela($admin, 'center', '5%', 'normal10');
					itemLinhaTabela($incluir, 'center', '5%', 'normal10');
					itemLinhaTabela($alterar, 'center', '5%', 'normal10');
					itemLinhaTabela($excluir, 'center', '5%', 'normal10');
					itemLinhaTabela($visualizar, 'center', '5%', 'normal10');
					itemLinhaTabela($abrir, 'center', '5%', 'normal10');					
					itemLinhaTabela($fechar, 'center', '5%', 'normal10');
					itemLinhaTabela($comentar, 'center', '5%', 'normal10');
					itemLinhaTabela($opcoes, 'center', '20%', 'normal10');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
			
			fechaTabela();
		} #fecha servicos encontrados
	} #fecha listagem

	
}#fecha fun��o de listagem



# Fun��o para busca de Servidor de Servidores
function buscaCategoriasGrupos($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[CategoriasGrupos] ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[CategoriasGrupos] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[CategoriasGrupos] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
} #fecha busca de servi�os por servidor



# Funcao para cadastro de servicos
function adicionarCategoriasGrupos($modulo, $sub, $acao, $registro, $matriz) {

	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Form de inclusao
	if(!$matriz[bntAdicionar]) {

		# Sele��o de registros
		$consulta=buscaCategorias($registro, 'id', 'igual', 'id');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# Servidor n�o encontrado
			itemTabelaNOURL(_('Category not found!'), 'left', $corFundo, 3, 'txtaviso');
		}
		else {
			# Mostrar Informa��es sobre Servidor
			verCategoria($registro);
	
			# Motrar tabela de busca
			novaTabela2("["._("Add")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=registro value=$registro>
					<input type=hidden name=matriz[categoria] value=$registro>
					<input type=hidden name=acao value=$acao>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("Group:")."</b>&nbsp;<br>
						<span class=normal10>"._("Select the group to participate in this category")."</span>";
					htmlFechaColuna();
					$item=formListaGruposCategoria($registro, 'grupo');
					itemLinhaForm($item, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntAdicionar] value="._("Add")." class=submit>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		} # fecha servidor informado para cadastro
	} #fecha form
	elseif($matriz[bntAdicionar]) {
		# Conferir campos
		if($matriz[categoria] && $matriz[grupo]) {
			# Cadastrar em banco de dados
			$grava=dbCategoriasGrupo($matriz, 'incluir');
				
			# Verificar inclus�o de registro
			if($grava) {
				# acusar falta de parametros
				# Mensagem de aviso
				$msg=_("Data Recorded Success full!");
				$url="?modulo=$modulo&sub=$sub&acao=$acao&registro=$registro";
				aviso(_("Warning"), $msg, $url, 760);
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
			$url="?modulo=$modulo&sub=$sub&acao=$acao&registro=$registro";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	}
} # fecha funcao de inclusao de servicos


# Funcao para exclus�o de servicos
function excluirCategoriasGrupos($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;

	$matTMP=explode(":",$registro);
	$matriz[categoria]=$matTMP[0];
	$matriz[grupo]=$matTMP[1];
	
	$consultaGrupo=buscaGrupos($matriz[grupo], 'id', 'igual', 'id');
	$nome=resultadoSQL($consultaGrupo, 0, 'nome');
	
	$consultaCategoriasGrupos=buscaCategoriasGrupos('idCategoria='.$matriz[categoria].' AND idGrupo='.$matriz[grupo], $campo, 'custom', 'idCategoria');
	
	# Form de exclus�o
	if(!$matriz[bntRemover]) {

		# Sele��o de registros
		$consulta=buscaCategorias($matriz[categoria], 'id', 'igual', 'id');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# Servidor n�o encontrado
			itemTabelaNOURL(_('Category not found!'), 'left', $corFundo, 3, 'txtaviso');
		}
		else {
			# Mostrar Informa��es sobre Servidor
			verCategoria($matriz[categoria]);
	
			# Motrar tabela de busca
			novaTabela2("["._("Delete")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=registro value=$registro>
					<input type=hidden name=matriz[categoria] value=$matriz[categoria]>
					<input type=hidden name=matriz[grupo] value=$matriz[grupo]>
					<input type=hidden name=acao value=$acao>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("Group:")."</b>&nbsp;";
					htmlFechaColuna();
					itemLinhaForm($nome, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntRemover] value="._("Remove")." class=submit>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		} # fecha servidor informado para cadastro
	} #fecha form
	elseif($matriz[bntRemover]) {
		# Conferir campos
		if($matriz[grupo] && $matriz[categoria]) {
		
			# Cadastrar em banco de dados
			$grava=dbCategoriasGrupo($matriz, 'excluir');
				
			# Verificar inclus�o de registro
			if($grava) {
				# acusar falta de parametros
				# Mensagem de aviso
				$msg=_("Record deleted Success Full!");
				$url="?modulo=$modulo&sub=$sub&acao=grupos&registro=$matriz[grupo]";
				aviso(_("Warning"), $msg, $url, 760);
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
			$url="?modulo=$modulo&sub=$sub&acao=grupos";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	}
} # fecha funcao de exclus�o




# Fun��o para grava��o em banco de dados
function dbCategoriasGrupo($matriz, $tipo)
{
	global $conn, $tb, $modulo, $sub, $acao;
	
	# Sql de inclus�o
	if($tipo=='incluir') {
		# Verificar se servi�o existe
		$tmpConsulta=buscaCategoriasGrupos("idCategoria='$matriz[categoria]' AND idGrupo='$matriz[grupo]'", $campo, 'custom', 'idCategoria');
		
		# Registro j� existe
		if($tmpConsulta && contaConsulta($tmpConsulta)>0) {
			# Mensagem de aviso
			$msg=_("Record already exists in the database");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: Error when including record"), $msg, $url, 760);
		}
		else {
			$sql="INSERT INTO $tb[CategoriasGrupos] VALUES ('$matriz[categoria]', '$matriz[grupo]')";
		}
	} #fecha inclusao
	
	elseif($tipo=='excluir') {
		# Verificar se servi�o existe
		$tmpConsulta=buscaCategoriasGrupos("idCategoria='$matriz[categoria]' AND idGrupo='$matriz[grupo]'", $campo, 'custom', 'idCategoria');
		
		# Registro j� existe
		if(!$tmpConsulta|| contaConsulta($tmpConsulta)==0) {
			# Mensagem de aviso
			$msg=_("Record doesn't exist in the database");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: Error when changing record"), $msg, $url, 760);
		}
		else {
			$sql="DELETE FROM $tb[CategoriasGrupos] WHERE idCategoria=$matriz[categoria] AND idGrupo=$matriz[grupo]";
		}
	}
	
	
	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
	
} # fecha fun��o de grava��o em banco de dados


# Fun��o para montar campo de formulario
function formListaGruposCategoria($categoria, $campo)
{
	global $conn, $tb;
	
	# Buscar Servi�os de servidor (ja cadastrados)
	$tmpConsulta=buscaCategoriasGrupos($categoria, 'idCategoria','igual','idCategoria');
	
	$consulta=buscaGrupos($texto, $campo, 'todos', 'nome');
	
	$item="<select name=matriz[$campo]>\n";
	
	# Listargem
	$i=0;
	while($i < contaConsulta($consulta)) {
		# Zerar flag de registro j� cadastrado
		$flag=0;
		
		# Valores dos campos
		$nome=resultadoSQL($consulta, $i, 'nome');
		$id=resultadoSQL($consulta, $i, 'id');

		# Verificar se servi�o j� est� cadastrado
		$x=0;
		while($x < contaConsulta($tmpConsulta) ) {
		
			# Verificar
			$idTmp=resultadoSQL($tmpConsulta, $x, 'idGrupo');
			
			if($idTmp == $id) {
				# Setar Flag de registro j� cadastrado
				$flag=1;
				break;
			}

			# Incrementar contador
			$x++;
		}

		if(!$flag) {
			# Mostrar servi�o		
			$item.= "<option value=$id>$nome\n";
		}

		#Incrementar contador
		$i++;
	}
	
	$item.="</select>";
	
	return($item);
	
} #fecha funcao de montagem de campo de form



# Formul�rio para sele��o de usuarios pertencentes aos grupos/categorias do usuario
function formSelectUsuariosGruposCategorias($idUsuario, $campo, $tipo="", $default="") {
	
	global $tb, $conn;
	
	# Selecionar Grupos
	$sql="
		SELECT
			$tb[UsuariosGrupos].idGrupo
		FROM
			$tb[UsuariosGrupos]
		WHERE
			$tb[UsuariosGrupos].idUsuario='$idUsuario'
	";
	
	$consultaGrupos=consultaSQL($sql, $conn);
	
	if($consultaGrupos && contaConsulta($consultaGrupos)>0) {
		
		# Montar lista de grupos
		for($a=0;$a<contaConsulta($consultaGrupos);$a++) {
			$idGrupo=resultadoSQL($consultaGrupos, $a, 'idGrupo');
			
			$sqlGrupos.="$idGrupo";
			
			if(($a+1) < contaConsulta($consultaGrupos)) $sqlGrupos.=",";
		}
	
		# Selecionar Usu�rios
		$sql="
			SELECT
				$tb[Usuarios].login login,
				$tb[Usuarios].id idUsuario
			FROM
				$tb[Grupos], 
				$tb[Usuarios], 
				$tb[UsuariosGrupos], 
				$tb[CategoriasGrupos]
			WHERE  
				$tb[UsuariosGrupos].idUsuario=$tb[Usuarios].id 
				and $tb[UsuariosGrupos].idGrupo = $tb[Grupos].id 
				and $tb[UsuariosGrupos].idGrupo = $tb[CategoriasGrupos].idGrupo 
				and $tb[Grupos].id in ($sqlGrupos)  
			GROUP BY 
				$tb[Usuarios].id";
		
		$consulta=consultaSQL($sql, $conn);
		
		if ($tipo!='change') $retorno="\n<select name=matriz[$campo]>";
		else $retorno="\n<select name=matriz[$campo] onChange=javascript:submit();>";
		
		if($consulta && contaConsulta($consulta)>0) {
			# form de sele��o
			for($a=0;$a<contaConsulta($consulta);$a++) {
				$id=resultadoSQL($consulta, $a, 'idUsuario');
				$login=resultadoSQL($consulta, $a, 'login');
				
				if ($id!=$default)
					$retorno.="<option value='$id'>$login";
				else
					$retorno.="<option value='$id' SELECTED>$login";
			}
		}
		
		$retorno.="</select>";
	}
	
	return($retorno);
}

?>
