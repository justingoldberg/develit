<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 15/04/2003
# Ultima altera��o: 02/08//2005
#    Altera��o No.: 011
#
# Fun��o:
#    P�gina principal (index) da aplica��o

include("relatorios.php");
include("relatorio_totalhoras.php");
include("relatorio_usuariohoras.php");
include("relatorio_clientehoras.php");
include("relatorio_producaohoras.php");

?>