<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 02/08/2005
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 002
#
# Fun��o:
#    Relat�rio de Total de Horas por Cliente


function formRelatorioProducaoHoras($modulo, $sub, $acao, $registro, $matriz) {

	global $corFundo, $corBorda, $sessLogin;
	
	# Permiss�o do usuario
	$permissao=buscaPermissaoUsuario($sessLogin[login],'login','igual','login');
	
	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
		
		$data=dataSistema();
		# Motrar tabela de busca
		novaTabela2("["._("Total Consultation of Produced Hours")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
			$texto="			
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=$acao>";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			itemTabelaNOURL('&nbsp;', 'center', $corFundo, 2, 'tabfundo1');
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL('<b>'._("Initial Day/Month/Year:").'</b><br>
				<span class=normal10>'._("Inform the initial day/month/year for consultation").'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				$texto="<input type=text name=matriz[dtInicial] size=10 value='$matriz[dtInicial]' onBlur=verificaDataDiaMesAno2(this.value,3)>&nbsp;
				<span class=txtaviso>("._("Format:")."&nbsp;".$data[dia]."/".$data[mes]."/".$data[ano].")</span>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL('<b>'._("Last Day/Month/Year:").'</b><br>
				<span class=normal10>'._("Inform the last day/month/year for consultation").'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				$texto="<input type=text name=matriz[dtFinal] size=10 value='$matriz[dtFinal]'  onBlur=verificaDataDiaMesAno2(this.value,4)>&nbsp;
				<span class=txtaviso>("._("Format:")."&nbsp;".$data[dia]."/".$data[mes]."/".$data[ano].")</span>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL('<b>'._("User").':</b><br>
				<span class=normal10>'._("Select the user").'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				$texto=formListaUsuarios($matriz[usuario]);
				if($matriz[usuariotodos]) $opcCheck="checked";
				else $opcCheck="";
				$texto.="&nbsp;<input type=checkbox name=matriz[usuariotodos] value=S $opcCheck>"._("All");
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
		
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL('<b>'._("Generate Report").':</b><br>
				<span class=normal10>'._("Select this option to generate the PDF file").'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				if($matriz[relatorio]) $opcCheck="checked";
				else $opcCheck="";
				$texto="&nbsp;<input type=checkbox name=matriz[relatorio] value=S $opcCheck>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			
			novaLinhaTabela($corFundo, '100%');
				$texto="<input type=submit name=matriz[bntConfirmar] value="._('Seek')." class=submit>";
				itemLinhaForm($texto, 'center', 'top', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
		fechaTabela();
		
		
		if( $matriz[bntConfirmar] && $matriz[dtInicial] && $matriz[dtFinal] ) {
			# Consultar
			relatorioProducaoHoras($modulo, $sub, $acao, $registro, $matriz);
		}
	}
}

function relatorioProducaoHoras($modulo, $sub, $acao, $registro, $matriz) {

	global $corFundo, $corBorda, $html, $sessLogin, $conn, $tb, $limites;
	
	# Formatar Datas
	$matriz[dtInicial]	= formatarData($matriz[dtInicial]);
	$matriz[dtFinal]	= formatarData($matriz[dtFinal]);

	# Cabe�alho
	itemTabelaNOURL('&nbsp;', 'right', $corFundo, 0, 'normal10');
	# Mostrar Cliente
	htmlAbreLinha($corFundo);
		htmlAbreColunaForm('100%', 'center', 'middle', $corFundo, 2, 'normal10');
			
		# Mostrar resultados da consulta
		# Verificar se a consulta de tickets deve ser feita por usuario
		if($matriz[usuariotodos]) {
			$consulta=buscaUsuarios('','','todos','login');
			for($a=0;$a<contaConsulta($consulta);$a++) {
				
				$matriz[usuario]=resultadoSQL($consulta, $a, 'id');
				$usuario=resultadoSQL($consulta, $a, 'login');
				
				novaTabela( _("$usuario"), "left", '100%', 0, 0, 0, $corFundo, $corBorda, 5);
				htmlAbreLinha($corFundo);
					htmlAbreColunaForm('100%', 'center', 'middle', $corFundo, 0, 'normal10');
						relatorioProducaoHorasLOOP($modulo, $sub, $acao, $registro, $matriz);
						if($a<contaConsulta($consulta)-1) echo "<BR>";
					htmlFechaColuna();
				htmlFechaLinha();
			fechaTabela();
			}
		}
		else {
			$consulta=buscaUsuarios($matriz[usuario],'id','igual','login');
			$usuario=resultadoSQL($consulta, $a, 'login');
			novaTabela("$usuario", "left", '100%', 0, 0, 0, $corFundo, $corBorda, 0);
				htmlAbreLinha($corFundo);
					htmlAbreColunaForm('100%', 'center', 'middle', $corFundo, 0, 'normal10');
						relatorioProducaoHorasLOOP($modulo, $sub, $acao, $registro, $matriz);
					htmlFechaColuna();
				htmlFechaLinha();
			fechaTabela();
		}
		htmlFechaColuna();
	htmlFechaLinha();		
}


function relatorioProducaoHorasLOOP($modulo, $sub, $acao, $registro, $matriz) {
	
	global $corFundo, $corBorda, $html, $sessLogin, $conn, $tb, $limites;
	
	# Procedimentos:
	# 1) Formatar as datas para aaaa-mm-dd hh:mm:ss
	# 2) Rotina de consulta
	# 3) Listagem em html e pdf
	
	# 1)
	# Montar o ano-mes-dia 00:00:00
	$dtInicial = substr($matriz[dtInicial],4,4) . "-" . substr($matriz[dtInicial],2,2) . "-" . substr($matriz[dtInicial],0,2) . ' 00:00:00';
	$dtFinal = substr($matriz[dtFinal],4,4) ."-". substr($matriz[dtFinal],2,2) . "-" . substr($matriz[dtFinal],0,2) .' 23:59:59';
	
	# 2)
	$sql="
		SELECT
			$tb[Ticket].id idTicket, 
			$tb[Ticket].protocolo protocolo, 
			$tb[Ticket].assunto titulo, 
			$tb[Usuarios].login, 
			$tb[TicketFinalizacoes].idUsuario, 
			$tb[TicketFinalizacoes].data, 
			$tb[TicketFinalizacoes].segundos segundos, 
			$tb[TicketFinalizacoes].expediente 
		FROM  
			$tb[Ticket] INNER JOIN $tb[TicketFinalizacoes] ON ( $tb[Ticket].id = $tb[TicketFinalizacoes].idTicket )
			INNER JOIN  $tb[Usuarios] ON ( $tb[Usuarios].id = $tb[TicketFinalizacoes].idUsuario )
		WHERE 
			$tb[TicketFinalizacoes].data BETWEEN '$dtInicial' and '$dtFinal' 
			AND $tb[TicketFinalizacoes].segundos != '' 
			AND $tb[TicketFinalizacoes].idUsuario='$matriz[usuario]' 
		
		ORDER BY 
			$tb[Usuarios].login ASC, 
			$tb[TicketFinalizacoes].expediente DESC, 
			$tb[TicketFinalizacoes].data ASC";
	
	$colunasRelatorio = 5;
	
	$matCabecalho = array( _("Protocol"), _("Title"), _("Date"), _("Expedient"), _("Time") );
	$l=0;
	$matrizRelatorio=array();
	
	htmlAbreTabelaSH("left", '100%', 0, 2, 1, $corFundo, $corBorda, 4);
	
	$consulta=consultaSQL($sql, $conn);
	
	if($consulta && contaConsulta($consulta)>0) {
				
		$totalNormal=0;
		$totalExtra=0;
		$totalGeral=0;
		
		# 3)
		
		htmlAbreLinha($corFundo);
			itemLinhaTMNOURL(_('Protocol'), 'center', 'middle', '10%', $corFundo, 0, 'tabfundo0');
			itemLinhaTMNOURL(_('Title'), 'center', 'middle', '40%', $corFundo, 0, 'tabfundo0');
			itemLinhaTMNOURL(_('Date'), 'center', 'middle', '20%', $corFundo, 0, 'tabfundo0');
			itemLinhaTMNOURL(_('Expedient'), 'center', 'middle', '10%', $corFundo, 0, 'tabfundo0');
			itemLinhaTMNOURL(_('Time'), 'center', 'middle', '20%', $corFundo, 0, 'tabfundo0');
		htmlFechaLinha();
				
		for($b=0;$b<contaConsulta($consulta);$b++) {
			
			$idUsuario = resultadoSQL( $consulta, $b, 'idUsuario');
			$idTicket=resultadoSQL($consulta, $b, 'idTicket');
			$usuario = resultadoSQL( $consulta, $b, 'login' );
			$protocolo=resultadoSQL($consulta, $b, 'protocolo');
			$titulo=resultadoSQL($consulta, $b, 'titulo');
			$tituloURL="<a href=?modulo=ticket&acao=ver&registro=$idTicket>" . resultadoSQL($consulta, $b, 'titulo') . "</a>";
			$datatime = resultadoSQL( $consulta, $b, 'data');
			$expediente=resultadoSQL($consulta, $b, 'Expediente');
			$segundos=resultadoSQL($consulta, $b, 'Segundos');
			
			$totalGeral+=$segundos;
			
			if($expediente == 'S') {
				$totalNormal+=$segundos;
			}
			elseif( $expediente == 'N' ) {
				$totalExtra+=$segundos;
			}
			
			$segundosURL="<a href=javascript:novaJanela(\"?modulo=ticket&sub=tempoticket&acao=listar&registro=$idTicket\",\"listatempo$idTicket\",\"width=640,height=600,resizable=No,scrollbars=Yes,title=Atendimento,toolbar=No\")>" . converteData($segundos,'timestamp','formhora') . "</a>";
			
			htmlAbreLinha($corFundo);
				itemLinhaTMNOURL($protocolo, 'left', 'middle', '10%', $corFundo, 0, 'normal10');
				itemLinhaTMNOURL($tituloURL, 'left', 'middle', '40%', $corFundo, 0, 'normal8');
				itemLinhaTMNOURL(converteData($datatime,'banco','form'), 'center', 'middle', '20%', $corFundo, 0, 'normal8');
				itemLinhaTMNOURL($expediente, 'center', 'middle', '10%', $corFundo, 0, 'normal8');
				itemLinhaTMNOURL($segundosURL, 'center', 'middle', '20%', $corFundo, 0, 'normal10');
			htmlFechaLinha();
			
			$c=0;
			$matResultado[$matCabecalho[$c++]][$l]=$protocolo;
			$matResultado[$matCabecalho[$c++]][$l]=$titulo;
			$matResultado[$matCabecalho[$c++]][$l]=converteData($datatime,'banco','form');
			$matResultado[$matCabecalho[$c++]][$l]=$expediente;
			$matResultado[$matCabecalho[$c++]][$l]=converteData($segundos,'timestamp','formhora');
			$l++;
			
		}
		
		# Mostrar sub-Total
		htmlAbreLinha($corFundo);
			itemLinhaTMNOURL(_("Normal Total").':<br>'.("Total Extra").':', 'right', 'middle', '50%', $corFundo, 4, 'bold10');
			$totalNormal=converteData($totalNormal,'timestamp','formhora');
			$totalExtra=converteData($totalExtra,'timestamp','formhora');
			itemLinhaTMNOURL("$totalNormal<br>$totalExtra", 'center', 'middle', '20%', $corFundo, 0, 'bold10');
		htmlFechaLinha();
		
		$c=0;
		$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
		$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
		$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
		$matResultado[$matCabecalho[$c++]][$l]='<b>'._("Normal Total").':<br>'._("Extra Total").':</b>';
		$matResultado[$matCabecalho[$c++]][$l]="<b>$totalNormal<br>$totalExtra</b>";

	}
	else {
		htmlAbreLinha($corFundo);
			itemLinhaTMNOURL("<span class=txtaviso>"._("Records not found")."</span>", 'left', 'middle', '20%', $corFundo, 5, 'bold10');
		htmlFechaLinha();
	}
	
	
	
	# Alimentar Matriz Geral
	$matrizRelatorio[detalhe]=$matResultado;
	
	# Alimentar Matriz de Header
	$matrizRelatorio[header][TITULO]= $usuario . "<br>" . _("Total of Hours by User in the Period")."<br>"."&nbsp;"._("From")."&nbsp;".converteData($dtInicial,'banco','formdata')."&nbsp;". _("until")."&nbsp;".converteData($dtFinal,'banco','formdata');
	$matrizRelatorio[header][POP]=$nomePOP;
	$matrizRelatorio[header][IMG_LOGO]=$html[imagem][logoRelatorio];
	
	# Configura��es
	$matrizRelatorio[config][linhas]=20;
	$matrizRelatorio[config][layout]='landscape';
	
	$matrizGrupo[]=$matrizRelatorio;

	if($matriz[relatorio]=='S' && is_array($matResultado)) {
		# Converter para PDF:
		$arquivo=k_reportHTML2PDF( k_report( $matrizGrupo, 'html', $sub ), "producaohoras-$usuario-".$matriz[dtInicial]."-".$matriz[dtFinal], $matrizRelatorio[config], 'N' );
		# coloca o bot�o
		itemTabelaNOURL(htmlMontaOpcao("<a href=$arquivo>"._("Total Hours for Production")."</a>",'pdf'), 'center', $corFundo, 5, 'txtaviso');
	}
	
	fechaTabela();
}

?>