<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 02/08/2005
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 002
#
# Fun��o:
#    Relatorios

# Relatorios
function relatorios($modulo, $sub, $acao, $registro, $matriz) {
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $sessLogin;

	# Permiss�o do usuario
	$permissao=buscaPermissaoUsuario($sessLogin[login],'login','igual','login');
	
	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
		### Menu principal - usuarios logados apenas
		novaTabela2("["._("Reports")."]", "center", '100%', 0, 3, 1, $corFundo, $corBorda, 4);
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('64%', 'left', $corFundo, 0, 'tabfundo1');
					echo "<br><img src=".$html[imagem][empresa]." border=0 align=left >
					<b class=bold>"._("Reports")."</b>
					<br><span class=normal10>"._("Reports")." $configAppName.</span>";
				htmlFechaColuna();			
				$texto=htmlMontaOpcao("<br>"._("Total Hours for Company"), 'relogio');
				itemLinha($texto, "?modulo=$modulo&sub=clienteshoras", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>"._("Total Hours for User"), 'relogio');
				itemLinha($texto, "?modulo=$modulo&sub=usuarioshoras", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>"._("General Total of Hours"), 'relogio');
				itemLinha($texto, "?modulo=$modulo&sub=totalhoras", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>"._("Total Hours for Production"), 'relogio');
				itemLinha($texto, "?modulo=$modulo&sub=producaohoras", 'center', $corFundo, 0, 'normal');
			fechaLinhaTabela();
		fechaTabela();
		
		if($sub=='clienteshoras') {
			# Menu de modulos
			echo "<br>";
			formRelatorioClienteHoras($modulo, $sub, $acao, $registro, $matriz);	
		}
		elseif( $sub == 'usuarioshoras' ){
			# Menu de modulos
			echo "<br>";
			formRelatorioUsuarioHoras($modulo, $sub, $acao, $registro, $matriz);				
		}
		elseif($sub=='totalhoras') {
			# Menu de modulos
			echo "<br>";
			formRelatorioHoras($modulo, $sub, $acao, $registro, $matriz);	
		}
		elseif($sub=='producaohoras') {
			# Menu de modulos
			echo "<br>";
			formRelatorioProducaoHoras($modulo, $sub, $acao, $registro, $matriz);	
		}

	}
}



?>