<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 02/08/2005
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 002
#
# Fun��o:
#    Relat�rio de Total de Horas por Cliente


function formRelatorioHoras($modulo, $sub, $acao, $registro, $matriz) {

	global $corFundo, $corBorda, $sessLogin;
	
	# Permiss�o do usuario
	$permissao=buscaPermissaoUsuario($sessLogin[login],'login','igual','login');
	
	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
		
		$data=dataSistema();
		# Motrar tabela de busca
		novaTabela2("["._("Consultation of Total General of Hours")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
			$texto="			
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=$acao>";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			itemTabelaNOURL('&nbsp;', 'center', $corFundo, 2, 'tabfundo1');
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL('<b>'._("Initial Day/Month/Year:").'</b><br>
				<span class=normal10>'._("Inform the initial day/month/year for consultation").'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				$texto="<input type=text name=matriz[dtInicial] size=10 value='$matriz[dtInicial]' onBlur=verificaDataDiaMesAno2(this.value,3)>&nbsp;
				<span class=txtaviso>("._("Format:")."&nbsp;".$data[dia]."/".$data[mes]."/".$data[ano].")</span>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL('<b>'._("Last Day/Month/Year:").'</b><br>
				<span class=normal10>'._("Inform the last day/month/year for consultation").'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				$texto="<input type=text name=matriz[dtFinal] size=10 value='$matriz[dtFinal]'  onBlur=verificaDataDiaMesAno2(this.value,4)>&nbsp;
				<span class=txtaviso>("._("Format:")."&nbsp;".$data[dia]."/".$data[mes]."/".$data[ano].")</span>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL('<b>'._('Generate Report').':</b><br>
				<span class=normal10>'._('Select this option to generate the PDF file').'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				if($matriz[relatorio]) $opcCheck="checked";
				else $opcCheck="";
				$texto="&nbsp;<input type=checkbox name=matriz[relatorio] value=S $opcCheck>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			
			novaLinhaTabela($corFundo, '100%');
				$texto="<input type=submit name=matriz[bntConfirmar] value="._('Seek')." class=submit>";
				itemLinhaForm($texto, 'center', 'top', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
		fechaTabela();
		
		
		if($matriz[bntConfirmar] && $matriz[dtInicial] && $matriz[dtFinal]) {
			# Consultar
			relatorioTotalHoras($modulo, $sub, $acao, $registro, $matriz);
		}
	}
}

function relatorioTotalHoras($modulo, $sub, $acao, $registro, $matriz) {

	global $corFundo, $corBorda, $html, $sessLogin, $conn, $tb, $limites;
	
	# Formatar Datas
	
	$matriz[dtInicial]=formatarData($matriz[dtInicial]);
	$matriz[dtFinal]=formatarData($matriz[dtFinal]);
	$dtInicial = substr($matriz[dtInicial],4,4) . "-" . substr($matriz[dtInicial],2,2) . "-" . substr($matriz[dtInicial],0,2) . ' 00:00:00';
	$dtFinal = substr($matriz[dtFinal],4,4) ."-". substr($matriz[dtFinal],2,2) . "-" . substr($matriz[dtFinal],0,2) .' 23:59:59';
	$idStatus = resultadoSQL(consultaSQL("SELECT id FROM status WHERE nome = 'Fechado'", $conn), 0, "id");
	
	# SQL para consulta de emails por dominios do cliente informado
	$sql="
		SELECT 
			Empresas.id,
			Empresas.nome Cliente, 
			ticket_tempo.expediente Expediente, 
			sum(ticket_tempo.segundos) Segundos 
		FROM 
			status,
			processos_ticket,
			ticket,Empresas,
			ticket_empresa,
			ticket_tempo 
		WHERE 
			ticket.id = processos_ticket.idTicket 
			and Empresas.id=ticket_empresa.idEmpresa 
			and ticket_empresa.idTicket = ticket.id 
			and ticket.id = ticket_tempo.idTicket 
			and processos_ticket.idStatus = $idStatus
			and processos_ticket.data between '$dtInicial' and '$dtFinal'
			and Segundos <= 50000
		GROUP BY 
			ticket_tempo.expediente,
			Empresas.id 
		ORDER BY 
			Empresas.nome
	";
	
	$consulta=consultaSQL($sql, $conn);
	
	$matCabecalho=array(_("Customer's Name"),_("Expedient"),_("Hours"));

	# Cabe�alho
	itemTabelaNOURL('&nbsp;', 'right', $corFundo, 0, 'normal10');
	# Mostrar Cliente
	htmlAbreLinha($corFundo);
		htmlAbreColunaForm('100%', 'center', 'middle', $corFundo, 2, 'normal10');
			novaTabela("["._("Results")."]<a name=ancora></a>", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 4);
			
			if( contaConsulta($consulta) == 0) {
				htmlAbreLinha($corFundo);
					itemLinhaTMNOURL("<span class=txtaviso>"._("Records not found")."</span>", 'left', 'middle', '20%', $corFundo, 5, 'bold10');
				htmlFechaLinha();
			}
			
			$l=0;
			$matrizRelatorio=array();
			
			if( contaConsulta($consulta) > 0) {
				htmlAbreLinha($corFundo);
					itemLinhaTMNOURL(_("Customer's Name"), 'center', 'middle', '40%', $corFundo, 0, 'tabfundo0');
					itemLinhaTMNOURL(_("Expedient"), 'center', 'middle', '10%', $corFundo, 0, 'tabfundo0');
					itemLinhaTMNOURL(_("Hours"), 'center nowrap ', 'middle', '15%', $corFundo, 0, 'tabfundo0');
				htmlFechaLinha();
			}
			
			for($b=0;$b<contaConsulta($consulta);$b++) {
				
				$empresa=resultadoSQL($consulta, $b, 'Cliente');
				$expediente=resultadoSQL($consulta, $b, 'Expediente');
				$segundos=resultadoSQL($consulta, $b, 'Segundos');
				
				htmlAbreLinha($corFundo);
					itemLinhaTMNOURL($empresa, 'left', 'middle', '70%', $corFundo, 0, 'normal10');
					itemLinhaTMNOURL($expediente, 'center', 'middle', '10%', $corFundo, 0, 'normal8');
					itemLinhaTMNOURL(converteData($segundos,'timestamp','formhora'), 'center', 'middle', '20%', $corFundo, 0, 'normal10');
				htmlFechaLinha();
				
				$c=0;
				$matResultado[$matCabecalho[$c++]][$l]=$empresa;
				$matResultado[$matCabecalho[$c++]][$l]=$expediente;
				$matResultado[$matCabecalho[$c++]][$l]=converteData($segundos,'timestamp','formhora');
				$l++;
				
			}
			
			# Alimentar Matriz Geral
			$matrizRelatorio[detalhe]=$matResultado;
			
			# Alimentar Matriz de Header
			$matrizRelatorio[header][TITULO]=_("Total General of Hours")."<br>"._("Period")."&nbsp;"."<br>"."&nbsp;"._("From")."&nbsp;".converteData($dtInicial,'banco','formdata')."&nbsp;"._("until")."&nbsp;".converteData($dtFinal,'banco','formdata');
			$matrizRelatorio[header][POP]=$nomePOP;
			$matrizRelatorio[header][IMG_LOGO]=$html[imagem][logoRelatorio];
			
			# Configura��es
			$matrizRelatorio[config][linhas]=30;
			$matrizRelatorio[config][layout]='portrait';
			
			$matrizGrupo[]=$matrizRelatorio;

	
			if($matriz[relatorio]=='S' && is_array($matResultado)) {
				# Converter para PDF:
				$arquivo=k_reportHTML2PDF(k_report($matrizGrupo, 'html','totalhoras'),'totalhoras',$matrizRelatorio[config]);
				# coloca o bot�o
				itemTabelaNOURL(htmlMontaOpcao("<a href=$arquivo>"._("General Total of Hours")."</a>",'pdf'), 'center', $corFundo, 7, 'txtaviso');
			}
			
			fechaTabela();
		
		htmlFechaColuna();
	  htmlFechaLinha();
}

?>