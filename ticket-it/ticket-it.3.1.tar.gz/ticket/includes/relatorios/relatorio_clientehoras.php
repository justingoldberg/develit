<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 02/08/2005
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 002
#
# Fun��o:
#    Relat�rio de Total de Horas por Cliente


function formRelatorioClienteHoras($modulo, $sub, $acao, $registro, $matriz) {

	global $corFundo, $corBorda, $sessLogin;
	
	# Permiss�o do usuario
	$permissao=buscaPermissaoUsuario($sessLogin[login],'login','igual','login');
	
	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
		
		$data=dataSistema();
		# Motrar tabela de busca
		novaTabela2("["._("Total Consultation of Hours by Company")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
			$texto="			
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=$acao>";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			itemTabelaNOURL('&nbsp;', 'center', $corFundo, 2, 'tabfundo1');
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL('<b>'._("Initial Day/Month/Year:").'</b><br>
				<span class=normal10>'._("Inform the initial day/month/year for consultation").'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				$texto="<input type=text name=matriz[dtInicial] size=10 value='$matriz[dtInicial]' onBlur=verificaDataDiaMesAno2(this.value,3)>&nbsp;
				<span class=txtaviso>("._("Format:")."&nbsp;".$data[dia]."/".$data[mes]."/".$data[ano].")</span>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL('<b>'._("Last Day/Month/Year:").'</b><br>
				<span class=normal10>'._("Inform the last day/month/year for consultation").'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				$texto="<input type=text name=matriz[dtFinal] size=10 value='$matriz[dtFinal]'  onBlur=verificaDataDiaMesAno2(this.value,4)>&nbsp;
				<span class=txtaviso>("._("Format:")."&nbsp;".$data[dia]."/".$data[mes]."/".$data[ano].")</span>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL('<b>'._("Company").':</b><br>
				<span class=normal10>'._("Select the company").'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				$texto=formSelectEmpresas($matriz[empresa],'empresa','form');
				if($matriz[empresatodos]) $opcCheck="checked";
				else $opcCheck="";
				$texto.="&nbsp;<input type=checkbox name=matriz[empresatodos] value=S $opcCheck>"._("All");
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
		
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL('<b>'._("Generate Report").':</b><br>
				<span class=normal10>'._("Select this option to generate the PDF file").'</span>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				if($matriz[relatorio]) $opcCheck="checked";
				else $opcCheck="";
				$texto="&nbsp;<input type=checkbox name=matriz[relatorio] value=S $opcCheck>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			
			novaLinhaTabela($corFundo, '100%');
				$texto="<input type=submit name=matriz[bntConfirmar] value="._('Seek')." class=submit>";
				itemLinhaForm($texto, 'center', 'top', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
		fechaTabela();
		
		
		if($matriz[bntConfirmar] && $matriz[dtInicial] && $matriz[dtFinal]) {
			# Consultar
			relatorioClienteHoras($modulo, $sub, $acao, $registro, $matriz);
		}
	}
}

function relatorioClienteHoras($modulo, $sub, $acao, $registro, $matriz) {

	global $corFundo, $corBorda, $html, $sessLogin, $conn, $tb, $limites;
	
	# Formatar Datas
	$matriz[dtInicial]=formatarData($matriz[dtInicial]);
	$matriz[dtFinal]=formatarData($matriz[dtFinal]);

	# Cabe�alho
	itemTabelaNOURL('&nbsp;', 'right', $corFundo, 0, 'normal10');
	# Mostrar Cliente
	htmlAbreLinha($corFundo);
		htmlAbreColunaForm('100%', 'center', 'middle', $corFundo, 2, 'normal10');
			
		# Mostrar resultados da consulta
		# Verificar se a consulta de tickets deve ser feita por empresa
		if($matriz[empresatodos]) {
			$consulta=buscaEmpresas('','','todos','nome');
			for($a=0;$a<contaConsulta($consulta);$a++) {
				
				$matriz[empresa]=resultadoSQL($consulta, $a, 'id');
				$empresa=resultadoSQL($consulta, $a, 'nome');
				
				novaTabela("$empresa", "left", '100%', 0, 0, 0, $corFundo, $corBorda, 5);
				htmlAbreLinha($corFundo);
					htmlAbreColunaForm('100%', 'center', 'middle', $corFundo, 0, 'normal10');
						relatorioClienteHorasLOOP($modulo, $sub, $acao, $registro, $matriz);
						if($a<contaConsulta($consulta)-1) echo "<BR>";
					htmlFechaColuna();
				htmlFechaLinha();
			fechaTabela();
			}
		}
		else {
			$consulta=buscaEmpresas($matriz[empresa],'id','igual','nome');
			$empresa=resultadoSQL($consulta, 0, 'nome');
			novaTabela("$empresa", "left", '100%', 0, 0, 0, $corFundo, $corBorda, 0);
				htmlAbreLinha($corFundo);
					htmlAbreColunaForm('100%', 'center', 'middle', $corFundo, 0, 'normal10');
						relatorioClienteHorasLOOP($modulo, $sub, $acao, $registro, $matriz);
					htmlFechaColuna();
				htmlFechaLinha();
			fechaTabela();

		}			
		htmlFechaColuna();
	htmlFechaLinha();		
}


function relatorioClienteHorasLOOP($modulo, $sub, $acao, $registro, $matriz) {
	
	global $corFundo, $corBorda, $html, $sessLogin, $conn, $tb, $limites;
	
	$colunasRelatorio = (verificaIntegracaoTicketInvent()) ? 4 : 3;	
	htmlAbreTabelaSH("left", '100%', 0, 2, 1, $corFundo, $corBorda, 5);
	$dtInicial = substr($matriz[dtInicial],4,4) . "-" . substr($matriz[dtInicial],2,2) . "-" . substr($matriz[dtInicial],0,2) . ' 00:00:00';
	$dtFinal = substr($matriz[dtFinal],4,4) ."-". substr($matriz[dtFinal],2,2) . "-" . substr($matriz[dtFinal],0,2) .' 23:59:59';

	$matCabecalho=array(_("Host"), _("Protocol"), _("Title"), _("Expedient"), _("Time"));
	$l=0;
	$matrizRelatorio=array();
	$idStatus = resultadoSQL(consultaSQL("SELECT id FROM status WHERE nome = 'Fechado'", $conn), 0, "id");
	
	# SQL para consulta de emails por dominios do cliente informado
	if(verificaIntegracaoTicketInvent()) {
		$sql="
			SELECT 
				ticket.protocolo protocolo, 
				ticket.assunto titulo, 
				ticket.id idTicket, 
				Maquinas.nome maquina, 
				Empresas.id idEmpresa,
				Empresas.nome cliente, 
				ticket_tempo.expediente, 
				sum(ticket_tempo.segundos) segundos 
			FROM 
				processos_ticket
			LEFT JOIN 
				ticket ON (ticket.id = processos_ticket.idTicket)				
			LEFT JOIN				
				ticket_empresa ON (ticket_empresa.idTicket = ticket.id)
			LEFT JOIN 
				Empresas ON (Empresas.id=ticket_empresa.idEmpresa)
			LEFT JOIN 
				ticket_tempo ON (ticket.id = ticket_tempo.idTicket)
			LEFT JOIN 
				Maquinas on (Maquinas.id=ticket_empresa.idMaquina)
			WHERE 
  			    processos_ticket.idStatus = $idStatus
				and processos_ticket.data BETWEEN '$dtInicial' and '$dtFinal'
				and Empresas.id='$matriz[empresa]'
			GROUP BY 
				ticket.id,
				processos_ticket.idTicket,
				ticket_tempo.expediente
			ORDER BY 
				ticket_empresa.idMaquina,
				ticket_tempo.expediente DESC,
				Maquinas.id
		";
	} else {
	$sql="
			SELECT
				ticket.protocolo protocolo, 
				ticket.assunto titulo, 
				ticket.id idTicket, 
				Empresas.id idEmpresa,
				Empresas.nome cliente, 
				ticket_tempo.expediente, 
				sum(ticket_tempo.segundos) segundos 
			FROM 
				processos_ticket,
				ticket,
				Empresas,
				ticket_empresa,
				ticket_tempo
			WHERE 
				ticket.id = processos_ticket.idTicket 
				and Empresas.id=ticket_empresa.idEmpresa 
				and ticket_empresa.idTicket = ticket.id 
				and ticket.id = ticket_tempo.idTicket 
				and processos_ticket.idStatus = $idStatus 
				and processos_ticket.data BETWEEN '$dtInicial' and '$dtFinal'
				and Empresas.id='$matriz[empresa]'
			GROUP BY 
				ticket.id,
				processos_ticket.idTicket,
				ticket_tempo.expediente
			ORDER BY 
				ticket_tempo.expediente DESC
		";	
	}
	$consulta=consultaSQL($sql, $conn);
	
	if($consulta && contaConsulta($consulta)>0) {
		htmlAbreLinha($corFundo);
			if(verificaIntegracaoTicketInvent()) {
				itemLinhaTMNOURL(_("Host"), 'center', 'middle', '20%', $corFundo, 0, 'tabfundo0');
			}
			itemLinhaTMNOURL(_('Protocol'), 'center', 'middle', '10%', $corFundo, 0, 'tabfundo0');
			itemLinhaTMNOURL(_('Title'), 'center', 'middle', '40%', $corFundo, 0, 'tabfundo0');
			itemLinhaTMNOURL(_('Expedient'), 'center', 'middle', '10%', $corFundo, 0, 'tabfundo0');
			itemLinhaTMNOURL(_('Time'), 'center', 'middle', '20%', $corFundo, 0, 'tabfundo0');
		htmlFechaLinha();
		
		$SubtotalNormal=0;
		$SubtotalExtra=0;
		$totalNormal=0;
		$totalExtra=0;
		$totalGeral=0;
		$maquinaAnt='';
		
		for($b=0;$b<contaConsulta($consulta);$b++) {
			
			$idEmpresa=resultadoSQL($consulta, $b, 'idEmpresa');
			$idTicket=resultadoSQL($consulta, $b, 'idTicket');
			$empresa=resultadoSQL($consulta, $b, 'Cliente');
			$protocolo=resultadoSQL($consulta, $b, 'protocolo');
			if(verificaIntegracaoTicketInvent()) {
				itemLinhaTMNOURL(_("Host"), 'center', 'middle', '20%', $corFundo, 0, 'tabfundo0');
			}
			$titulo=resultadoSQL($consulta, $b, 'titulo');
			$tituloURL="<a href=?modulo=ticket&acao=ver&registro=$idTicket>" . resultadoSQL($consulta, $b, 'titulo') . "</a>";
			$expediente=resultadoSQL($consulta, $b, 'Expediente');
			$segundos=resultadoSQL($consulta, $b, 'Segundos');
			
			if(!$maquina || $maquina==NULL) {
				$maquina=_("General Attendance");
			}

			
			$totalGeral+=$segundos;

			if($b>0 && $maquinaAnt != $maquina) {
				
				# Mostrar sub-Total
				if(verificaIntegracaoTicketInvent()) {
					htmlAbreLinha($corFundo);
						itemLinhaTMNOURL(_('Normal Sub-Total').":<br>"._('Extra Sub-Total').':', 'right', 'middle', '50%', $corFundo, 4, 'bold10');

						$SubtotalNormal=converteData($SubtotalNormal,'timestamp','formhora');
						$SubtotalExtra=converteData($SubtotalExtra,'timestamp','formhora');
						itemLinhaTMNOURL("$SubtotalNormal<br>$SubtotalExtra", 'center', 'middle', '20%', $corFundo, 0, 'bold10');
					htmlFechaLinha();
				}
				$c=0;
				$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
				$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
				$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
				$matResultado[$matCabecalho[$c++]][$l]='<b>'._('Normal Sub-Total').":<br>"._('Extra Sub-Total').':</b>';
				$matResultado[$matCabecalho[$c++]][$l]="<b>$SubtotalNormal<br>$SubtotalExtra</b>";
				$l++;
				
				$SubtotalNormal=0;
				$SubtotalExtra=0;
				if($expediente == 'S') {
					$totalNormal+=$segundos;
					$SubtotalNormal+=$segundos;
				}
				if($expediente == 'N') {
					$totalExtra+=$segundos;
					$SubtotalExtra+=$segundos;
				}
			}
			else {
				if($expediente == 'S') {
					$totalNormal+=$segundos;
					$SubtotalNormal+=$segundos;
				}
				if($expediente == 'N') {
					$totalExtra+=$segundos;
					$SubtotalExtra+=$segundos;
				}
			}
			echo "Segundos: $segundos";
			$segundosURL="<a href=javascript:novaJanela(\"?modulo=ticket&sub=tempoticket&acao=listar&registro=$idTicket\",\"listatempo$idTicket\",\"width=640,height=600,resizable=No,scrollbars=Yes,title=Atendimento,toolbar=No\")>" . converteData($segundos,'timestamp','formhora') . "</a>";
			
			htmlAbreLinha($corFundo);
					if(verificaIntegracaoTicketInvent()) {
						itemLinhaTMNOURL($maquina, 'left', 'middle', '20%', $corFundo, 0, 'bold10');
					}
					itemLinhaTMNOURL($protocolo, 'left', 'middle', '10%', $corFundo, 0, 'normal10');
					itemLinhaTMNOURL($tituloURL, 'left', 'middle', '40%', $corFundo, 0, 'normal8');
					itemLinhaTMNOURL($expediente, 'center', 'middle', '10%', $corFundo, 0, 'normal8');
					itemLinhaTMNOURL($segundosURL, 'center', 'middle', '20%', $corFundo, 0, 'normal10');
			htmlFechaLinha();
			
			$c=0;
			if(verificaIntegracaoTicketInvent()) {
				$matResultado[$matCabecalho[$c++]][$l]=$maquina;
			}
			$matResultado[$matCabecalho[$c++]][$l]=$protocolo;
			$matResultado[$matCabecalho[$c++]][$l]=$titulo;
			$matResultado[$matCabecalho[$c++]][$l]=$expediente;
			$matResultado[$matCabecalho[$c++]][$l]=converteData($segundos,'timestamp','formhora');
			$l++;
			
			if( ($b+1) == contaConsulta($consulta) ) {
					
				# Mostrar sub-Total
				if(verificaIntegracaoTicketInvent()) {
					htmlAbreLinha($corFundo);
						itemLinhaTMNOURL(_('Normal Sub-Total').":<br>"._('Extra Sub-Total').':', 'right', 'middle', '50%', $corFundo, 4, 'bold10');
	
						$SubtotalNormal=converteData($SubtotalNormal,'timestamp','formhora');
						$SubtotalExtra=converteData($SubtotalExtra,'timestamp','formhora');
						itemLinhaTMNOURL("$SubtotalNormal<br>$SubtotalExtra", 'center', 'middle', '20%', $corFundo, 0, 'bold10');
					htmlFechaLinha();
				}
				$c=0;
				$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
				$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
				$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
				$matResultado[$matCabecalho[$c++]][$l]='<b>'._('Normal Sub-Total').":<br>"._('Extra Sub-Total').':</b>';
				$matResultado[$matCabecalho[$c++]][$l]="<b>$SubtotalNormal<br>$SubtotalExtra</b>";
				$l++;
				
			}
			
			$maquinaAnt=$maquina;
			
		}
		
		# Mostrar sub-Total
		htmlAbreLinha($corFundo);
			itemLinhaTMNOURL(_('Normal Total').':<br>'.('Total Extra').':', 'right', 'middle', '50%', $corFundo, 4, 'bold10');

			$totalNormal=converteData($totalNormal,'timestamp','formhora');
			$totalExtra=converteData($totalExtra,'timestamp','formhora');
			itemLinhaTMNOURL("$totalNormal<br>$totalExtra", 'center', 'middle', '20%', $corFundo, 0, 'bold10');
		htmlFechaLinha();
		
		$c=0;
		$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
		$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
		$matResultado[$matCabecalho[$c++]][$l]='&nbsp;';
		$matResultado[$matCabecalho[$c++]][$l]='<b>'._('Normal Total').':<br>'._('Extra Total').':</b>';
		$matResultado[$matCabecalho[$c++]][$l]="<b>$totalNormal<br>$totalExtra</b>";
	}
	else {
		htmlAbreLinha($corFundo);
			itemLinhaTMNOURL("<span class=txtaviso>"._("Records not found")."</span>", 'left', 'middle', '20%', $corFundo, 5, 'bold10');
		htmlFechaLinha();
	}
	
	
	
	# Alimentar Matriz Geral
	$matrizRelatorio[detalhe]=$matResultado;
	
	# Alimentar Matriz de Header
	$matrizRelatorio[header][TITULO]=$empresa . "<br>" . _("Total of Hours by Company in the Period")."<br>"."&nbsp;"._("From")."&nbsp;".converteData($dtInicial,'banco','formdata')."&nbsp;". _("until")."&nbsp;".converteData($dtFinal,'banco','formdata');
	$matrizRelatorio[header][POP]=$nomePOP;
	$matrizRelatorio[header][IMG_LOGO]=$html[imagem][logoRelatorio];
	
	# Configura��es
	$matrizRelatorio[config][linhas]=20;
	$matrizRelatorio[config][layout]='landscape';
	
	$matrizGrupo[]=$matrizRelatorio;

	if($matriz[relatorio]=='S' && is_array($matResultado)) {
		# Converter para PDF:
		$arquivo=k_reportHTML2PDF(k_report($matrizGrupo, 'html',$sub),$sub.$matriz[empresa],$matrizRelatorio[config]);
		# coloca o bot�o
		itemTabelaNOURL(htmlMontaOpcao("<a href=$arquivo>"._("Total Hours for Company")."</a>",'pdf'), 'center', $corFundo, 7, 'txtaviso');
	}
	
	fechaTabela();
}

?>