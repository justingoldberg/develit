<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 10/04/2003
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 005
#
# Fun��o:
#    P�gina principal (index) da aplica��o - formul�rios

# Fun��o para alimentar valores de formul�rio
function alimentaForm($matriz, $sessCadastro) {
        # Alimentar sess��o (retornar valor) com dados de formul�rio alterados


        # Alimentar Sess�o com vari�veis j� contidas
        if(is_array($sessCadastro)) $keys=array_keys($sessCadastro);

        for($i=0;$i<count($keys);$i++) {
                $tmpVariavel[$keys[$i]]=$sessCadastro[$keys[$i]];
        }


        # Alimentar vari�vel para retorno
        if($matriz) {
                $keys=array_keys($matriz);
                for($i=0;$i<count($keys);$i++) {
                        # alimentar vari�vel
                        #echo "gravando: $keys[$i]\n<br>";
                        if($keys[$i]=='cpf') $tmpVariavel[$keys[$i]]=cpfFormatar($matriz[$keys[$i]]);
                        if($keys[$i]=='cnpj') $tmpVariavel[$keys[$i]]=cnpjFormatar($matriz[$keys[$i]]);
                        elseif($keys[$i]=='nome') $tmpVariavel[$keys[$i]]=formatarString($matriz[$keys[$i]],'maiuscula');
                        else $tmpVariavel[$keys[$i]]=$matriz[$keys[$i]];
                }
        }


        # retornar valor
        return($tmpVariavel);

} # fecha funcao de alimenta��o de sessao



# Fun��o para alimentar valores de formul�rio
function visualizaForm($matriz) {
        # Alimentar sess��o (retornar valor) com dados de formul�rio alterados

        $keys=array_keys($matriz);

        # Alimentar vari�vel para retorno
        for($i=0;$i<count($keys);$i++) {
                # alimentar vari�vel
                echo _("Viewing:")." $keys[$i]: ".$matriz[$keys[$i]]."\n<br>";
        }

} # fecha funcao de alimenta��o de sessao


# Calcular Totais
function calculaTotal($consulta, $campo, $limite, $decimal) {

        for($i=0;$i<$limite;$i++) {
                $retorno+=resultadoSQL($consulta, $i, $campo);
        }

        if($decimal) {
                $retorno=number_format($retorno,$decimal,',','.');
        }

        return($retorno);
}


# Calcular Totais
function calculaTotalDesconto($consulta, $valor, $desconto, $limite, $decimal) {

        for($i=0;$i<$limite;$i++) {
                $tmpValor=resultadoSQL($consulta, $i, $valor);
                $tmpDesconto=resultadoSQL($consulta, $i, $desconto);
                $retorno+=$tmpValor-($tmpValor*($tmpDesconto/100));
        }

        if($decimal) {
                $retorno=number_format($retorno,$decimal,',','.');
        }

        return($retorno);
}


# Calcular Totais
function calculaDesconto($consulta, $valor, $desconto, $limite, $decimal) {

        for($i=0;$i<$limite;$i++) {
                $tmpValor=resultadoSQL($consulta, $i, $valor);
                $tmpDesconto=resultadoSQL($consulta, $i, $desconto);
                $retorno+=($tmpValor*($tmpDesconto/100));
        }

        if($decimal) {
                $retorno=number_format($retorno,$decimal,',','.');
        }

        return($retorno);
}



# Verifica formato informado para CPF
function formFormatarDoc($doc) {

                $doc=str_replace(".","",$doc);
                $doc=str_replace("-","",$doc);
                $doc=str_replace("/","",$doc);
                $doc=str_replace("\\","",$doc);

                return($doc);
}




# Fun��o para convers�o de valores de formul�rio
function formFormatarString($texto, $tipo){

        # Converter acentua��o para mai�scula
        $matMinuscula=array('�'
        ,'�','�','�','�','�'
        ,'�','�','�','�'
        ,'�','�','�','�'
        ,'�','�','�','�','�'
        ,'�','�','�','�');

        $matMaiuscula=array('�'
        ,'�','�','�','�','�'
        ,'�','�','�','�'
        ,'�','�','�','�'
        ,'�','�','�','�','�'
        ,'�','�','�','�');


        if($tipo=='minuscula') {
                # Converter para mai�scula
                $texto=strtolower($texto);
                for($i=0;$i<count($matMinuscula);$i++) {
                        $texto=str_replace($matMinuscula[$i], $matMaiuscula[$i], $texto);
                }
        }
        elseif($tipo=='maiuscula') {
                # Converter para mai�scula
                $texto=strtoupper($texto);
                for($i=0;$i<count($matMinuscula);$i++) {
                        $texto=str_replace($matMinuscula[$i], $matMaiuscula[$i], $texto);
                }
        }

        return($texto);
}

# Fun��o para montar select de cores
function formSelectCor ($selected,$campo) {
        global $cores;
        $texto="<select name=matriz[$campo]>";
        while(list($key, $value) = each($cores)) {
                if($value == $selected) {
                        $texto.="<option value=$value selected>"._("$key")."</option>";
                } else {
                        $texto.="<option value=$value>"._("$key")."</option>";
                }
        }
        $texto.="</select>";
        return($texto);
}

# Fun��o para montar select de n�meros/prioridades
function formSelectNumeros ($selected,$campo) {
        $texto="<select name=matriz[$campo]>";
        for($i=0;$i<10;$i++) {
                if($i == $selected) {
                        $texto.="<option value=$i selected>$i</option>";
                } else {
                        $texto.="<option value=$i>$i</option>";
                }
        }
        $texto.="</select>";
        return($texto);
}

# Fun��o para montar select de n�meros/prioridades
function formSelectLetras ($selected,$campo) {
        $texto="<select name=matriz[$campo]>";
        for($i="A";$i<="Z" && strlen($i)==1;$i++) {
                if($i == $selected) {
                        $texto.="<option value=$i selected>$i</option>";
                } else {
                        $texto.="<option value=$i>$i</option>";
                }
        }
        $texto.="</select>";
        return($texto);
}


# Fun��o para form de sele��o de alinhamento (Direita / Esquerda)
function formSelectPosicaoDirEsq($posicao, $campo) {
	
	if($posicao) {
		if($posicao == 'D') $opcDireita='selected';
		elseif($posicao == 'E') $opcEsquerda='selected';
		elseif($posicao == 'I') $opcIcone='selected';
		elseif($posicao == 'L') $opcLinha='selected';
	}
	
	$texto="<select name=matriz[$campo]>\n";
	$texto.="<option value=D $opcDireita>"._("Right")."\n";
	$texto.="<option value=E $opcEsquerda>"._("Left")."\n";
	$texto.="<option value=I $opcIcone>"._("Icon")."\n";
	$texto.="<option value=L $opcLinha>"._("Line")."\n";
	$texto.="</select>";
	
	return($texto);
	
}

# Fun��o para form de sele��o de alinhamento (Direita / Esquerda)
function formSelectPosicaoDireitaEsquerda($posicao, $campo) {
	
	if($posicao) {
		if($posicao == 'D') $opcDireita='selected';
		elseif($posicao == 'E') $opcEsquerda='selected';
	}
	
	$texto="<select name=matriz[$campo]>\n";
	$texto.="<option value=D $opcDireita>"._("Right")."\n";
	$texto.="<option value=E $opcEsquerda>"._("Left")."\n";
	$texto.="</select>";
	
	return($texto);
	
}


#  Fun��o para mostrar form de sele�ao Sim/N�o
function formSelectSimNao($valor, $campo, $tipo) {

	if($valor=='S') $opcSelectSim='selected';
	if($valor=='N') $opcSelectNao='selected';
	
	if($tipo=='form') {
		$texto="<select name=matriz[$campo]>
			<option value=S $opcSelectSim>"._("Yes")."\n
			<option value=N $opcSelectNao>"._("No")."\n
		</select>";
	}
	elseif($tipo=='check') {
		if($valor=='S') $texto="<input type=hidden name=matriz[$campo] value='$valor'><span class=txtok>"._("Yes")."</span>";
		elseif($valor=='N') $texto="<span class=txtcheck>"._("No")."</span>";
	}
	
	return($texto);
	
}



#  Fun��o para mostrar form de sele�ao Sim/N�o
function formSelectOrdem($valor, $campo, $tipo) {

	if($valor=='A') $opcSelectAsc='selected';
	if($valor=='D') $opcSelectDesc='selected';
	
	if($tipo=='form') {
		$texto="<select name=matriz[$campo]>
			<option value=A $opcSelectAsc>"._("Crescent")."\n
			<option value=D $opcSelectDesc>"._("Decreasing")."\n
		</select>";
	}
	elseif($tipo=='check') {
		if($valor=='A') $texto="<span class=txtok>"._("Crescent")."</span>";
		elseif($valor=='D') $texto="<span class=txtcheck>"._("Decreasing")."</span>";
	}
	
	return($texto);
	
}


# Icone do ticket
/**
 * @return icone de ticket
 * @param $usuario
 * @param $idUsuario 
 * @desc Montar Icone do ticket
   <b>usuario</b> id do usuario da sessLogin
   <b>idUsuario</b> idUsuario do ticket
*/
function iconeTicket($usuario, $idUsuario, $idTicket=0) {

	global $html;
	
	if(buscaIDUsuario( 'guest', 'login', 'igual', 'id' ) == $idUsuario) {
		$imagem=$html[imagem][help];
		$alt=_("External Ticket");
	}
	elseif($usuario == $idUsuario) {
		$imagem=$html[imagem][usuario];
		$alt=_("My Ticket");
	}
	else {
		$imagem=$html[imagem][grupo];
		$alt=_("Another user's Ticket");
	}
	
	if($idTicket>0) {
		# Verificar ultimo coment�rio do ticket
		# e caso usu�rio do coment�rio != $idusuario
		# utilizar novo icone
		$comentarioTicket=buscaUltimoComentarioTicket($idTicket);
		if($comentarioTicket[idUsuario]>0 && $comentarioTicket[idUsuario] != $usuario) $imagem=$html[imagem][alerta];
	}

	$retorno="<img src=".$imagem." border=0 title='$alt'>";

	return($retorno);
}



#  Fun��o para mostrar form de sele�ao Sim/N�o
function formSelectStatus($valor, $campo, $tipo) {

	if($valor=='A') $opcSelectAtivo='selected';
	if($valor=='I') $opcSelectInativo='selected';
	if($valor=='C') $opcSelectCancelado='selected';
	
	if($tipo=='form') {
		$texto="<select name=matriz[$campo]>
			<option value=A $opcSelectAtivo class=txtok>"._("Activated")."\n
			<option value=I $opcSelectInativo class=txtaviso>"._("Inactive")."\n
			<option value=C $opcSelectCancelado class=txtaviso>"._("Canceled")."\n
		</select>";
	}
	elseif($tipo=='check') {
		if($valor=='A') $texto="<span class=txtok>"._("Active")."</span>";
		elseif($valor=='I') $texto="<span class=txtaviso>"._("Inactive")."</span>";
		elseif($valor=='C') $texto="<span class=txtaviso>"._("Canceled")."</span>";
	}
	
	return($texto);
	
}

/**
 * Open a HTML form.
 *
 * @since 2007-04-20
 * @author Nash
 * @param string $module
 * @param string $action
 * @param string $record
 * @param string $sub
 * @param string $hiddenFields
 * @param string $name
 * @param string $method
 */
function openForm( $module, $action, $record, $sub="", $hiddenFields="", $name="matriz", $method="post" ){
	echo "<form method=\"$method\" name=\"$name\" action=\"index.php\">\n".
		"<input type=\"hidden\" name=\"modulo\"	  value=\"$module\" />\n".
		"<input type=\"hidden\" name=\"sub\" 	  value=\"$sub\" />\n".
		"<input type=\"hidden\" name=\"acao\" 	  value=\"$action\" />\n".
		"<input type=\"hidden\" name=\"registro\" value=\"$record\" />\n".
		"$hiddenFields\n";
}

/**
 * Closes a HTML form.
 * 
 * @since 2007-04-20
 * @author Nash
 */
function closeForm(){
	echo "</form>";
}

/**
 * Return a submit form button.
 *
 * @author Nash
 * @since 2007-04-20
 * @param string $name = button id
 * @param string $value = value and label
 * @param string $class = css style
 * @return string
 */
function getSubmit( $name, $value, $class="submit" ){
	return "<input type=\"submit\" name=\"matriz[$name]\" value=\"$value\" class=\"$class\" />";
}

/**
 * Return a form button.
 *
 * @author Nash
 * @since 2007-04-20
 * @param string $name = button id
 * @param string $value = value and label
 * @param string $class = css style
 * @return string
 */
function getButton( $name, $value, $event, $class="submit" ){
	return "<input type=\"button\" name=\"matriz[$name]\" value=\"$value\" ".$event." class=\"$class\" />";
}

/**
 * Returns a hiden field
 *
 * @author Nash
 * @since 2007-04-24
 * @param string $name
 * @param string $value
 * @return string
 */
function getHiddenField( $name, $value ){
	return "<input type=\"hidden\" name=\"matriz[$name]\" value=\"$value\" />";
}

?>