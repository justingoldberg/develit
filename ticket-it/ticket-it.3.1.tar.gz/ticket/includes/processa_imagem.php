<?
	/**
	 * @desc processa_imagem.php - Programa respons�vel por gerar a imagem de valida��o (CAPTCHA)
	 * @author Felipe dos S. Assis
	 * @since 27/05/2008
	 * @version 1.0.0
	 */
	
	#invoca a classe a classe captcha
	require_once("../class/captcha.php");
	
	# Definindo fontes a serem implementadas
	$fontes = array('../config/fonts/VeraBd.ttf', '../config/fonts/VeraIt.ttf', '../config/fonts/Vera.ttf');
	
	# Criando inst�ncia do objeto PhpCaptcha
	$imgCaptcha = new PhpCaptcha($fontes, 200, 60);
	
	#Attribuindo propriedades
	$imgCaptcha->SetNumChars(5);
	$imgCaptcha->SetBackgroundImages("../imagens/fundo_captcha.jpg");
	$imgCaptcha->UseColour(true);
	$imgCaptcha->SetMaxFontSize(25);
	$imgCaptcha->SetMinFontSize(16);
	
	$imgCaptcha->Create();
	
?>