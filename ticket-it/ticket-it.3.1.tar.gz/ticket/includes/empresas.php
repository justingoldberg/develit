<?

################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 10/01/2005
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 006
#
# Fun��o:
#    Painel - Fun��es para cadastro

# Fun��o para cadastro
function empresas($modulo, $sub, $acao, $registro, $matriz) {

	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $sessLogin;

	# Permiss�o do usuario
	$permissao = buscaPermissaoUsuario($sessLogin[login], 'login', 'igual', 'login');

	if (!$permissao[admin] && !$permissao[visualizar]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg = _("WARNING: You don't have permission to execute this function");
		$url = "?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	} else {
		# Topo da tabela - Informa��es e menu principal do Cadastro
		novaTabela2("[" . _("Cadaster of Companies") . "]", "center", '100%', 0, 3, 1, $corFundo, $corBorda, 4);
		novaLinhaTabela($corFundo, '100%');
		htmlAbreColuna('65%', 'left', $corFundo, 0, 'tabfundo1');
		echo "<br><img src=" . $html[imagem][cadastro] . " border=0 align=left><b class=bold>" . _("Companies") . "</b>
							<br><span class=normal10>" . _("Cadaster of") . "&nbsp;<b>" . _("companies") . "</b>" . "&nbsp;" .
		_("and control of relationship host/companies") . ".</span>";
		htmlFechaColuna();
		$texto = htmlMontaOpcao("<br>" . _("Add"), 'incluir');
		itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=adicionar", 'center', $corFundo, 0, 'normal');
		$texto = htmlMontaOpcao("<br>" . _("Search"), 'procurar');
		itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=procurar", 'center', $corFundo, 0, 'normal');
		$texto = htmlMontaOpcao("<br>" . _("List"), 'listar');
		itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=listar", 'center', $corFundo, 0, 'normal');
		fechaLinhaTabela();
		fechaTabela();

		if ($sub == 'empresas') {
			# Inclus�o
			if ($acao == "adicionar") {
				echo "<br>";
				adicionarEmpresas($modulo, $sub, $acao, $registro, $matriz);
			}

			# Altera��o
			elseif ($acao == "alterar") {
				echo "<br>";
				alterarEmpresas($modulo, $sub, $acao, $registro, $matriz);
			}

			# Exclus�o
			elseif ($acao == "excluir") {
				echo "<br>";
				excluirEmpresas($modulo, $sub, $acao, $registro, $matriz);
			}

			# Listar / Buscar
			elseif ($acao == "listar" || $acao == 'procurar' || !$acao) {
				echo "<br>";
				procurarEmpresas($modulo, $sub, $acao, $registro, $matriz);
			} #fecha listagem de servicos

			# Detalhes
			elseif ($acao == 'detalhes') {
				echo "<br>";
				verEmpresa($modulo, $sub, $acao, $registro, $matriz);
			}
		}
	}
} #fecha menu principal 

# fun��o de busca 
function buscaEmpresas($texto, $campo, $tipo, $ordem) {
	global $conn, $tb, $corFundo, $modulo, $sub;

	if ($tipo == 'todos') {
		$sql = "SELECT * FROM $tb[Empresas] ORDER BY $ordem";
	}
	elseif ($tipo == 'contem') {
		$sql = "SELECT * from $tb[Empresas] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif ($tipo == 'igual') {
		$sql = "SELECT * from $tb[Empresas] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif ($tipo == 'custom') {
		$sql = "SELECT * from $tb[Empresas] WHERE $texto ORDER BY $ordem";
	}
	# Verifica consulta
	if ($sql) {
		$consulta = consultaSQL($sql, $conn);
		# Retornvar consulta
		return ($consulta);
	} else {
		# Mensagem de aviso
		$msg = _("Consultation cannot be accomplished by lack of parameters");
		$url = "?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}

} # fecha fun��o de busca

# Funcao para cadastro 
function adicionarEmpresas($modulo, $sub, $acao, $registro, $matriz) {
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;

	# Form de inclusao
	if (!$matriz[bntAdicionar] || !$matriz[nome] || (!$matriz[idPessoaTipo] && $matriz[bntSelecionar])) {
		# Motrar tabela de busca
		novaTabela2("[" . _("Add") . "]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		# Opcoes Adicionais
		menuOpcAdicional($modulo, $sub, $acao, $registro);
		#fim das opcoes adicionais
		novaLinhaTabela($corFundo, '100%');
		$texto = "			
						<form method=post name=matriz action=index.php>
						<input type=hidden name=modulo value=$modulo>
						<input type=hidden name=sub value=$sub>
						<input type=hidden name=acao value=$acao>
						<input type=hidden name=registro value=$registro>&nbsp;
						";
		itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();

		if (verificaIntegracaoTicketIsp()) {

			novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b class=bold10>" . _("Company:") . " </b><br>
									<span class=normal10>" . _("Name of the Company") . "</span>";
			htmlFechaColuna();

			itemLinhaForm(formSelectAddPessoaTipo($matriz[idPessoaTipo], 'idPessoaTipo', 'form', 4), 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela('<input type=text name=');
		}

		if ($matriz[idPessoaTipo] || !verificaIntegracaoTicketIsp()) {
			novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b class=bold10>" . _("Name:") . " </b><br>
									<span class=normal10>" . _("Name of the Company") . "</span>";
			htmlFechaColuna();
			if ($matriz[idPessoaTipo])
				$matriz[nome] = formSelectAddPessoaTipo($matriz[idPessoaTipo], '', 'check');
			$texto = "<input type=text name=matriz[nome] size=60 value='$matriz[nome]'>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();

			novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b class=bold10>" . _("Domain:") . " </b><br>
									<span class=normal10>" . _("Company's Domain") . "</span>";
			htmlFechaColuna();
			$texto = "<input type=text name=matriz[dominio] size=30 value='$matriz[dominio]'>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();

			novaLinhaTabela($corFundo, '100%');
			$texto = "<input type=submit name=matriz[bntAdicionar] value=" . _("Add") . " class=submit>
										</form>";
			itemLinhaForm($texto, 'center', 'top', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
		} else {
			novaLinhaTabela($corFundo, '100%');
			$texto = "<input type=submit name=matriz[bntSelecionar] value=" . _("Select") . " class=submit>
										</form>";
			itemLinhaForm($texto, 'center', 'top', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
		}
		fechaTabela();
	} #fecha form
	elseif ($matriz[bntAdicionar]) {
		//	if($matriz[bntAdicionar]) {		//fiz uma copia
		# Conferir campos
		if ($matriz[nome]) {
			# Buscar por prioridade
			# Cadastrar em banco de dados
			$grava = dbEmpresa($matriz, 'incluir');

			# Verificar inclus�o de registro
			if ($grava) {
				# acusar falta de parametros
				# Mensagem de aviso
				$msg = _("Data Recorded Success full!");
				$url = "?modulo=$modulo&sub=$sub&acao=$acao";
				avisoNOURL(_("Warning"), $msg, 400);
			}
			echo "<br>";
			procurarEmpresas($modulo, $sub, 'listar', $matriz[id], '');

		}

		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg = _("Lack of necessary parameters.") . "&nbsp;" . _("Fill the required fields and try again ");
			$url = "?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	}

} # fecha funcao de inclusao

# Fun��o para grava��o em banco de dados
function dbEmpresa($matriz, $tipo) {

	global $conn, $tb, $modulo, $sub, $acao;

	# Sql de inclus�o
	if ($tipo == 'incluir') {
		$sql = "INSERT INTO $tb[Empresas] VALUES (0,
				'$matriz[idPessoaTipo]',
				'$matriz[nome]',
				'$matriz[dominio]',
				'A',
				'N'
				)";
	} #fecha inclusao

	elseif ($tipo == 'excluir') {
		$sql = "UPDATE $tb[Empresas] SET status='C' WHERE id=$matriz[id]";
	}

	# Alterar
	elseif ($tipo == 'alterar') {
		# Verificar se prioridade existe
		$sql = "
					UPDATE 
						$tb[Empresas] 
					SET 
						nome='$matriz[nome]',
						dominio='$matriz[dominio]',
						status='$matriz[status]'
					WHERE 
						id=$matriz[id]";
	}
	elseif ($tipo == 'consultar') {
		#consulta empresas cadastradas no sistema
		$sql = "SELECT id, nome FROM $tb[Empresas] ORDER BY nome";
	}
	elseif($tipo == 'verificaBloqueio'){
		$sql = "SELECT bloqueio FROM $tb[Empresas] WHERE id=$matriz[empresa]";
	}

	if ($sql) {
		$retorno = consultaSQL($sql, $conn);
		return ($retorno);
	}

} # fecha fun��o de grava��o em banco de dados

# Fun��o para procura de servi�o
function procurarEmpresas($modulo, $sub, $acao, $registro, $matriz) {
	global $conn, $tb, $corFundo, $corBorda, $html, $limite, $textoProcurar;

	# Atribuir valores a vari�vel de busca
	if ($textoProcurar) {
		$matriz[bntProcurar] = 1;
		$matriz[txtProcurar] = $textoProcurar;
	} #fim da atribuicao de variaveis

	# Motrar tabela de busca
	novaTabela2("[" . _("Search") . "]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
	novaLinhaTabela($corFundo, '100%');
	htmlAbreColuna('30%', 'right', $corFundo, 0, 'tabfundo1');
	echo "<b>" . _("Search for:") . "</b>";
	htmlFechaColuna();
	$texto = "
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=procurar>
				<input type=hidden name=nulo value=nulo>
				<input type=text name=matriz[txtProcurar] size=40 value='$matriz[txtProcurar]'>
				<input type=submit name=matriz[bntProcurar] value=" . _("Search") . " class=submit>
				";
	itemLinhaForm($texto, 'left', 'middle', $corFundo, 0, 'tabfundo1');
	fechaLinhaTabela();
	fechaTabela();

	# Caso bot�o procurar seja pressionado
	if (($matriz[txtProcurar] && $matriz[bntProcurar]) || $acao == 'listar' || !$acao) {
		#buscar registros
		if ($acao == 'listar' || !$acao)
			$consulta = buscaEmpresas('', '', 'todos', 'nome ASC');
		else
			$consulta = buscaEmpresas("upper(nome) like '%$matriz[txtProcurar]%'", $campo, 'custom', 'nome');
		//echo "consulta:"; print_r($consulta);echo"<br>";
		//		$integrado = ( ( contaConsulta($consulta) && verificaIntegracaoTicketInvent() ) ? 1 : 0 );
		//if ($integrado == 0){
		//	echo "Nao integrado<br>";
		//}
		echo "<br>";
		novaTabela("[" . _("Results") . "]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);

		//		if ( $integrado == 0 ){
		if (!$consulta || contaConsulta($consulta) == 0) {
			# N�o h� registros
			itemTabelaNOURL(_('No record found'), 'left', $corFundo, 4, 'txtaviso');
		}
		elseif ($consulta && contaConsulta($consulta) > 0 && (!$registro || is_numeric($registro))) {

			if ($acao != 'listar' && $acao)
				itemTabelaNOURL(_('Found records looking for') . ' (' . $matriz[txtProcurar] . '): ' . contaConsulta($consulta) . "&nbsp;" . _('record(s)'), 'left', $corFundo, 4, 'txtaviso');

			# Paginador
			$urlADD = "&textoProcurar=" . $matriz[txtProcurar];
			# Paginador
			paginador($consulta, contaConsulta($consulta), $limite[lista][empresas], $registro, 'normal10', 4, $urlADD);

			# Cabe�alho
			novaLinhaTabela($corFundo, '100%');
			itemLinhaTabela(_('Name'), 'center', '40%', 'tabfundo0');
			itemLinhaTabela(_('Domain'), 'center', '30%', 'tabfundo0');
			itemLinhaTabela(_('Status'), 'center', '10%', 'tabfundo0');
			itemLinhaTabela(_('Options'), 'center', '20%', 'tabfundo0');
			fechaLinhaTabela();

			# Setar registro inicial
			if (!$registro) {
				$i = 0;
			}
			elseif ($registro && is_numeric($registro)) {
				$i = $registro;
			} else {
				$i = 0;
			}

			$limite = $i + $limite[lista][empresas];

			while ($i < contaConsulta($consulta) && $i < $limite /*&& verificaIntegracaoTicketInvent()*/
				) {
				# Mostrar registro
				$id = resultadoSQL($consulta, $i, 'id');
				$nome = resultadoSQL($consulta, $i, 'nome');
				$idPessoaTipo = resultadoSQL($consulta, $i, 'idPessoaTipo');
				$dominio = resultadoSQL($consulta, $i, 'dominio');
				$status = resultadoSQL($consulta, $i, 'status');

				$opcoes = "";
				$opcoes .= htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$id>" . _("Change") . "</a>", 'alterar');
				$opcoes .= htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>" . _("Delete") . "</a>", 'excluir');
				//				novaLinhaTabela( $corFundo, '100%' );

				//				switch (verificaIntegracaoTicketIsp() ){
				//					case 1:
				//						if ($idPessoaTipo==0){
				//							break;
				//						}
				novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela($nome, 'left', '40%', 'normal10');
				itemLinhaTabela($dominio, 'left', '30%', 'normal10');
				itemLinhaTabela(formSelectStatus($status, '', 'check'), 'center', '10%', 'normal10');
				itemLinhaTabela($opcoes, 'center', '20%', 'normal8');
				fechaLinhaTabela();
				//						break;
				//					case 0:
				//						if ($idPessoaTipo==0){
				//							novaLinhaTabela( $corFundo, '100%' );
				//								itemLinhaTabela($nome, 'left', '40%', 'normal10');
				//								itemLinhaTabela($dominio, 'left','30%','normal10');
				//								itemLinhaTabela(formSelectStatus($status,'','check'), 'center', '10%', 'normal10');
				//								itemLinhaTabela($opcoes, 'center', '20%', 'normal8');
				//							fechaLinhaTabela();
				//						}
				//						break;
				//				} # fim do switch

				//				fechaLinhaTabela();

				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem

		fechaTabela();
	} # fecha bot�o procurar
} #fecha funcao de  procurar 

# Funcao para altera��o
function alterarEmpresas($modulo, $sub, $acao, $registro, $matriz) {

	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;

	# ERRO - Registro n�o foi informado
	if (!$registro) {
		# ERRO
	}
	# Form de inclusao
	elseif (!$matriz[bntAlterar] || !$matriz[nome]) {

		# Buscar Valores
		$consulta = buscaEmpresas($registro, 'id', 'igual', 'id');
		if (!$consulta || contaConsulta($consulta) == 0) {
			# Mostrar Erro
			$msg = _("Record not found!");
			$url = "?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning"), $msg, $url, 760);
		} else {
			#atribuir valores
			if (!$matriz[bntAlterar]) {
				$matriz[nome] = resultadoSQL($consulta, 0, 'nome');
				$matriz[dominio] = resultadoSQL($consulta, 0, 'dominio');
				$matriz[idPessoaTipo] = resultadoSQL($consulta, 0, 'idPessoaTipo');
				$matriz['status'] = resultadoSQL($consulta, 0, 'status');
			}

			# Motrar tabela de busca
			novaTabela2("[" . _("Change") . "]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
			$texto = "			
								<form method=post name=matriz action=index.php>
								<input type=hidden name=modulo value=$modulo>
								<input type=hidden name=sub value=$sub>
								<input type=hidden name=acao value=$acao>
								<input type=hidden name=registro value=$registro>&nbsp;
								";
			itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b class=bold10>" . _("Name:") . " </b><br>
									<span class=normal10>" . _("Name of the Company") . "</span>";
			htmlFechaColuna();
			$texto = "<input type=text name=matriz[nome] size=60 value='$matriz[nome]'>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b class=bold10>" . _("Domain:") . " </b><br>
									<span class=normal10>" . _("Company's Domain") . "</span>";
			htmlFechaColuna();
			$texto = "<input type=text name=matriz[dominio] size=30 value='$matriz[dominio]'>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			# STATUS
			novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b class=bold10>" . _("Status:") . " </b><br>
									<span class=normal10>" . _("Company's Status") . "</span>";
			htmlFechaColuna();
			$texto = formSelectStatus($matriz[status], 'status', 'form');
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
			$texto = "<input type=submit name=matriz[bntAlterar] value=" . _("Change") . " class=submit>";
			itemLinhaForm($texto, 'center', 'top', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			fechaTabela();

		} #fecha alteracao
	} #fecha form - !$bntAlterar

	# Altera��o - bntAlterar pressionado
	elseif ($matriz[bntAlterar]) {
		# Conferir campos
		# continuar
		# Cadastrar em banco de dados
		$matriz[id] = $registro;
		$grava = dbEmpresa($matriz, 'alterar');

		# Verificar inclus�o de registro
		if ($grava) {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg = _("Data Recorded Success full!");
			$url = "?modulo=$modulo&sub=$sub&acao=listar";
			avisoNOURL(_("Warning"), $msg, 400);

			echo "<br>";
			$acao = listar;
			procurarEmpresas($modulo, $sub, $acao, 0, '');

		}

		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg = _("Lack of necessary parameters.") . "&nbsp;" . _("Fill the required fields and try again ");
			$url = "?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	} #fecha bntAlterar

} # fecha funcao de altera��o

# Exclus�o de servicos
function excluirEmpresas($modulo, $sub, $acao, $registro, $matriz) {

	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;

	# ERRO - Registro n�o foi informado
	if (!$registro) {
		# Mostrar Erro
		$msg = _("Record not found!");
		avisoNOURL(_("Warning"), $msg, 400);
	}
	# Form de inclusao
	elseif ($registro && !$matriz[bntExcluir]) {

		# Buscar Valores
		$consulta = buscaEmpresas($registro, 'id', 'igual', 'id');

		if (!$consulta || contaConsulta($consulta) == 0) {
			# Mostrar Erro
			$msg = _("Record not found!");
			$url = "?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning"), $msg, $url, 760);
		} else {
			#atribuir valores
			$id = resultadoSQL($consulta, 0, 'id');
			$nome = resultadoSQL($consulta, 0, 'nome');
			$dominio = resultadoSQL($consulta, 0, 'dominio');
			$idPessoaTipo = resultadoSQL($consulta, 0, 'idPessoaTipo');

			# Motrar tabela de busca
			novaTabela2("[" . _("Delete") . "]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
			$texto = "			
								<form method=post name=matriz action=index.php>
								<input type=hidden name=modulo value=$modulo>
								<input type=hidden name=sub value=$sub>
								<input type=hidden name=acao value=$acao>
								<input type=hidden name=registro value=$registro>&nbsp;
								";
			itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b class=bold10>" . _("Name:") . " </b>";
			htmlFechaColuna();
			itemLinhaForm($nome, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b class=bold10>" . _("Domain:") . " </b>";
			htmlFechaColuna();
			itemLinhaForm($dominio, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			if ($idPessoaTipo != 0) {
				novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold10>" . _("Company:") . " </b>";
				htmlFechaColuna();
				itemLinhaForm(formSelectAddPessoaTipo($idPessoaTipo, '', 'check'), 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			}
			novaLinhaTabela($corFundo, '100%');
			$texto = "<input type=submit name=matriz[bntExcluir] value=" . _("Delete") . " class=submit>";
			itemLinhaForm($texto, 'center', 'top', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			fechaTabela();
		} #fecha alteracao
	} #fecha form - !$bntExcluir

	# Altera��o - bntExcluir pressionado
	elseif ($matriz[bntExcluir]) {
		# Cadastrar em banco de dados
		$matriz[id] = $registro;
		$grava = dbEmpresa($matriz, 'excluir');

		# Verificar inclus�o de registro
		if ($grava) {
			# Mensagem de aviso
			$msg = _("Record deleted Success Full! ");
			$url = "?modulo=$modulo&sub=$sub&acao=listar";
			avisoNOURL(_("Warning"), $msg, 400);

			echo "<br>";
			procurarEmpresas($modulo, $sub, 'listar', 0, $matriz);
		}

	} #fecha bntExcluir

} #fecha exclusao 

# Visualiza��o de maquinas
function verEmpresa($modulo, $sub, $acao, $registro, $matriz) {

	global $corFundo, $corBorda, $html;

	# ERRO - Registro n�o foi informado
	if (!$registro) {
		# Mostrar Erro
		$msg = _("Record not found!");
		$url = "?modulo=$modulo&sub=$sub&acao=$acao";
		aviso(_("Warning"), $msg, $url, 760);
	}
	# Form de inclusao
	elseif ($registro) {

		# Buscar Valores
		$consulta = buscaEmpresas($registro, 'id', 'igual', 'id');

		if (!$consulta || contaConsulta($consulta) == 0) {
			# Mostrar Erro
			$msg = _("Record not found!");
			$url = "?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning"), $msg, $url, 760);
		} else {
			#atribuir valores
			$nome = resultadoSQL($consulta, 0, 'nome');

			# Motrar tabela de busca
			novaTabela2("[" . _("Company View") . "]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b class=bold10>" . _("Name:") . " </b>";
			htmlFechaColuna();
			itemLinhaForm($nome, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			fechaTabela();
		} #fecha alteracao
	} #fecha form - !$bntExcluir
}

function formSelectEmpresas($registro, $campo, $tipo, $indexform = 0) {
	global $isp, $conn;
	if ($tipo == 'form') {
		$consulta = buscaEmpresas('', '', 'todos', 'nome');
	}
	elseif ($tipo == 'check') {
		$consulta = buscaEmpresas($registro, 'id', 'igual', 'nome');
	}

	if ($consulta && contaConsulta($consulta) > 0) {
		if ($tipo == 'form') {

			if ($indexform == "ajax" && verificaIntegracaoTicketInvent()) {
				$tmpJS = 'onchange=""';
			}
			if ($indexform > 0) {
				$tmpJS = "onChange=javascript:submit();";
			}

			$retorno = "<select name=\"matriz[$campo]\" $tmpJS>\n";

			for ($a = 0; $a < contaConsulta($consulta); $a++) {

				$id = resultadoSQL($consulta, $a, 'id');
				$nome = substr(resultadoSQL($consulta, $a, 'nome'), 0, 40);
				$opcSelect = ($registro == $id ? ' selected="selected"' : '');

				# Verificar se registro j� est� em banco de dados de Empresas
				$retorno .= "<option value=$id $opcSelect>$nome</option>\n";
			}

			$retorno .= "</select>";
		}
		elseif ($tipo == 'check') {
			$retorno = resultadoSQL($consulta, 0, 'nome');
		}
	}
	return ($retorno);
}

function selectEmpresas($campo, $matriz) {
	$conEmpresas = dbEmpresa('', 'consultar');
	$empresasSQL = resultadoSQL($conEmpresas, 0, 'nome');
	
	$item = "<select name=matriz[$campo] onchange='javascript:submit();'>\n";

	//$item .=  "<option value='' selected>"._("Click here for select other company")."</option>";
	# Listargem
	for ($i = 0; $i < contaConsulta($conEmpresas); $i++) {
		# Valores dos campos
		$nome = resultadoSQL($conEmpresas, $i, 'nome');
		$id = resultadoSQL($conEmpresas, $i, 'id');

		$opcSelect = '';
		if ($id == $matriz[$campo]) {
			$opcSelect = 'selected';
		}

		$item .= "<option value=$id $opcSelect>$nome</option>\n";
	}

	$item .= "</select>";
	
	return($item);

}

/**
 * Return an array of companies. Its index is the company Id.
 *
 * @since 2007-04-27
 * @param integer $registro
 * @return string
 */
function getCompanyArray($record = 0) {
	$return = array ();
	$search = buscaEmpresas('', '', 'todos', 'nome');
	if ($search && contaConsulta($search) > 0) {
		for ($a = 0; $a < contaConsulta($search); $a++) {
			$id = resultadoSQL($search, $a, 'id');
			$name = substr(resultadoSQL($search, $a, 'nome'), 0, 40);
			# Verificar se registro j� est� em banco de dados de Empresas
			$return[$id] = $name;
		}
	}
	return $return;
}

/**
 * Return the options host to a select combo object
 *
 * @since 2007-04-25
 * @param integer $idCompany
 * @return string
 */
function getHostArray($idCompany) {

	$return = array ();
	$search = buscaMaquinas($idCompany, 'idEmpresa', 'igual', 'nome');
	if ($search && contaConsulta($search) > 0) {
		for ($a = 0; $a < contaConsulta($search); $a++) {
			$id = resultadoSQL($search, $a, 'id');
			$name = substr(resultadoSQL($search, $a, 'nome'), 0, 40);
			# Verificar se registro j� est� em banco de dados de Empresas
			$return[$id] = $name;
		}
	} else {
		$return = false;
	}

	return $return;
}

/**
 * Retorna todos os campos do BD para a empresa informado
 *
 * @param $idEmpresa
 * @return matriz contendo os campos do BD
 */
function dadosEmpresa($registro) {

	$consulta = buscaEmpresas($registro, 'id', 'igual', 'id');

	if ($consulta && contaConsulta($consulta) > 0) {
		$retorno[id] = resultadoSQL($consulta, 0, 'id');
		$retorno[idPessoaTipo] = resultadoSQL($consulta, 0, 'idPessoaTipo');
		$retorno[nome] = resultadoSQL($consulta, 0, 'nome');
	}

	return ($retorno);

}

/**
 * Retorna o Id da Empresa da qual o usuario-empresa (logado) pertence
 *
 * @param $registro
 */
function buscaIDsEmpresaUE($usuario) {

	$consulta = buscaUsuariosEmpresas($usuario, 'login', 'igual', 'id');
	$idEmpresasUsuarios = resultadoSQL($consulta, 0, 'id');
	$consulta = buscaUsuariosEmpresasEmpresas($idEmpresasUsuarios, 'idEmpresaUsuario', 'igual', 'id');

	$i = 0;
	$idEmpresas = '';
	while ($i < contaConsulta($consulta)) {
		if ($i <> 0)
			$idEmpresas .= ", ";
		$idEmpresas .= resultadoSQL($consulta, $i, 'idEmpresa');
		$i = $i +1;
	}

	return ($idEmpresas);

}
?>