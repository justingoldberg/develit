<?
################################################################################
# Fun��o:
#    Menus da aplica��o


# Fun��o para verifica��o de menus da aplica��o
/**
 * @return void
 * @param unknown $html
 * @desc Fun��o para verifica��o de menus da aplica��o
*/
function menuPrincipal($tipo)
{
	global $corFundo, $corBorda, $html;
	
	
	# Receber ID do Grupo do usuario
	if($grupoUsuario && contaConsulta($grupoUsuario)>0) {
		$idGrupo=resultadoSQL($grupoUsuario, 0, 'idGrupo');	
		
		# Buscar informa��es do grupo
		# receber informa��es do grupo
		$infoGrupo=buscaInfoGrupo($idGrupo);
	}
	
	if($tipo=='usuario') {
		$classe='menusuperior';
		htmlAbreTabelaSH("center", 760, 0, 1, 0, $corFundo, $corBorda, 7);
			htmlAbreLinha($corFundo);
				itemLinha("<img src=".$html[imagem][ticket]." border=0>"._("TICKET"), "?modulo=ticket", 'center', $corFundo, 0, $classe);
				itemLinha("<img src=".$html[imagem][protocolo]." border=0>"._("PROTOCOL"), "?modulo=protocolo", 'center', $corFundo, 0, $classe);
				itemLinha("<img src=".$html[imagem][relogio]." border=0>"._("CALENDAR"), "?modulo=evento", 'center', $corFundo, 0, $classe);
				itemLinha("<img src=".$html[imagem][procurar]." border=0>"._("SEARCH"), "?modulo=ticket&acao=procurar", 'center', $corFundo, 0, $classe);
				itemLinha("<img src=".$html[imagem][perfil]." border=0>"._("MY PROFILE"), "?modulo=perfil", 'center', $corFundo, 0, $classe);
				itemLinha("<img src=".$html[imagem][config]." border=0>"._("CONFIGURATIONS"), "?modulo=configuracoes", 'center', $corFundo, 0, $classe);
				itemLinha("<img src=".$html[imagem][imprimir]." border=0>"._("REPORTS"), "?modulo=relatorios", 'center', $corFundo, 0, $classe);
				itemLinha("<img src=".$html[imagem][fechar]." border=0>"._("LOGOFF"), "?modulo=logoff", 'center', $corFundo, 0, $classe);
			htmlFechaLinha();
		fechaTabela();
	}
	elseif( $tipo == 'usuariosEmpresas' ){
		$classe='menusuperior';
		$UE = 'UE';
		htmlAbreTabelaSH("center", 760, 0, 1, 0, $corFundo, $corBorda, 7);
			htmlAbreLinha($corFundo);
				itemLinha("<img src=".$html[imagem][ticket].	" border=0>"._("TICKET"), 	"?modulo=ticket$UE", 'center', $corFundo, 0, $classe);
				itemLinha("<img src=".$html[imagem][protocolo].	" border=0>"._("PROTOCOL"), "?modulo=protocolo$UE", 'center', $corFundo, 0, $classe);
				itemLinha("<img src=".$html[imagem][procurar].	" border=0>"._("SEARCH"), 	"?modulo=ticket$UE&acao=procurar$UE", 'center', $corFundo, 0, $classe);
				itemLinha("<img src=".$html[imagem][fechar].	" border=0>"._("LOGOFF"), 	"?modulo=logoff", 'center', $corFundo, 0, $classe);
			htmlFechaLinha();
		fechaTabela();
	}

} # fecha visualizacao de menu



# Fun��o para verifica��o de menus da aplica��o
/**
 * Fun��o para verifica��o de menus da aplica��o
 * 
 * @return void
 * @param string $modulo
 * @param string $sub
 * @param string $acao
 * @param string $registro
 * @param string $matriz
*/
function verMenu($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $sessLogin;
	
	### Menu principal - usuarios logados apenas
	if($modulo=='login' || !$sessLogin)
	{
		validacao($sessLogin, $modulo, $sub, $acao, $registro);
	}
	
	### MODULOS QUE REQUEREM AUTENTICA��O
	else {
		
		if(checaLogin($sessLogin) ) {

			$consultaPerfil= buscaPerfil($sessLogin['id'], 'id', 'igual', 'id');
			
			if( $consultaPerfil && contaConsulta($consultaPerfil)>0) {
				## CONFIGURA��ES
				if($modulo=='configuracoes') {
					config($modulo, $sub, $acao, $registro, $matriz);
				}
				## TICKETS
				elseif($modulo=='ticket' || $modulo=='principal' || !$modulo) {
					$modulo='ticket';
					ticket($modulo, $sub, $acao, $registro, $matriz);
				}
				## PERFIL
				elseif($modulo=='perfil') {
					perfil($modulo, $sub, $acao, $registro, $matriz);
				}
				## PROTOCOLO
				elseif($modulo=='protocolo') {
					protocolo($modulo, $sub, $acao, $registro, $matriz);
				}
				## eventos
				elseif($modulo=='evento') {
					evento($modulo, $sub, $acao, $registro, $matriz);
				}
				## relatorios
				elseif($modulo=='relatorios') {
					relatorios($modulo, $sub, $acao, $registro, $matriz);
				}
				##USUARIOS_EMPRESAS
				elseif( $modulo == 'usuariosEmpresas' ){
					usuariosEmpresas($modulo, $sub, $acao, $registro, $matriz);
				}
			
			} else {
                $msg = _("It is necessary to fill out your profile to access the other modules.");
                avisoNOURL(_("Warning:"), $msg, "100%");
                echo "<br />";
				perfil($modulo, $sub, $acao, $registro, $matriz);
			}
			
		}
	}
} # fecha visualizacao de menu



# Visualiza��o de menu adicional em cadastros
/**
 * Fun��o para verifica��o de menus da aplica��o
 * 
 * @return void
 * @param string $modulo
 * @param string $sub
 * @param string $acao
 * @param string $registro
 * @param string $matriz
*/
function menuOpcAdicional($modulo, $sub, $acao, $registro)
{
	global $corFundo, $moduloApp, $sessLogin;


	## ACESSO
	if($modulo=='acesso') {
		# USUARIOS
		if($sub=='usuarios') {
			if($acao=='adicionar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=grupos&acao=listar>"._("Select Group")."</a>",'usuario');
			}
			elseif($acao=='alterar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$registro>"._("Delete")."</a>",'excluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
			elseif($acao=='excluir') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$registro>"._("Change")."</a>",'alterar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
		}
		elseif($sub=='grupos') {
			if($acao=='adicionar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
			if($acao=='usuariosadicionar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=usuarios&acao=adicionar>"._("New user")."</a>",'usuario');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=usuarios&registro=$registro>"._("List")."</a>",'listar');
			}
			if($acao=='excluir') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.= "&nbsp;&nbsp;";
				$opcoes.= htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$registro>"._("Change")."</a>",'alterar');
				$opcoes.= "&nbsp;&nbsp;";
				$opcoes.= htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.= "&nbsp;&nbsp;";
				$opcoes.= htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
			if($acao=='alterar') {
				$opcoes.= htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.= "&nbsp;&nbsp;";
				$opcoes.= htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$registro>"._("Delete")."</a>",'excluir');
				$opcoes.= "&nbsp;&nbsp;";
				$opcoes.= htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.= "&nbsp;&nbsp;";
				$opcoes.= htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
		}
	}
	
	
	## CONFIGURA��ES
	elseif($modulo=='configuracoes') {
		# CATEGORIAS
		if($sub=='categorias') {
			if($acao=='adicionar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
			elseif($acao=='excluir') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$registro>"._("Change")."</a>",'alterar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=grupos&registro=$registro>"._("Groups")."</a>",'grupo');
			}
			elseif($acao=='alterar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$registro>"._("Delete")."</a>",'excluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=grupos&registro=$registro>"._("Groups")."</a>",'grupo');
			}
			elseif($acao=='gruposexcluir') {
				$registro=explode(":",$registro);
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=grupos&registro=$registro[0]>"._("Add")."</a>",'incluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=grupos&registro=$registro[0]>"._("List")."</a>",'listar');
			}
			elseif($acao=='gruposadicionar') {
				$registro=explode(":",$registro);
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=grupos&registro=$registro[0]>"._("List")."</a>",'listar');
			}
		}
		elseif($sub=='grupos') {
			if($acao=='adicionar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
			if($acao=='usuariosadicionar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=usuarios&acao=adicionar>"._("New user")."</a>",'usuario');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=usuarios&registro=$registro>"._("List")."</a>",'listar');
			}
			if($acao=='excluir') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$registro>"._("Change")."</a>",'alterar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
			if($acao=='alterar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$registro>"._("Delete")."</a>",'excluir');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
		}
		elseif($sub=='prioridades' || $sub=='status') {
			if($acao=='adicionar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
			if($acao=='excluir') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$registro>"._("Change")."</a>",'alterar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
			if($acao=='alterar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$registro>"._("Delete")."</a>",'excluir');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
		}
		elseif($sub=='usuariosempresas') {
			if($acao=='adicionar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
			elseif($acao=='excluir') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$registro>"._("Change")."</a>",'alterar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
			elseif($acao=='alterar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("Add")."</a>",'incluir');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$registro>"._("Delete")."</a>",'excluir');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=procurar>"._("Search")."</a>",'procurar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>"._("List")."</a>",'listar');
			}
			elseif($acao=='empresas') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$registro>"._("Change")."</a>",'alterar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$registro>"._("Delete")."</a>",'excluir');
//				$opcoes.="&nbsp;&nbsp;";
//				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=empresas&registro=$registro>"._("Companies")."</a>",'empresas');
			}
		}
	}
	
	### TICKETS
	elseif($modulo=='ticket') {
		if(!$sub && !$acao) {
			$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&acao=adicionar>"._("New Ticket")."teste"."</a>",'incluir');
			$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&acao=procurar>"._("Search")."</a>",'procurar');

		}
		if($sub=='grupo') {
			$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo>"._("My Tickets")."</a>",'usuario');
			$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&acao=adicionar>"._("New Ticket")."</a>",'incluir');
			$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&acao=procurar>"._("Search")."</a>",'procurar');

		}
		else {
			if($acao=='adicionar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo>"._("My Tickets")."</a>",'usuario');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&acao=procurar>"._("Search")."</a>",'procurar');
			}
			if($acao=='alterar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo>"._("My Tickets")."</a>",'usuario');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=ver&registro=$registro>"._("View Ticket")."</a>",'ver');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("New Ticket")."</a>",'incluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$registro>"._("Delete")."</a>",'excluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&acao=procurar>"._("Search")."</a>",'procurar');
			}
			if($acao=='fechar') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo>"._("My Tickets")."</a>",'usuario');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=ver&registro=$registro>"._("View Ticket")."</a>",'ver');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("New Ticket")."</a>",'incluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&acao=procurar>"._("Search")."</a>",'procurar');
			}
			if($acao=='abrir') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo>"._("My Tickets")."</a>",'usuario');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=ver&registro=$registro>"._("View Ticket")."</a>",'ver');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("New Ticket")."</a>",'incluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&acao=procurar>"._("Search")."</a>",'procurar');
			}
			elseif($acao=='excluir') {
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo>"._("My Tickets")."</a>",'usuario');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=ver&registro=$registro>"._("View Ticket")."</a>",'ver');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>"._("New Ticket")."</a>",'incluir');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$registro>"._("Change")."</a>",'alterar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&acao=procurar>"._("Search")."</a>",'procurar');
			}
		}

	}
	
	### MAQUINAS
	elseif($modulo=='maquinaUE') {
		if( !$sub ){
			if( $acao =='verUE' ){
				$opcoes.=htmlMontaOpcao("<a href=?modulo=ticketUE&sub=$sub&acao=adicionarUE&registro=$registro>"._("New Ticket")."</a>",'incluir');
			}
		}
	}
	/*
	# C�digo comentado por mal funcionamento
	# Op��o default - VOLTAR
	if($sessLogin[modulo]=='ticket' && !$sessLogin[sub] && !$sessLogin[acao] && !$sessLogin[registro]) {
		$opcoes.="&nbsp;";
		$opcoes.=htmlMontaOpcao("<a href=?modulo=>Voltar</a>",'setaesquerda');
	}
	else {
		$opcoes.="&nbsp;";
		$opcoes.=htmlMontaOpcao("<a href=# onClick=voltar()>Voltar</a>",'setaesquerda');
	}
	*/
	
	
	if($opcoes) {
		# Mostrar op��o adicional
		novaLinhaTabela($corFundo, '100%');
		itemLinhaNOURL($opcoes, 'right', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();
	}
	
}
# fecha menu adicional



# Fun��o para mostrar o menu de ticket
/**
 * @desc Fun��o para mostrar o menu de ticket
 * @return void
 * @param int $idStatus
 * @param int $ticket
 * @param str $titulo
 * @param str $$alinhamento
 * @param str $tamanho
 * @param str $corFundo
 * @param str $corBorda
 * @param str $classeCSS
*/
function menuTicket($idStatus, $ticket, $titulo, $alinhamento, $tamanho, $corFundo, $corBorda, $classeCSS) {
	global $html, $sessLogin, $modulo, $categoria, $sessChat;
	
	# Permiss�o do usuario
	$permissao = buscaPermissaoUsuario($sessLogin[login], 'login', 'igual', 'login');
	
	# Status do ticket
	$consulta = buscaStatus($idStatus, 'id','igual','id');
	$valorStatus = resultadoSQL($consulta, 0, 'valor');
	
	$separador = "<br />";
	
	if($permissao[admin] || $permissao[visualizar]) {
		//$opcoes.=htmlMontaOpcao("<a href=?modulo=ticket>Meus Tickets</a>",'usuario');
		//$opcoes.=$separador;
	}
	
	if($permissao[admin] || $permissao[adicionar]) {
		$opcoes.=htmlMontaOpcao("<a href=?modulo=ticket&sub=$sub&acao=adicionar>"._("New")."</a>",'incluir');
		$opcoes.=$separador;
	}
	
	if($permissao[admin] || $permissao[excluir]) {
		$opcoes.= htmlMontaOpcao("<a href=?modulo=ticket&sub=$sub&acao=excluir&registro=$ticket>"._("Delete")."</a>",'excluir');
		$opcoes.= $separador;
	}
	
	if($permissao[admin] || $permissao[alterar]) {
		$opcoes.= htmlMontaOpcao("<a href=?modulo=ticket&sub=$sub&acao=alterar&registro=$ticket>"._("Change")."</a>",'alterar');
		$opcoes.= $separador;
		
		# Checar Status - Status NOVO
		if($valorStatus == 'N') {
			if($permissao[admin] || $permissao[abrir]) {
				$opcoes.= htmlMontaOpcao("<a href=?modulo=ticket&sub=$sub&acao=abrir&registro=$ticket>"._("Open")."</a>",'abrir');
				$opcoes.= $separador;
			}
		}
		elseif($valorStatus == 'A' || $valorStatus == 'R') {
			$opcoes.= htmlMontaOpcao("<a href=?modulo=ticket&sub=$sub&acao=prioridade&registro=$ticket>"._("Priority")."</a>",'prioridades');
			$opcoes.= $separador;			
		}
	}
	
	if($permissao[admin] || $permissao[fechar]) {
		
		# Checar status - Status Aberto, Resolvido
		if($valorStatus=='A' || $valorStatus=='R') {
			$opcoes.= htmlMontaOpcao("<a href=?modulo=ticket&sub=$sub&acao=fechar&registro=$ticket>"._("Close")."</a>",'fechar');
			$opcoes.= $separador;
		}
	}
	
	if($permissao[admin] || $permissao[comentar]) {
		if($valorStatus == 'A' || $valorStatus == 'N' || $valorStatus == 'R') {
			$opcoes.= htmlMontaOpcao("<a href=?modulo=ticket&sub=comentario&acao=adicionar&registro=$ticket>"._("Comment")."</a>",'comentar');
			$opcoes.= $separador;
		}
	}
	
	if($permissao[admin] || $permissao[abrir]) {
		# Checar status - Status Aberto, Resolvido
		if($valorStatus == 'F') {
			# Re-Abrir ticket
			$opcoes.= htmlMontaOpcao("<a href=?modulo=ticket&sub=$sub&acao=reabrir&registro=$ticket>"._("Reopen")."</a>",'pasta');
			$opcoes.= $separador;
		}
	}
	
	# Encaminhar protocolo
	$opcoes.= htmlMontaOpcao("<a href=?modulo=ticket&acao=encaminhar&registro=$ticket>"._("Forward")."</a>",'encaminhar');
	$opcoes.= $separador;
	
	# Transferir ticket
	$opcoes.= htmlMontaOpcao("<a href=?modulo=ticket&acao=transferir&registro=$ticket>"._("Transfer")."</a>",'transferir');
	$opcoes.= $separador;
	
	# Agenda
	$opcoes.= htmlMontaOpcao("<a href=?modulo=evento&acao=agendar&registro=$ticket&matriz[ticket]=$ticket>"._("Schedule")."</a>",'relogio');
	$opcoes.= $separador;
	
	# Relacionar a empresa
	$opcoes.= htmlMontaOpcao("<a href=?modulo=ticket&acao=relacionar&registro=$ticket>"._("Relate")."</a>",'empresas');
	$opcoes.= $separador;
	
	# Procurar
	$opcoes.= htmlMontaOpcao("<a href=?modulo=$modulo&acao=ver&registro=$ticket>"._("View")."</a>",'ver');
	$opcoes.= $separador;
	
	# Visualizar
	$opcoes.= htmlMontaOpcao("<a href=?modulo=$modulo&acao=procurar>"._("Search")."</a>",'procurar');
	$opcoes.= $separador;
	
	# Contabilizar Tempo
	$opcoes.=htmlMontaOpcao("<a href=javascript:novaJanela(\"?modulo=$modulo&sub=tempoticket&acao=adicionar&registro=$ticket\",\"tempo$ticket\",\"width=640,height=400,resizable=No,scrollbars=Yes,title=Atendimento,toolbar=No\")>"._("Assist")."</a>",'atender');
	$opcoes.=$separador;
	
	# Chat
	$opcoes.= htmlMontaOpcao("<a href=javascript:novaJanela(\"?modulo=$modulo&sub=chat&acao=montar&registro=$ticket\",\"chat$ticket\",\"width=640,height=600,resizable=No,scrollbars=Yes,title=ChatOnline,toolbar=No\")>"._("Chat")."&nbsp;"._("Online")."</a>",'usuario');
	$opcoes.= $separador;
	
	# Avaliac�o do ticket	
	$opcoes.=htmlMontaOpcao("<a href=javascript:novaJanela(\"?modulo=ticket&sub=feedback&acao=incluir&registro=$ticket\",\"feedback$ticket\",\"width=640,height=600,resizable=No,scrollbars=Yes,title=FeedBack,toolbar=No\")>"._("Feedback")."</a>",'feedback');
	$opcoes.=$separador;
		
	if( !$sessLogin[login] ) {
		//$opcoes=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=incluir&categoria=$categoria>Novo Ticket</a>",'incluir');
		$opcoes = htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=comentar&registro=$ticket>"._("Add Commentary")."</a>",'comentar');
		$opcoes.= $separador;
		$opcoes.= htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=verprotocolo&registro=$ticket>"._("View Ticket")."</a>",'procurar');
		$opcoes.= $separador;
		$opcoes.= htmlMontaOpcao("<a href=javascript:novaJanela(\"?modulo=$modulo&sub=feedback&acao=incluir&registro=$ticket\",\"feedback$ticket\",\"width=640,height=600,resizable=No,scrollbars=Yes,title=FeedBack,toolbar=No\")>"._("Evaluate Attendance")."</a>",'feedback');
		$opcoes.= $separador;
		
		# Checar Chat
		# Caso por protocolo, procurar ticket
		if(!$ticket || !is_numeric($ticket)) {
			
			$detalhesTicket=dadosTicketProtocolo($ticket,'protocolo','igual','id');
			
			$tmpRegistro=$detalhesTicket[id];
			# Chechar Chat em aberto
			$idChatAberto=checkChatTicket($tmpRegistro);
			if($idChatAberto) $sessChat[id]=$idChatAberto;
		
			if($sessChat[id] && checkChatStatus($sessChat[id])) {
				$opcoes.=htmlMontaOpcao("<a href=javascript:novaJanela(\"?modulo=ticket&sub=chat&acao=montar&registro=$ticket\",\"chat$ticket\",\"width=640,height=600,resizable=No,scrollbars=Yes,title=ChatOnline,toolbar=No\")>"._("Chat")."&nbsp;"._("Online")."</a>",'usuario');
				$opcoes.=$separador;
			}
		}

	}
		
	novaTabela2(_("Options"),'center' , $tamanho, 0, 2, 1, $corFundo, $corBorda, 0);
	novaLinhaTabela($corFundo, '100%');
		itemLinhaForm($opcoes, 'left nowrap', 'middle', $corFundo, 0,  'normal8');
	fechaLinhaTabela();
	fechaTabela();
}


###########################################################################################################################################
###############################																			  #################################
#############################################		SISTEMA DE LOGIN PARA USUARIO_EMPRESA		###########################################
###############################																			  #################################
###########################################################################################################################################

function verMenuUsuarioEmpresa( $modulo, $sub, $acao, $registro, $matriz ){
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $sessLogin;

	### Menu principal - usuarios logados apenas
	if($modulo=='login' || !$sessLogin){
		validacao($sessLogin, $modulo, $sub, $acao, $registro);
	}
	
	### MODULOS QUE REQUEREM AUTENTICA��O
	else {
		
		if(checaLogin($sessLogin) ) {
				
//				$consultaPerfil= buscaPerfil($sessLogin[id], 'id', 'igual', 'id');
				
//				if($consultaPerfil && contaConsulta($consultaPerfil)==1) {
					## TICKETS
					if( $modulo == 'ticketUE' || $modulo == 'principal' || !$modulo ){
						ticketUE( $modulo, $sub, $acao, $registro, $matriz);
					}
					## PROTOCOLO
					elseif( $modulo == 'protocoloUE' ){
						protocoloUE( $modulo, $sub, $acao, $registro, $matriz );
					}
					## M�QUINA
					elseif ( $modulo == 'maquinaUE' ){
						maquinaUE( $modulo, $sub, $acao, $registro, $matriz );
					}
					else{
						# SEM PERMISS�O DE EXECUTAR A FUN��O
						$msg=_("WARNING: You don't have permission to execute this function");
						$url="?modulo=$modulo&sub=$sub";
						aviso(_("Access Denied"), $msg, $url, 760);
					}
//				} else {
//	                $msg = _("It is necessary to fill out your profile to access the other modules.");
//	                avisoNOURL(_("Warning:"), $msg, "100%");
//	                echo "<br />";
//					perfil($modulo, $sub, $acao, $registro, $matriz);
//				}
			
		}
	}
	
}

function menuTicketUE($idStatus, $ticket, $titulo, $alinhamento, $tamanho, $corFundo, $corBorda, $classeCSS) {
	global $html, $sessLogin, $modulo, $categoria;
	
	# Permiss�o do usuario
	$consulta = buscaUsuariosEmpresas($sessLogin[login], 'login', 'igual', 'id');
	$permissao[admin] =resultadoSQL( $consulta, 0, 'admin' );	
	# Status do ticket
	$consulta = buscaStatus($idStatus, 'id','igual','id');
	$valorStatus = resultadoSQL($consulta, 0, 'valor');
	
	$separador = "<br />";
	
	if($permissao[admin] == 'S'/*|| $permissao[visualizar]*/) {
		//$opcoes.=htmlMontaOpcao("<a href=?modulo=ticket>Meus Tickets</a>",'usuario');
		//$opcoes.=$separador;
	}
	
	# Novo ticket
	$opcoes.=htmlMontaOpcao("<a href=?modulo=ticketUE&sub=&acao=adicionarUE>"._("New")."</a>",'incluir');
	$opcoes.=$separador;
	
	# Comentar
	if($valorStatus == 'A' || $valorStatus == 'N' || $valorStatus == 'R') {
		$opcoes.= htmlMontaOpcao("<a href=?modulo=ticketUE&sub=comentarioUE&acao=adicionarUE&registro=$ticket>"._("Comment")."</a>",'comentar');
		$opcoes.= $separador;
	}
	
	
	# Ver
	$opcoes.= htmlMontaOpcao("<a href=?modulo=$modulo&acao=verUE&registro=$ticket>"._("View")."</a>",'ver');
	$opcoes.= $separador;
	
	# Avaliac�o do ticket	
	$opcoes.=htmlMontaOpcao("<a href=javascript:novaJanela(\"?modulo=ticketUE&sub=feedbackUE&acao=incluirUE&registro=$ticket\",\"feedback$ticket\",\"width=640,height=600,resizable=No,scrollbars=Yes,title=FeedBack,toolbar=No\")>"._("Feedback")."</a>",'feedback');
	$opcoes.=$separador;
		
	novaTabela2(_("Options"),'center' , $tamanho, 0, 2, 1, $corFundo, $corBorda, 0);
	novaLinhaTabela($corFundo, '100%');
		itemLinhaForm($opcoes, 'left nowrap', 'middle', $corFundo, 0,  'normal8');
	fechaLinhaTabela();
	fechaTabela();
}

?>