<?
/**
 * Realize AJAX Integration on ticket applications using the XAJAX library.
 * 
 * @author Nash
 * @since 2007/04/23
 * 
 */

$xajax = new xajax();
$xajax->registerFunction("getAjax");

/**
 * Mediator functions for AJAX Requests.
 *
 * @param string $module
 * @param string $action
 * @param string $propriety
 * @param unkown $value
 * @return XML
 */
function getAjax( $module, $action, $propriety='innerHTML', $value=NULL ){
	global $sessLogin;
	
	$objResponse = new xajaxResponsePlus();
	$ret = "";
	
	if( $sessLogin['id'] ) {
		if( substr( $value, 0, 9 ) == 'clearAjax' ) {
			if( strstr( $value, 'Layer' ) ) {
				$objResponse->addAssign( $action.'Layer', 'className', 'invisible');		
			}
			$objResponse->addClear( $action, $propriety );
		}
		else {
			if( $module == 'ticket' ) {
		
				if( $action == 'comboEmpresa' ) {
					$objResponse->addCreateOptions( $action, getCompanyArray() );
					$objResponse->addAssign($action.'Layer', 'className', 'visibletr');
				}
				elseif( $action == 'comboMaquina' ) {				
					getComboHostAjax(&$objResponse, $action, $propriety, $value );
				}
			}
		}
		return $objResponse->getXML();
	}
}

function getComboHostAjax( &$objResponse, $action, $propriety, $value ){
	$ret = getHostArray( $value );
	if( !$ret ){
		$objResponse->addClear(	$action, $propriedade );
		$objResponse->addAssign( 'hostField',	'style.display', 'none' );
		$objResponse->addAssign( 'hostMessage', 'style.display', 'inline' );
	}
	else {
		$objResponse->addCreateOptions( $action, $ret );
		$objResponse->addAssign( 'hostField',	'style.display', 'inline' );
		$objResponse->addAssign( 'hostMessage', 'style.display', 'none' );
	}
	$objResponse->addAssign( $action.'Layer', 'className', 'visibletr');
}

$xajax->processRequests();

?>