<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 12/03/2003
# Ultima altera��o: 18/08/2006
#    Altera��o No.: 012
#
# Fun��o:
#    Fun��es de autentica��o e valida��o de usuario

# Formul�rio de valida��o
function validacao($sessLogin, $modulo, $sub, $acao, $registro) {
	# Carregar vari�veis de autentica��o
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $lang, $languages;
	if($modulo) {
		# Menu Principal
		htmlAbreTabelaSH("center", 760, 0, 0, 0, $corFundo, $corBorda, 2);
			htmlAbreLinha($corFundo);
				htmlAbreColuna('100%', 'center', $corFundo, 0, 'normal');
				menuPrincipal('anonimo');
				htmlFechaColuna();
			htmlFechaLinha();
		fechaTabela();
	}
	
	# Formulario de login
	if(!$sessLogin[login] || !$sessLogin[senha]) {
		# Formul�rio de login
		
		if($modulo=='login' || $modulo=='logoff') {
			$modulo='ticket';
			$sub='';
			$acao='';
		}
		
		# Motrar tabela de busca
		novaTabela2SH("center", '100%', 0, 2, 0, $corFundo, $corBorda, 2);//novaTabela2SH("center", '100%', (num_borda), 2, 0, $corFundo, $corBorda, 2);
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColunaEspecial('60%', 'center', $corFundo, 0, 'normal10', 5);//('60%', 'center', $corFundo, 0, 'normal10')
					echo "<img src=".$html[imagem][logo].">";
				htmlFechaColuna();
				
				# Escolha do idioma
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'normal10');
					novaTabela2("["._("System")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
						novaLinhaTabela($corFundo, '100%');
							htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
								echo "<b class=bold10>"._("Select:")." </b>";
							htmlFechaColuna();		
							
							$lang_padrao = ( !array_key_exists( $lang, $languages ) ) ? "en_US" : $lang;
							$minusculo=strtolower( $lang_padrao ).".gif";
							$texto="<form method=post name=matriz action=index.php>					
							<select name='lang' tabindex=0 id=\"issuetype\" class=\"imagebacked\" style=\"background-image: url(./imagens/$minusculo); onclick=\"this.parentNode.setAttribute('style',this.getAttribute('style'));\" onChange=javascript:submit()>";
							
							while( $value = current ( $languages ) ){
								$chave=key($languages);
								$minusculo=strtolower($chave).".gif";
								$texto.="<option value=$chave " . ( ( $chave != $lang_padrao ) ? "" : "selected" )." class=\"imagebacked\" style=\"background-image: url(./imagens/$minusculo);\">&nbsp;$value</option>";
								next($languages);
							}#fim do while
							$texto.="</select>";
							itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
						fechaLinhaTabela();
					fechaTabela();
				htmlFechaColuna();
			fechaLinhaTabela();
		
			# caixa para login
			itemTabelaNOURL('&nbsp;', 'left', $corFundo, 2, 'normal10');
			novaLinhaTabela($corFundo, '100%');
//				htmlAbreColuna('40%', 'center', $corFundo, 0, 'normal10');
//					echo "&nbsp;";
//				htmlFechaColuna();
				htmlAbreColuna('60%', 'right', $corFundo, 0, 'normal10');
					novaTabela2("["._("Access Login")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
						# Opcoes Adicionais
						//menuOpcAdicional($modulo, $sub, $acao, $registro);				
						
						#fim das opcoes adicionais
						novaLinhaTabela($corFundo, '100%');
							$texto="<form method=post name=matriz action=index.php>
							<input type=hidden name=modulo value=$modulo>
							<input type=hidden name=sub value=$sub>
							<input type=hidden name=acao value=$acao>
							<input type=hidden name=registro value=$registro>
							<br>
							<center><b class=bold10>$configAppName - $configAppVersion</b><br>
							<br>
							<span class=txtaviso>"._("Fill the User and Password for Access")."</span></center><br>";
							itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
						fechaLinhaTabela();
						novaLinhaTabela($corFundo, '100%');
							htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
								echo "<b class=bold10>"._("User:")." </b>";
							htmlFechaColuna();
							$texto="<input type=text name=matValida[login] size=20 tabindex=1 >";
							itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
						fechaLinhaTabela();
						novaLinhaTabela($corFundo, '100%');
							htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
								echo "<b class=bold10>"._("Password:")." </b>";
							htmlFechaColuna();
							$texto="<input type=password name=matValida[senha] size=20 tabindex=2>";
							itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
						fechaLinhaTabela();
						
						# Bot�o de confirma��o
						novaLinhaTabela($corFundo, '100%');
							htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
								echo "&nbsp;";
							htmlFechaColuna();
							$texto="<input type=submit name=matValida[bntOK] value="._("OK")." class=submit tabindex=3>
							</form>";
							itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
						fechaLinhaTabela();
					fechaTabela();
				htmlFechaColuna();
			fechaLinhaTabela();
			
			# caixa para o n�mero do protocolo
			if(!$registro) {
				itemTabelaNOURL('&nbsp;', 'left', $corFundo, 2, 'normal10');
				novaLinhaTabela($corFundo, '100%');
//					htmlAbreColuna('40%', 'center', $corFundo, 0, 'normal10');
//						echo "&nbsp;";
//					htmlFechaColuna();
					
					htmlAbreColuna('60%', 'right', $corFundo, 0, 'normal10');
						novaTabela2("["._("View Protocol")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
							#fim das opcoes adicionais
							novaLinhaTabela($corFundo, '100%');
								$texto="<form method=post name=matriz action=index.php>
								<input type=hidden name=moduloProtocolo value=protocolo>
								<input type=hidden name=sub value=>
								<input type=hidden name=acaoProtocolo value=ver>";
								itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
							fechaLinhaTabela();
							novaLinhaTabela($corFundo, '100%');
								htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
									echo "<b class=bold10>"._("Protocol:")." </b>";
								htmlFechaColuna();
								$texto="<input type=text name=registro size=20 tabindex=4>";
								itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
							fechaLinhaTabela();
							# Bot�o de confirma��o
							novaLinhaTabela($corFundo, '100%');
								htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
									echo "&nbsp;";
								htmlFechaColuna();
								$texto="<input type=submit name=matriz[bntProtocolo] value="._("View")." class=submit tabindex=5>";
								itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
							fechaLinhaTabela();
							
						fechaTabela();
						
					htmlFechaColuna();
				fechaLinhaTabela();
			}
			
		fechaTabela();
	}
	# Conferir usuario
	elseif($sessLogin[login] && $sessLogin[senha]) {
		# Conferir campos
		$usuario=strtoupper($usuario);
		$consulta=buscaUsuarios("upper(login)='$sessLogin[login]'", 'login','custom','id');
		
		if($consulta && contaConsulta($consulta)>0) {
			# Verificar usuario
			$usuario=resultadoSQL($consulta, 0, 'login');
			$id=resultadoSQL($consulta, 0, 'id');
			$senhaBanco=resultadoSQL($consulta, 0, 'senha');
			$status=resultadoSQL($consulta, 0, 'status');
			
			# conferir senha
			if($senhaBanco <> crypt($sessLogin[senha], $senhaBanco)) {
				# Mensagem
				$msg=_("Invalid User or Password!");
				$url="?modulo=login";
				avisoUrl(_("ERROR: Access Login"), $msg, $url, 760);
				
				session_destroy();
			}
			else {
				
				# Mensagem
				$msg=_("Login success full!");
				$url="?modulo=";
				avisoUrl(_("Acess login"), $msg, $url, 760);
			}
		}
		else {
			# Mensagem
			$msg=_("Invalid User or Password!");
			$url="?modulo=login";
			avisoUrl(_("ERROR: Access Login"), $msg, $url, 760);
			
			session_destroy();
		}
	
	}
	
} #fecha funcao de valida��o



# Fun��o para checagem de formul�rio de valida��o
function usuariosValidaForm($matriz) {

	if($matriz[login]) $retorno[login]=$matriz[login];
	if($matriz[senha]) $retorno[senha]=$matriz[senha];
	
	if($retorno) return($retorno);
	
} #fecha valida��o de formul�rio de login



# Fun��o para checagem de login
function checaLogin($matriz) {
	# Carregar vari�veis de autentica��o
	global $corFundo, $corBorda, $sessLogin;
	
	if($matriz[login] && $matriz[senha]) {
		# Conferir campos
		$usuario=strtoupper($usuario);
		# 1� verificar na Tab. EmpresasUsuarios
		$consulta = buscaUsuariosEmpresas( "upper(login)='$sessLogin[login]'", 'login','custom','id' );
		$isCompanyUser = true;
		if( !( $consulta && contaConsulta($consulta) > 0 ) ){
			# 2� verificar na Tab. usuarios
			$consulta=buscaUsuarios("upper(login)='$matriz[login]'", 'login','custom','id');
			// by nash - 2007-04-16 - deveria verificar se o usuario de empresa ou normal
			$isCompanyUser = false;
		}
		
		if($consulta && contaConsulta($consulta)>0) {
			# Verificar usuario
			$usuario=resultadoSQL($consulta, 0, 'login');
			$id=resultadoSQL($consulta, 0, 'id');
			$senhaBanco=resultadoSQL($consulta, 0, 'senha');
			$status=resultadoSQL($consulta, 0, 'status');
			if($status!='A'){
				$matriz[senha]='';
			}
			# conferir senha	
			if($senhaBanco <> crypt($matriz[senha], $senhaBanco)) {
				# Mensagem
				$msg=_("Invalid User or Password!");
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				
				if($opcao) aviso(_("ERROR: Access Login"), $msg, $url, 760);
			}
			else {
				# retornar com autentica��o OK
				$sessLogin[id]=$id;
				$sessLogin['isCompanyUser']=$isCompanyUser;
				return(1);
			}
		}
		else {
			# Mensagem
			$msg=_("Invalid User or Password!");
			$url="?modulo=login";
			
			if($opcao) aviso(_("ERROR: Access Login"), $msg, $url, 760);			
		}
	
	}
	
}



# fun��o de busca 
function buscaUsuarios($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Usuarios] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[Usuarios] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	
} # fecha fun��o de busca de usuarios






# Buscar infoma��es do grupo e retornar matriz
function buscaInfoGrupo($idGrupo) {

	if($idGrupo) {
		$consultaGrupo=buscaGrupos($idGrupo, 'id','igual','id');
	}

	if($consultaGrupo && contaConsulta($consultaGrupo)>0) {
		# Informa��es do grupo	
		$infoGrupo[admin]=resultadoSQL($consultaGrupo, 0, 'admin');
		$infoGrupo[incluir]=resultadoSQL($consultaGrupo, 0, 'incluir');
		$infoGrupo[alterar]=resultadoSQL($consultaGrupo, 0, 'alterar');
		$infoGrupo[excluir]=resultadoSQL($consultaGrupo, 0, 'excluir');
		$infoGrupo[buscar]=resultadoSQL($consultaGrupo, 0, 'buscar');
	}
	
	return($infoGrupo);
} #fecha funcao de informa��es do grupo



# Fun��o para busca de ID de usuario
function buscaIDUsuario($texto, $campo, $tipo, $ordem) {
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Usuarios] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[Usuarios] WHERE $texto ORDER BY $ordem";
	}
	
	$ret=0;
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		if ($consulta && contaConsulta($consulta)>0) {
			$ret=resultadoSQL($consulta,0,'id');
		}
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	return ($ret);
} # fecha busca por ID de usu�rio


# Fun��o para busca de ID de usuario
function buscaLoginUsuario($texto, $campo, $tipo, $ordem) {
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Usuarios] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[Usuarios] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta		
		if($consulta && contaConsulta($consulta)>0) return(resultadoSQL($consulta,0,'login'));
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	
} # fecha busca por ID de usu�rio


# Buscar infoma��es do grupo e retornar matriz
function buscaPermissaoUsuario($login) {

	# Checar informa��o sobre usuarios - localizar grupos
	
	if($login) {
		# Buscar o ID do usuario
		$idUsuario=buscaIDUsuario($login, 'login','igual','login');
		$consulta=buscaUsuariosGrupos($idUsuario, 'idUsuario','igual','idUsuario');
	}

	# Zerar permiss�es
	$permissao[admin]="";
	$permissao[incluir]="";
	$permissao[alterar]="";
	$permissao[excluir]="";
	$permissao[visualizar]="";
	$permissao[abrir]="";
	$permissao[fechar]="";
	$permissao[comentar]="";

	# Caso encontrado grupo
	if($consulta && contaConsulta($consulta)>0) {
	
		# Atualizar permiss�es
		$i=0;
		while($i < contaConsulta($consulta)) {
			# Verificar permiss�es
			$idGrupo=resultadoSQL($consulta, $i, 'idGrupo');
			
			# Buscar informa��es sobre este grupo
			$consultaGrupo=buscaGrupos($idGrupo, 'id','igual','id');
			
			# atualizar informa��es do usuario
			if(resultadoSQL($consultaGrupo, 0, 'admin')) $permissao[admin]=resultadoSQL($consultaGrupo, 0, 'admin');
			if(resultadoSQL($consultaGrupo, 0, 'incluir')) $permissao[adicionar]=resultadoSQL($consultaGrupo, 0, 'incluir');
			if(resultadoSQL($consultaGrupo, 0, 'alterar')) $permissao[alterar]=resultadoSQL($consultaGrupo, 0, 'alterar');
			if(resultadoSQL($consultaGrupo, 0, 'excluir')) $permissao[excluir]=resultadoSQL($consultaGrupo, 0, 'excluir');
			if(resultadoSQL($consultaGrupo, 0, 'visualizar')) $permissao[visualizar]=resultadoSQL($consultaGrupo, 0, 'visualizar');
			if(resultadoSQL($consultaGrupo, 0, 'abrir')) $permissao[abrir]=resultadoSQL($consultaGrupo, 0, 'abrir');
			if(resultadoSQL($consultaGrupo, 0, 'fechar')) $permissao[fechar]=resultadoSQL($consultaGrupo, 0, 'fechar');
			if(resultadoSQL($consultaGrupo, 0, 'comentar')) $permissao[comentar]=resultadoSQL($consultaGrupo, 0, 'comentar');
			
			# Incrementar contador
			$i++;
		} #fecha atualiza��o de permiss�es
	}

	return($permissao);
	
} #fecha funcao de informa��es do grupo



# Menu principal
function acesso($modulo, $sub, $acao, $registro, $matriz) {

	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	
	#$sessLogin =& $GLOBALS["sessLogin"];
	$sessLogin = $_SESSION["sessLogin"];
	
	# Buscar informa��es sobre usuario - permiss�es
	$permissao=buscaPermissaoUsuario($sessLogin[login]);

	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {

		# Menu principal de acesso
		if(!$sub) {
			# Mostrar menu
			novaTabela2("["._("Access")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 4);
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('55%', 'left', $corFundo, 0, 'tabfundo1');
						echo "<br><img src=".$html[imagem][controle_acesso]." border=0 align=left>
						<b class=bold>"._("Access")."</b><br><br><span class=normal10>".
						_("Use the access section to control the Users and groups,")."&nbsp;".
						_("users of the")."&nbsp;".$configAppName.".</span>";
					htmlFechaColuna();
					htmlAbreColuna('5%', 'left', $corFundo, 0, 'normal');
						echo "&nbsp;";
					htmlFechaColuna();									
					$texto=htmlMontaOpcao("<br>"._("Users"), 'usuario');
					itemLinha($texto, "?modulo=$modulo&sub=usuarios", 'center', $corFundo, 0, 'normal');
					$texto=htmlMontaOpcao("<br>"._("Groups"), 'grupo');
					itemLinha($texto, "?modulo=$modulo&sub=grupos", 'center', $corFundo, 0, 'normal');
				fechaLinhaTabela();
			fechaTabela();
		}
		
		# Usu�rios
		elseif($sub=='usuarios') {
			# Menu de modulos
			cadastroUsuarios($modulo, $sub, $acao, $registro, $matriz);	
		}
		
		# Grupos
		elseif($sub=='grupos') {
			# Menu de parametros
			cadastroGrupos($modulo, $sub, $acao, $registro, $matriz);
		}
	}
}


# Menu principal de usuarios
# Fun��o para cadastro de usuarios
function cadastroUsuarios($modulo, $sub, $acao, $registro, $matriz) {
	
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;

	# Buscar informa��es sobre usuario - permiss�es
	$sessLogin=$_SESSION["sessLogin"];	
	$permissao=buscaPermissaoUsuario($sessLogin[login]);

	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {

		# Topo da tabela - Informa��es e menu principal do Cadastro
		novaTabela2("["._("Cadaster of Users")."]", "center", '100%', 0, 3, 1, $corFundo, $corBorda, 4);
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('65%', 'left', $corFundo, 0, 'tabfundo1');
					echo "<br><img src=".$html[imagem][cadastro]." border=0 align=left>
					<b class=bold>"._("Users")."</b><br><span class=normal10>".
					_("The user's cadaster provides the user's control that will have access to the")." $configAppName.</span>";
				htmlFechaColuna();			
				$texto=htmlMontaOpcao("<br>"._("Add"), 'incluir');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=adicionar", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>"._("Search"), 'procurar');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=procurar", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>"._("List"), 'listar');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=listar", 'center', $corFundo, 0, 'normal');
			fechaLinhaTabela();
		fechaTabela();
		
		# Mostrar Status para n�o seja informada a a��o
		if(!$acao) {
			# Mostrar Status
			echo "<br>";
			verStatusUsuarios();
		}
	
		# Inclus�o
		elseif($acao=="adicionar") {
			echo "<br>";
			adicionarUsuarios($modulo, $sub, $acao, $registro, $matriz);
		}
		# Lista
		elseif($acao=="listar") {
			echo "<br>";
			listarUsuarios($modulo, $sub, $acao, $registro, $matriz);
		}
		# Procurar
		elseif($acao=="procurar") {
			echo "<br>";
			procurarUsuarios($modulo, $sub, $acao, $registro, $matriz);
		}
		# Lista
		elseif($acao=="alterar") {
			echo "<br>";
			alterarUsuarios($modulo, $sub, $acao, $registro, $matriz);
		}
		# Lista
		elseif($acao=="excluir") {
			echo "<br>";
			excluirUsuarios($modulo, $sub, $acao, $registro, $matriz);
		}
	}
}


# Fu��o para visualiza��o de status
function verStatusUsuarios()
{
	global $conn, $tb, $corFundo, $corBorda, $html;

	# Motrar tabela de busca
	novaTabela2("["._("Information about Users Cadaster")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('60%', 'left', $corFundo, 0, 'tabfundo1');
			echo "<br><img src=".$html[imagem][status]." border=0 align=left><b class=bold>"._("Users Status")."</b><br>
			<span class=normal10>"._("Status and informations about the user's cadaster.");
			htmlFechaColuna();
			htmlAbreColuna('10', 'left', $corFundo, 0, 'normal');
			echo "&nbsp;";
			htmlFechaColuna();
			
			
			htmlAbreColuna('40%', 'left', $corFundo, 0, 'normal');
				# Mostrar status dos servi�os
				$consulta=buscaUsuarios($texto, $campo, 'todos', 'id');
				if($consulta) {
					$numConsulta=contaConsulta($consulta);
				}
				else {
					$numConsulta=0;
				}
				
				htmlAbreTabelaSH('left', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
					novaLinhaTabela($corFundo, '100%');
						itemLinhaNOURL(_('Number of records:'), 'right', $corFundo, $colunas, 'bold10');
						itemLinhaNOURL("$numConsulta "._("registered users"), 'left', $corFundo, $colunas, 'normal10');
					fechaLinhaTabela();
				fechaTabela();
				
			
			htmlFechaColuna();
		fechaLinhaTabela();
	fechaTabela();	
} #fecha status do cadastro de usuarios



# Funcao para cadastro de usuarios
function adicionarUsuarios($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Form de inclusao
	if(!$matriz[bntAdicionar]) {
		# Motrar tabela de busca
		novaTabela2("["._("Add")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);				
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
			$texto="			
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=$acao>&nbsp;";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold>"._("Login:")." </b><br>
					<span class=normal10>"._("Login of the user's access")."</span>";
				htmlFechaColuna();
				$texto="<input type=text name=matriz[login] size=20>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold>"._("Password:")." </b><br>
					<span class=normal10>"._("Password of the user's access")."</span>";
				htmlFechaColuna();
				$texto="<input type=password name=matriz[senha] size=20>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold>"._("Confirm Password:")." </b><br>
					<span class=normal10>"._("Confirm Password of the user's access")."</span>";
				htmlFechaColuna();
				$texto="<input type=password name=matriz[confirma_senha] size=20>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "&nbsp;";
				htmlFechaColuna();
				$texto="<input type=submit name=matriz[bntAdicionar] value="._("Add")." class=submit>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
		fechaTabela();
	} #fecha form
	elseif($matriz[bntAdicionar]) {
		# Conferir campos
		if($matriz[login] && $matriz[senha] && $matriz[confirma_senha]) {
			# conferir senha e confirma��o
			if( $matriz[senha] != $matriz[confirma_senha]){
				# Erro - campo inv�lido
				# Mensagem de aviso
				$msg=_("Password mismatch. Try again");
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				aviso(_("Warning: Incorrect Data"), $msg, $url, 760);
			}
			# continuar - campos OK
			else {
				# Cadastrar em banco de dados
				$grava=dbUsuario($matriz, 'incluir');
				
				# Verificar inclus�o de registro
				if($grava) {
					# acusar falta de parametros
					# Mensagem de aviso
					$msg=_("Data Recorded Success full!");
					$url="?modulo=$modulo&sub=$sub&acao=$acao";
					aviso(_("Warning"), $msg, $url, 760);
				}
				
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	}
} # fecha funcao de inclusao de usuarios


# Fun��o para grava��o em banco de dados
function dbUsuario($matriz, $tipo)
{
	global $conn, $tb, $modulo, $sub, $acao;
	
	# Sql de inclus�o
	if($tipo=='incluir') {
		$tmpLogin=strtoupper($matriz[login]);
		# Verificar se servi�o existe na tab. Usuarios
		$tmpBusca=buscaUsuarios("upper(login)='$tmpLogin'", $campo, 'custom', 'id');
		# Verificar se servi�o existe na tab. Usuarios
		$tmpBuscaUE=buscaUsuariosEmpresas("upper(login)='$tmpLogin'", $campo, 'custom', 'id');
		
		# Registro j� existe
		if( ($tmpBusca && contaConsulta($tmpBusca)>0) || ($tmpBuscaUE && contaConsulta($tmpBuscaUE)>0) ){
			# Mensagem de aviso
			$msg=_("Record already exists in the database");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: Error when including record"), $msg, $url, 760);
		}
		else {
			# Criptograma senha
			$senhaBanco=crypt($matriz[senha]);
			$sql="INSERT INTO $tb[Usuarios] VALUES (0, '$matriz[login]', '$senhaBanco', 'A')";
		}
	} #fecha inclusao
	
	elseif($tipo=='alterar') {
		# Verificar se servi�o existe
		$tmpBusca=buscaUsuarios($matriz[id], 'id', 'igual', 'id');
		
		# Registro j� existe
		if(!$tmpBusca || contaConsulta($tmpBusca)==0) {
			# Mensagem de aviso
			$msg=_("Record not found in database");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: Error when including record"), $msg, $url, 760);
		}
		else {
			if ( $matriz[nao_crypt]!='N' ){
				$senhaBanco=crypt($matriz[senha]);
			}
			else{
				$senhaBanco=$matriz[senha];
			}
			$sql="UPDATE $tb[Usuarios] SET senha='$senhaBanco', status='$matriz[status]' WHERE id=$matriz[id]";
		}
	}
	
	elseif($tipo=='excluir') {
		# Verificar se servi�o existe
		$tmpServico=buscaUsuarios($matriz[id], 'id', 'igual', 'id');
		
		# Registro j� existe
		if(!$tmpServico || contaConsulta($tmpServico)==0) {
			# Mensagem de aviso
			$msg=_("Record doesn't exist in the database");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: Error when changing record"), $msg, $url, 760);
		}
		else {
			$sql="DELETE FROM $tb[Usuarios] WHERE id=$matriz[id]";
		}
	}

	
	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
	
} # fecha fun��o de grava��o em banco de dados


# Listar usuarios
function listarUsuarios($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $limite;

	# Cabe�alho		
	# Motrar tabela de busca
	novaTabela("["._("List")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
		# Sele��o de registros
		$consulta=buscaUsuarios($texto, $campo, 'todos','login');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# N�o h� registros
			itemTabelaNOURL(_('There are not registered record'), 'left', $corFundo, 3, 'txtaviso');
		}
		else {
		
			# Paginador
			paginador($consulta, contaConsulta($consulta), $limite[lista][usuarios], $registro, 'normal', 3, $urlADD);
		
			# Cabe�alho
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela(_('Login'), 'center', '40%', 'tabfundo0');
				itemLinhaTabela(_('Status'), 'center', '20%', 'tabfundo0');
				itemLinhaTabela(_('Options'), 'center', '40%', 'tabfundo0');
			fechaLinhaTabela();

			# Setar registro inicial
			if(!$registro) {
				$i=0;
			}
			elseif($registro && is_numeric($registro) ) {
				$i=$registro;
			}
			else {
				$i=0;
			}
			
			$limite=$i+$limite[lista][usuarios];
			
			while($i < contaConsulta($consulta) && $i < $limite) {
				# Mostrar registro
				$id=resultadoSQL($consulta, $i, 'id');
				$login=resultadoSQL($consulta, $i, 'login');
				$status=resultadoSQL($consulta, $i, 'status');
				
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$id>"._("Change")."</a>",'alterar');
				if ($status=='A'){
					$opcoes.="&nbsp;&nbsp;";
					$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>"._("Delete")."</a>",'excluir');
				}
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($login, 'left', '40%', 'normal');
//					itemLinhaTabela(checaStatus($status), 'center', '20%', 'normal');
					itemLinhaTabela(formSelectStatus($status, '', 'check'), 'center', '20%', 'normal');
					itemLinhaTabela($opcoes, 'center', '40%', 'normal');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem

	fechaTabela();

} # fecha fun��o de listagem


# Funcao para alteracao de usuarios
function alterarUsuarios($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Form de inclusao
	if(!$matriz[bntAlterar]) {
		# Buscar informa��es do usuario
		$consulta=buscaUsuarios($registro, 'id','igual','id');
		
		#verificar consulta
		if($consulta && contaConsulta($consulta)>0) {
			# receber valores
			$id=resultadoSQL($consulta, 0, 'id');
			$login=resultadoSQL($consulta, 0, 'login');
			$senha=resultadoSQL($consulta, 0, 'senha');
			$status=resultadoSQL($consulta, 0, 'status');
		
			# Motrar tabela de busca
			novaTabela2("["._("Change")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=matriz[id] value=$id>
					<input type=hidden name=acao value=$acao>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				# Status do usuario - Desativado
				if ($status<>'A'){
					$texto="
					<input type=hidden name=matriz[senha] value=$senha>
					<input type=hidden name=matriz[confirma_senha] value=$senha>
					<input type=hidden name=matriz[nao_crypt] value='N'>";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Status:")." </b><br>";
						htmlFechaColuna();
//						itemLinhaForm(formChecaStatus($status), 'left', 'top', $corFundo, 0, 'tabfundo1');
						itemLinhaForm(formSelectStatus($status, 'status', 'form'), 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('100%', 'right', $corFundo, 2, 'tabfundo1');
							echo "&nbsp;";
						htmlFechaColuna();
					fechaLinhaTabela();					
				}
				else {
					$texto="
					<input type=hidden name=matriz[status] value=$status>";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Login:")." </b><br>
							<span class=normal10>"._("Login of the user's access")."</span>";
						htmlFechaColuna();					
						itemLinhaForm($login, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Password:")." </b><br>
							<span class=normal10>"._("Password of the user's access")."</span>";
						htmlFechaColuna();
						$texto="<input type=password name=matriz[senha] size=20>";
						itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Confirm Password:")." </b><br>
							<span class=normal10>"._("Confirm Password of the user's access")."</span>";
						htmlFechaColuna();
						$texto="<input type=password name=matriz[confirma_senha] size=20>";
						itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
				}
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntAlterar] value="._("Change")." class=submit>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		}
		# registro nao encontrado
		else {
			# Mensagem de aviso
			$msg=_("Record not found!");
			$url="?modulo=$modulo&sub=$sub&acao=listar";
			aviso(_("Warning"), $msg, $url, 760);
		}
	} #fecha form
	elseif($matriz[bntAlterar]) {
		# Conferir campos
		if($matriz[senha] && $matriz[confirma_senha]) {
			# conferir senha e confirma��o
			if( $matriz[senha] != $matriz[confirma_senha]){
				# Erro - campo inv�lido
				# Mensagem de aviso
				$msg=_("Password mismatch. Try again");
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				aviso(_("Warning: Incorrect Data"), $msg, $url, 760);
			}
			# continuar - campos OK
			else {
				# Cadastrar em banco de dados
				$grava=dbUsuario($matriz, 'alterar');
				
				# Verificar inclus�o de registro
				if($grava) {
					# acusar falta de parametros
					# Mensagem de aviso
					$msg=_("Data Recorded Success full!");
					$url="?modulo=$modulo&sub=$sub&acao=listar";
					aviso(_("Warning"), $msg, $url, 760);
				}
				
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	}
} # fecha funcao de alteracao de usuarios


# Funcao para exclusao de usuarios
function excluirUsuarios($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Form de inclusao
	if(!$matriz[bntExcluir]) {
		# Buscar informa��es do usuario
		$consulta=buscaUsuarios($registro, 'id','igual','id');
		
		#verificar consulta
		if($consulta && contaConsulta($consulta)>0) {
			# receber valores
			$id=resultadoSQL($consulta, 0, 'id');
			$login=resultadoSQL($consulta, 0, 'login');
			$senha=resultadoSQL($consulta, 0, 'senha');
			$status=resultadoSQL($consulta, 0, 'status');
		
			# Motrar tabela de busca
			novaTabela2("["._("delete")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=matriz[id] value=$id>
					<input type=hidden name=acao value=$acao>
					<input type=hidden name=matriz[senha] value=$senha>
					<input type=hidden name=matriz[nao_crypt] value='N'>
					<input type=hidden name=matriz[status] value='C'>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("Login:")." </b></span>";
					htmlFechaColuna();					
					itemLinhaForm($login, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntExcluir] value="._("Delete")." class=submit>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		}
		# registro nao encontrado
		else {
			# Mensagem de aviso
			$msg=_("Record not found!");
			$url="?modulo=$modulo&sub=$sub&acao=listar";
			aviso(_("Warning"), $msg, $url, 760);
		}
	} #fecha form
	elseif($matriz[bntExcluir]) {
		# Conferir campos
		# Cadastrar em banco de dados
		$grava=dbUsuario($matriz, 'alterar');
		
		# Verificar inclus�o de registro
		if($grava) {
//			# Apagar usuarios dos grupos
//			$gravaUsuariosGrupos=dbUsuarioGrupo($matriz, 'excluirtodos');
//			# Apagar perfil
//			$gravaPerfil=dbPerfil($matriz, 'excluir');
//			# Apagar Processos
//			dbProcessosTicket($matriz, 'excluirusuario');
//			# Apagar comentarios
//			dbComentariosTicket($matriz, 'excluirusuario');
			
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Record deleted Success Full!");
			$url="?modulo=$modulo&sub=$sub&acao=listar";
			aviso(_("Warning"), $msg, $url, 760);
		}
	}
} # fecha funcao de exclusao de usuarios


# Fun��o para procura de servi�o
function procurarUsuarios($modulo, $sub, $acao, $registro, $matriz)
{
	global $conn, $tb, $corFundo, $corBorda, $html, $limite, $textoProcurar;
	
	# Atribuir valores a vari�vel de busca
	if(!$matriz) {
		$matriz[bntProcurar]=1;
		$matriz[txtProcurar]=$textoProcurar;
	} #fim da atribuicao de variaveis
	
	# Motrar tabela de busca
	novaTabela2("["._("Search")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('30%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b>"._("Search for:")."</b>";
			htmlFechaColuna();
			$texto="
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=procurar>
			<input type=text name=matriz[txtProcurar] size=40 value='$matriz[txtProcurar]'>
			<input type=submit name=matriz[bntProcurar] value="._("Search")." class=submit>";
			itemLinhaForm($texto, 'left','middle', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();

	# Caso bot�o procurar seja pressionado
	if( $matriz[bntProcurar] && $matriz[txtProcurar] ) {
		#buscar registros
		$consulta=buscaUsuarios("upper(login) like '%$matriz[txtProcurar]%'",$campo, 'custom','login');

		echo "<br>";

		novaTabela("["._("List")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
	
		if(!$consulta || contaConsulta($consulta)==0 ) {
			# N�o h� registros
			itemTabelaNOURL(_('No record found'), 'left', $corFundo, 3, 'txtaviso');
		}
		elseif($consulta && contaConsulta($consulta)>0 && (is_numeric($registro) || !$registro)) {	
		
			itemTabelaNOURL(_('Found records looking for').' ('.$matriz[txtProcurar].'): '.contaConsulta($consulta)."&nbsp;"._('record(s)'), 'left', $corFundo, 3, 'txtaviso');

			# Paginador
			$urlADD="&textoProcurar=".$matriz[txtProcurar];
			paginador($consulta, contaConsulta($consulta), $limite[lista][usuarios], $registro, 'normal', 3, $urlADD);

			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela(_('Login'), 'center', '40%', 'tabfundo0');
				itemLinhaTabela(_('Status'), 'center', '20%', 'tabfundo0');
				itemLinhaTabela(_('Options'), 'center', '40%', 'tabfundo0');
			fechaLinhaTabela();

			# Setar registro inicial
			if(!$registro) {
				$i=0;
			}
			elseif($registro && is_numeric($registro) ) {
				$i=$registro;
			}
			else {
				$i=0;
			}
			
			
			$limite=$i+$limite[lista][usuarios];
			
			while($i < contaConsulta($consulta) && $i < $limite) {
				# Mostrar registro
				$id=resultadoSQL($consulta, $i, 'id');
				$login=resultadoSQL($consulta, $i, 'login');
				$status=resultadoSQL($consulta, $i, 'status');				
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$id>"._("Change")."</a>",'alterar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>"._("Delete")."</a>",'excluir');
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($login, 'left', '40%', 'normal');
					itemLinhaTabela(checaStatus($status),'center', '20%', 'normal');
					itemLinhaTabela($opcoes, 'center', '40%', 'normal');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem
		fechaTabela();
	} # fecha bot�o procurar
} #fecha funcao de  procura de usuarios





# Fun��o para montar campo de formulario
function formListaUsuarios($idUsuario, $tipo="")
{
	global $conn, $tb;
	
	$consulta=buscaUsuarios($idUsuario, $campo, 'todos', 'login');
	
	if ($tipo!='formnochange') $item="\n<select name=matriz[usuario]";
	else $item="\n<select name=matriz[usuario] onChange=javascript:submit();>";
	
	# Listargem
	$i=0;
	while($i < contaConsulta($consulta)) {
		# Valores dos campos
		$login=resultadoSQL($consulta, $i, 'login');
		$id=resultadoSQL($consulta, $i, 'id');
		
		# Verificar se deve selecionar o usuario na lista
		if($idUsuario==$id) $opcSelect="selected";
		else $opcSelect="";

		# Mostrar servi�o		
		$item.= "<option value=$id $opcSelect>" . _("$login") . "\n";

		#Incrementar contador
		$i++;
	}
	
	$item.="</select>";
	
	return($item);
	
} #fecha funcao de montagem de campo de form



# Fun��o para checagem de grupo
function checaUsuario($idUsuario) {
	
	$consulta=buscaUsuarios($idUsuario, 'id','igual','id');
	
	if($consulta && contaConsulta($consulta)==1) {
		$retorno=resultadoSQL($consulta, 0, 'login');
	}
	else 	$retorno=$consulta;
	
	return($retorno);
}
/**
 * Enter description here...
 *
 * @param unknown_type $idUsuario
 * @param unknown_type $aceita
 * @return unknown
 */
function comentarNomeGrupo( $idUsuario, $aceita='' ){
	global $sessLogin;
	# convidado
	$nomeGrupo = '';
	if ( empty( $sessLogin['login'] ) || $aceita == 'sim' ){
		$consulta = buscaPerfil( $idUsuario, 'id', 'igual', 'id' );
		if ( $consulta && contaConsulta( $consulta )==1 ){
			$perfilComentarGrupo = resultadoSQL( $consulta, 0, 'comentarGrupo' );
			if ($perfilComentarGrupo == 'S' ){
				$perfilIdGrupo = resultadoSQL( buscaPerfil( $idUsuario, 'id', 'igual', 'idGrupo' ), 0, 'idGrupo' );
				$nomeGrupo = resultadoSQL( buscaGrupos( $perfilIdGrupo, 'id', 'igual', 'nome' ), 0, 'nome' );
			}
		}
	}
	return $nomeGrupo;
}

/**
 * Depreciada. Utilize a variavel de sess�o $sessLogin['isCompanyUser']
 *
 * @param unknown_type $tipo
 * @return unknown
 */
function sistemaUsuarioEmpresa( $tipo ){
	global $sessLogin;
	$consulta = buscaUsuariosEmpresas( "upper(login)='$sessLogin[login]'", 'login','custom','id' );
	
	if ( $consulta && contaConsulta($consulta) > 0 ) {
		$tipo = 'usuariosEmpresas';
	}
	
	return $tipo;
}

/**
 * Check if the logged user is a Company User.
 *
 * @author Nash
 * @since 2007-04-13
 * @return boolean
 */
function isCompanyUser(){
	global $sessLogin;
	$consulta = buscaUsuariosEmpresas( "upper(login)=UPPER('{$sessLogin['login']}')", 'login','custom','id' );
	return ( $consulta && contaConsulta($consulta) > 0 );
}

/**
 * Returns the username. 
 * if it is a company user, it searchs the username according the $campo. 
 * For example, when you look for an author in comment, you should use 'idComentario'.
 *
 * @author Nash
 * @since 2007-04-16
 * @param integer $idUsuario
 * @param integer $idTicket
 * @param string $campo
 * @return string
 */
function getUsername( $idUsuario, $idTicket, $campo='idTicket' ){
	global $tb, $conn;

	$consulta = buscaUsuarios($idUsuario,'id','igual','login');
	$username = resultadoSQL($consulta,0,'login');

	if( $username == 'company_user' ){
		if( $campo == 'idComentario' ) {
			$tabela = $tb['ComentarioEmpresaUsuarios'];
		}
		else {
			$tabela = $tb['TicketEmpresaUsuarios'];
		}
		$sql = "SELECT ".
					"{$tb['EmpresasUsuarios']}.login login ".
				"FROM ".
					"{$tb['EmpresasUsuarios']} INNER JOIN $tabela ".
					"ON ({$tb['EmpresasUsuarios']}.id=$tabela.idEmpresaUsuario) ".
				"WHERE ".
					"$tabela.$campo='$idTicket'";
		$consulta = consultaSQL($sql, $conn);
		if( $consulta && contaConsulta($consulta) > 0 ){
			$username = resultadoSQL($consulta, 0, 'login')." ("._("From")." "._("Company").")";
		}
	}
	return $username;
}

/**
 * Verifica se as dados do login de administrador est� correto. 
 *
 * @author Nash
 * @since 2007-04-20
 * @param array $matriz
 * @return boolean
 */
function validaLoginAdm( $matriz ){
	global $tb, $conn;
	$ret = false;
	
//	$sql = "
//	SELECT 
//		u.*
//	FROM 
//		$tb[Usuarios] u
//		INNER JOIN $tb[UsuariosGrupos] ug ON (u.id=ug.idUsuario) 
//		INNER JOIN $tb[Grupos] g ON (ug.idGrupo=g.id) 
//	WHERE
//		u.login='$matriz[loginAdm]'
//		AND u.senha=encrypt('$matriz[pwdAdm]', '$1$')
//		AND u.status='A'
//		AND g.admin='S'";
//	$consulta = consultaSQL($sql, $conn);
//	if( $consulta && contaConsulta($consulta)>0 ){
//		$ret = true;
//	}	

	$sql = "SELECT DISTINCT
		u.*,
		g.admin AS admin
	FROM 
		$tb[Usuarios] u
		INNER JOIN $tb[UsuariosGrupos] ug ON (u.id=ug.idUsuario) 
		INNER JOIN $tb[Grupos] g ON (ug.idGrupo=g.id) 
	WHERE
		u.login='$matriz[loginAdm]'
	GROUP BY id";
	
	$consulta = consultaSQL($sql, $conn);
	if( $consulta && contaConsulta($consulta)>0 ){
		# Verificar usuario
		$usuario = resultadoSQL($consulta, 0, 'login');
		$id = resultadoSQL($consulta, 0, 'id');
		$senhaBanco = resultadoSQL($consulta, 0, 'senha');
		$status = resultadoSQL($consulta, 0, 'status');
		$admin = resultadoSQL($consulta, 0, 'admin');
		if( $status != 'A' ){
			$matriz['pwdAdm'] = '';
		}
		# conferir senha e se � admin
		if( $status == 'A' && $admin == 'S' && $senhaBanco == crypt($matriz['pwdAdm'], $senhaBanco) ) {
			# retornar com autentica��o OK
			$ret = true;
		}
	}
	return $ret;
}

?>