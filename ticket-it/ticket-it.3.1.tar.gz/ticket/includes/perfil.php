<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 21/08/2003
# Ultima altera��o: 27/10/2006
#    Altera��o No.: 005
#
# Fun��o:
#    Painel - Fun��es para cadastro de tickets


# Fun��o para cadastro
function perfil($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;

	# Mostrar menu
	novaTabela2("["._("User Profile")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 4);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('55%', 'left', $corFundo, 0, 'tabfundo1');
				echo "<br><img src=".$html[imagem][perfilg]." border=0 align=left>
				<b class=bold>"._("Profile")."</b><br>
				<br><span class=normal10>"._("Profile and the user's preference for using the")."
				$configAppName.</span>";
			htmlFechaColuna();
			htmlAbreColuna('5%', 'left', $corFundo, 0, 'normal');
				echo "&nbsp;";
			htmlFechaColuna();									
			$texto=htmlMontaOpcao("<br>"._("My Profile"), 'perfil');
			itemLinha($texto, "?modulo=perfil&acao=config", 'center', $corFundo, 0, 'normal');
			$texto=htmlMontaOpcao("<br>"._("Change Password"), 'chave');
			itemLinha($texto, "?modulo=perfil&acao=senha", 'center', $corFundo, 0, 'normal');
		fechaLinhaTabela();
	fechaTabela();
	
	if(!$sub) {
		# Mostrar Status caso n�o seja informada a a��o
		# Inclus�o
		if($acao=="senha") {
			itemTabelaNOURL("&nbsp;", 'left', $corFundo, 0, 'normal');	
			perfilSenha($modulo, $sub, $acao, $registro, $matriz);
		}
		# Configura��es
		elseif($acao=="config") {
			itemTabelaNOURL("&nbsp;", 'left', $corFundo, 0, 'normal');	
			perfilConfig($modulo, $sub, $acao, $registro, $matriz);
		}
	}
} #fecha menu principal 



# Altera��o de senha
function perfilSenha($modulo, $sub, $acao, $registro, $matriz) {

	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $sessLogin;
	
	# Identificar se usu�rio � o mesmo que est� sendo trocada a senha
	// Nash 2007-05-04 - why search a data in DB that has been in session?
	//$idUsuario=buscaIDUsuario($sessLogin[login],'login','igual','id');
	$idUsuario = $sessLogin['id'];
	
	if( $registro == $idUsuario || !$registro && $idUsuario ) {
		
		# Form de inclusao
		if( !$matriz[bntAlterar] ) {
			# Buscar informa��es do usuario
			$consulta=buscaUsuarios($idUsuario, 'id','igual','id');
			
			#verificar consulta
			if($consulta && contaConsulta($consulta)>0) {
				# receber valores
				$id=resultadoSQL($consulta, 0, 'id');
				$login=resultadoSQL($consulta, 0, 'login');
				$senha=resultadoSQL($consulta, 0, 'senha');
				$status=resultadoSQL($consulta, 0, 'status');
			
				# Motrar tabela de busca
				novaTabela2("["._("Changing User's Password")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
					# Opcoes Adicionais
					menuOpcAdicional($modulo, $sub, $acao, $idUsuario);				
					#fim das opcoes adicionais
					novaLinhaTabela($corFundo, '100%');
					$texto="			
						<form method=post name=matriz action=index.php>
						<input type=hidden name=modulo value=$modulo>
						<input type=hidden name=matriz[id] value=$id>
						<input type=hidden name=acao value=$acao>
						<input type=hidden name=matriz[status] value=$status>&nbsp;";
						itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Login:")." </b><br>
							<span class=normal10>"._("Login of the user's access")."</span>";
						htmlFechaColuna();					
						itemLinhaForm($login, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Password:")." </b><br>
							<span class=normal10>"._("Password of the user's access")."</span>";
						htmlFechaColuna();
						$texto="<input type=password name=matriz[senha] size=20>";
						itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Confirm Password:")." </b><br>
							<span class=normal10>"._("Confirm Password of the user's access")."</span>";
						htmlFechaColuna();
						$texto="<input type=password name=matriz[confirma_senha] size=20>";
						itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "&nbsp;";
						htmlFechaColuna();
						$texto="<input type=submit name=matriz[bntAlterar] value="._("Change")." class=submit>";
						itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
				fechaTabela();
			}
			# registro nao encontrado
			else {
				# Mensagem de aviso
				$msg=_("Record not found!");
				$url="?modulo=$modulo&sub=$sub&acao=listar";
				aviso(_("Warning"), $msg, $url, 760);
			}
		} #fecha form
		elseif($matriz[bntAlterar]) {
			# Conferir campos
			if($matriz[senha] && $matriz[confirma_senha]) {
				# conferir senha e confirma��o
				if( $matriz[senha] != $matriz[confirma_senha]){
					# Erro - campo inv�lido
					# Mensagem de aviso
					$msg=_("Password mismatch. Try again");
					$url="?modulo=$modulo&sub=$sub&acao=$acao";
					aviso(_("Warning: Incorrect Data"), $msg, $url, 760);
				}
				# continuar - campos OK
				else {
					# Cadastrar em banco de dados
					$grava=dbUsuario($matriz, 'alterar');
					
					# Verificar inclus�o de registro
					if($grava) {
						# acusar falta de parametros
						# Mensagem de aviso
						$msg=_("Data Recorded Success full!");
						$url="?modulo=$modulo&sub=$sub&acao=listar";
						aviso(_("Warning"), $msg, $url, 760);
						
						# Atualizar senha na session
						$sessLogin[senha]=$matriz[senha];
					}
					
				}
			}
			
			# falta de parametros
			else {
				# acusar falta de parametros
				# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
			}
		}
	}
	else {
		# Mensagem de aviso
		$msg=_("Operation not permitted!");
		$url="?modulo=$modulo";
		aviso(_("Warning"), $msg, $url, 760);	
	}
}




# Altera��o de parametros
function perfilConfig($modulo, $sub, $acao, $registro, $matriz) {

	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $sessLogin;
	
	# Identificar se usu�rio � o mesmo que est� sendo trocada a senha
	$idUsuario=buscaIDUsuario($sessLogin[login],'login','igual','id');

	if($registro == $idUsuario || !$registro && $idUsuario) {
		
		# Form de inclusao
		if(!$matriz[bntConfirmar]) {
			# Buscar informa��es do usuario
			$consulta=buscaUsuarios($idUsuario, 'id','igual','id');
			
			#verificar consulta
			if($consulta && contaConsulta($consulta)>0) {
				# receber valores
				$id=resultadoSQL($consulta, 0, 'id');
				$login=resultadoSQL($consulta, 0, 'login');
				$senha=resultadoSQL($consulta, 0, 'senha');
				$status=resultadoSQL($consulta, 0, 'status');
				
				# Buscar perfil do usuario
				$consultaPerfil=buscaPerfil($id, 'id','igual','id');
				if($consultaPerfil && contaConsulta($consultaPerfil)>0) {
					# Dados do perfil
					$notificar_email=resultadoSQL($consultaPerfil, 0, 'notificar_email');
					$email=resultadoSQL($consultaPerfil, 0, 'email');
					$titulo=resultadoSQL($consultaPerfil, 0, 'titulo_email');
					$idGrupo=resultadoSQL($consultaPerfil, 0, 'idGrupo');
					$diaInicio=resultadoSQL($consultaPerfil, 0, 'diaInicio');
					$diaFim=resultadoSQL($consultaPerfil, 0, 'diaFim');
					$horarioInicio=resultadoSQL($consultaPerfil, 0, 'horarioInicio');
					$horarioFim=resultadoSQL($consultaPerfil, 0, 'horarioFim');
					$grade=resultadoSQL($consultaPerfil, 0, 'grade');
					$alinhaMenu=resultadoSQL($consultaPerfil, 0, 'alinhaMenu');
					$alinhaPrior=resultadoSQL($consultaPerfil, 0, 'alinhaPrior');
					$categoriaPadrao=resultadoSQL($consultaPerfil, 0, 'categoriaPadrao');
					$atualizarUltimos=resultadoSQL($consultaPerfil, 0, 'atualizarUltimos');
					$ordemComentarios=resultadoSQL($consultaPerfil, 0, 'ordemComentarios');
					$comentarGrupo=resultadoSQL($consultaPerfil, 0, 'comentarGrupo');
					$acaoPerfil='alterar';
				}
				else $acaoPerfil='incluir';
			
				# Motrar tabela de busca
				novaTabela2("["._("Parameters configurations")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
					#fim das opcoes adicionais
					novaLinhaTabela($corFundo, '100%');
					$texto="			
						<form method=post name=matriz action=index.php>
						<input type=hidden name=modulo value=$modulo>
						<input type=hidden name=matriz[id] value=$id>
						<input type=hidden name=matriz[acaoPerfil] value=$acaoPerfil>
						<input type=hidden name=acao value=$acao>&nbsp;";
						itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
					fechaLinhaTabela();
					
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Login:")." </b>";
						htmlFechaColuna();					
						itemLinhaForm($login, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Notifications by e-mail:")." </b><br>
							<span class=normal10>"._("Receive notifications by e-mail")."</span>";
						htmlFechaColuna();
						if($notificar_email) $opcNotificar='checked';
						$texto="<input type=checkbox name=matriz[notificar_email] value='S' $opcNotificar>";
						itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("E-mail:")." </b><br>
							<span class=normal10>"._("E-mail address to receive notification")."</span>";
						htmlFechaColuna();
						$texto="<input type=text name=matriz[email] size=60 value='$email'>";
						itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("E-mail title:")." </b><br>
							<span class=normal10>"._("Notification's title sent by e-mail")."</span>";
						htmlFechaColuna();
						$texto="<input type=text name=matriz[titulo_email] size=60 value='$titulo'>";
						itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Default group:")." </b><br>
							<span class=normal10>"._("Select your default group")."</span>";
						htmlFechaColuna();
						itemLinhaForm(formListaGruposUsuario($idUsuario, $idGrupo), 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					# diaInicio
					$texto="<b class=bold>"._("First day:")."</b><br>
							<span class=normal10>"._("Select the first useful day of the week")."</span>";
					if (! $diaInicio) $diaInicio=_('Monday');
					getCampo('combo', $texto, '', getComboSemana($diaInicio, 'matriz[diaInicio]', 'form'));
					
					# dia Fim 
					$texto="<b class=bold>"._("Last day:")."</b><br>
							<span class=normal10>"._("Select the last useful day of the week")."</span>";
					if (! $diaFim) $diaFim=_('Friday');
					getCampo('combo', $texto, '', getComboSemana($diaFim, 'matriz[diaFim]', 'form'));
					
					# horario inicio
					$texto="<b class=bold>"._("Entrance:")."</b><br>
							<span class=normal10>"._("Type the entrance hour (h)")."</span>";
					if (! $horarioInicio) $horarioInicio='8';
					getCampo('text', $texto, 'matriz[horarioInicio]', $horarioInicio,'','','2');
					
					# horario final
					$texto="<b class=bold>"._("Exit:")."</b><br>
							<span class=normal10>"._("Type the exit hour (h)")."</span>";
					if (! $horarioFim) $horarioFim='18';
					getCampo('text', $texto, 'matriz[horarioFim]', $horarioFim,'','','2');
					
					#com grade
					$texto="<b class=bold>"._("Calendar with borders:")."</b><br>
							<span class=normal10>"._("It shows the lines of tables in the calendar")."</span>";
					getCampo('check', $texto, 'matriz[grade]', $grade);
					
					# alinhamento do Menu de Op��es
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Position of the Options Menu:")."</b><br>
							<span class=normal10>"._("Positioning of the Ticket's Options Menu")."</span>";
						htmlFechaColuna();					
						itemLinhaForm(formSelectPosicaoDireitaEsquerda($alinhaMenu, 'alinhaMenu'), 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					# alinhamento da cor da prioridade
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Priority Position:")."</b><br>
							<span class=normal10>"._("Positioning of the indication color of the priority")."</span>";
						htmlFechaColuna();					
						itemLinhaForm(formSelectPosicaoDirEsq($alinhaPrior, 'alinhaPrior'), 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					# alinhamento da cor da prioridade
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Default Category:")."</b><br>
							<span class=normal10>"._("Category automatically selected when opening tickets")."</span>";
						htmlFechaColuna();					
						itemLinhaForm(formCategorias($categoriaPadrao, 'categoriaPadrao'), 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					# alinhamento da cor da prioridade
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Update Last Tickets:")."</b><br>
							<span class=normal10>"._("Update the list of last tickets automatically")."</span>";
						htmlFechaColuna();					
						itemLinhaForm(formSelectSimNao($atualizarUltimos, 'atualizarUltimos', 'form'), 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					# alinhamento da cor da prioridade
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Commentaries Order:")."</b><br>
							<span class=normal10>"._("Commentaries order posted in the ticket")."</span>";
						htmlFechaColuna();					
						itemLinhaForm(formSelectOrdem($ordemComentarios, 'ordemComentarios', 'form'), 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					# alinhamento da cor da prioridade
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Show author like Group:")."</b><br>
							<span class=normal10>"._("Show author like Group Name for guest users")."</span>";
						htmlFechaColuna();					
						itemLinhaForm(formSelectSimNao($comentarGrupo, 'comentarGrupo', 'form'), 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					# botao confirmar
					getBotaoConfirmar( $matriz, _("Confirm") );
					
				fechaTabela();
			}
			# registro nao encontrado
			else {
				# Mensagem de aviso
				$msg=_("Record not found!");
				$url="?modulo=$modulo&sub=$sub&acao=listar";
				aviso(_("Warning"), $msg, $url, 760);
			}
		} #fecha form
		elseif($matriz[bntConfirmar]) {
			# Conferir campos
			if($matriz[email]) {
			
				# Cadastrar em banco de dados
				/* Checar se usuario é novo ou se usuario já exist em banco de dados
					1) Caso já exista em banco de dados, executar acao "alterar"
					2) Caso n�o exista em banco de dados, executar acao "incluir"
				*/ 
				$buscaPerfilUsuario = buscaPerfil($matriz[id], "id", 'igual', 'id');
				if($buscaPerfilUsuario && contaConsulta($buscaPerfilUsuario)>0) $acaoDB='alterar';
				else $acaoDB='incluir';
				
				$grava=dbPerfil($matriz, $acaoDB);
				
				# Verificar inclus�o de registro
				if($grava) {
					# OK 
					$msg=_("Profile modified successful!");
					$url="?modulo=$modulo";
					aviso(_("Warning"), $msg, $url, 760);
				}
			}
			
			# falta de parametros
			else {
				# acusar falta de parametros
				# Mensagem de aviso
				$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
			}
		}
	}
	else {
		# Mensagem de aviso
		$msg=_("Operation not permitted!");
		$url="?modulo=$modulo";
		aviso(_("Warning"), $msg, $url, 760);	
	}
}



# Fun��o para grava��o de dados de perfil
function dbPerfil($matriz, $tipo) {

	global $conn, $tb, $modulo, $sub, $acao;
	
	if($matriz[grade]=='on') $matriz[grade]=1;
	else $matriz[grade]=0;
	
	if($tipo=='alterar') {
		$sql="
			UPDATE 
			{$tb['Perfil']} 
			SET 
				email='{$matriz['email']}', 
				notificar_email='{$matriz['notificar_email']}',
				titulo_email='$matriz[titulo_email]' ,
				idGrupo='$matriz[grupo]',
				diaInicio='$matriz[diaInicio]',
				diaFim='$matriz[diaFim]',
				horarioInicio='$matriz[horarioInicio]',
				horarioFim='$matriz[horarioFim]',
				grade='$matriz[grade]',
				alinhaMenu='$matriz[alinhaMenu]',
				alinhaPrior='$matriz[alinhaPrior]',
				categoriaPadrao='$matriz[categoriaPadrao]',
				atualizarUltimos='$matriz[atualizarUltimos]',
				ordemComentarios='$matriz[ordemComentarios]',
				comentarGrupo='{$matriz['comentarGrupo']}'
			WHERE 
				id=$matriz[id]";
	}
	elseif($tipo=='incluir') {
		$sql="
			INSERT INTO 
				$tb[Perfil] 
			VALUES (
				$matriz[id], 
				'$matriz[notificar_email]', 
				'$matriz[email]',
				'$matriz[titulo_email]',
				'$matriz[grupo]',
				'$matriz[diaInicio]',
				'$matriz[diaFim]',
				'$matriz[horarioInicio]',
				'$matriz[horarioFim]',
				'$matriz[grade]',
				'$matriz[alinhaMenu]',
				'$matriz[alinhaPrior]',
				'$matriz[categoriaPadrao]',
				'$matriz[atualizarUltimos]',
				'$matriz[ordemComentarios]',
				'$matriz[comentarGrupo]'
			)";
	}
	elseif($tipo=='excluir') {
		$sql="DELETE FROM $tb[Perfil] where id='$matriz[id]'";
	}

	elseif($tipo=='excluirusuario') {
		$sql="DELETE FROM $tb[Perfil] where idUsuario='$matriz[id]'";
	}

	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
	
}



# fun��o de busca 
function buscaPerfil($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Perfil] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[Perfil] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[Perfil] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[Perfil] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	
} # fecha fun��o de busca de usuarios



# Fun��o para carregar parametros do perfil do usuairo
function dadosPerfilUsuario($idUsuario) {

	$consulta=buscaPerfil($idUsuario,'id','igual','id');
	
	if($consulta && contaConsulta($consulta)>0) {
		$retorno[id]=resultadoSQL($consulta, 0, 'id');
		$retorno[notificar_email]=resultadoSQL($consulta, 0, 'notificar_email');
		$retorno[email]=resultadoSQL($consulta, 0, 'email');
		$retorno[titulo_email]=resultadoSQL($consulta, 0, 'titulo_email');
		$retorno[idGrupo]=resultadoSQL($consulta, 0, 'idGrupo');
		$retorno[diaInicio]=resultadoSQL($consulta, 0, 'diaInicio');
		$retorno[diaFim]=resultadoSQL($consulta, 0, 'diaFim');
		$retorno[horarioInicio]=resultadoSQL($consulta, 0, 'horarioInicio');
		$retorno[horarioFim]=resultadoSQL($consulta, 0, 'horarioFim');
		$retorno[grade]=resultadoSQL($consulta, 0, 'grade');
		$retorno[alinhaMenu]=resultadoSQL($consulta, 0, 'alinhaMenu');
		$retorno[alinhaPrior]=resultadoSQL($consulta, 0, 'alinhaPrior');
		$retorno[categoriaPadrao]=resultadoSQL($consulta, 0, 'categoriaPadrao');
		$retorno[atualizarUltimos]=resultadoSQL($consulta, 0, 'atualizarUltimos');
		$retorno[ordemComentarios]=resultadoSQL($consulta, 0, 'ordemComentarios');
		$retorno[comentarGrupo]=resultadoSQL($consulta, 0, 'comentarGrupo');
	}

	return($retorno);
}

?>
