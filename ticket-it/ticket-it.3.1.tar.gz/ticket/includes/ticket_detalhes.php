<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 08/03/2004
# Ultima altera��o: 18/08/2006
#    Altera��o No.: 003
#
# Fun��o:
#    Painel - Fun��es para processos de tickets


# fun��o de busca 
function buscaTicketDetalhes($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[TicketDetalhes] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[TicketDetalhes] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[TicketDetalhes] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[TicketDetalhes] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	
} # fecha fun��o de busca


# Detalhes do Ticket
function detalhesTicket($idTicket) {

	$consulta=buscaTicketDetalhes("parametro='email' and idTicket='".(int)$idTicket."'",'','custom','idTicket');
	$contaConsulta = contaConsulta($consulta);
	if( $contaConsulta ) {
		for( $a = 0; $a < $contaConsulta; $a++ ) {
			$retorno[$a] = resultadoSQL( $consulta, $a, 'valor' );
		}
		return($retorno);
	}
}


# Detalhes do Ticket
function carregarEncaminhamentosTicket($idTicket) {

	$consultaNomes=buscaTicketDetalhes("parametro='nome' and idTicket=$idTicket",'','custom','idTicket');
	$consultaEmails=buscaTicketDetalhes("parametro='email' and idTicket=$idTicket",'','custom','idTicket');
	
	if($consultaNomes && contaConsulta($consultaNomes)>0) {
		$i=0;
		for($a=0;$a<contaConsulta($consultaNomes);$a++) {
			$valor=resultadoSQL($consultaNomes, $a, 'valor');
			$id=resultadoSQL($consultaNomes, $a, 'id');
			$retorno[idNome][$i]=$id;
			$retorno[nome][$i++]=$valor;
		}
	}
	if($consultaEmails && contaConsulta($consultaEmails)>0) {
		$i=0;
		for($a=0;$a<contaConsulta($consultaEmails);$a++) {
			$valor=resultadoSQL($consultaEmails, $a, 'valor');
			$id=resultadoSQL($consultaEmails, $a, 'id');
			$retorno[idEmail][$i]=$id;
			$retorno[email][$i++]=$valor;
		}
	}
	
	return($retorno);
}


# Gravar detalhes Ticket
function gravaDetalhesTicket($idTicket, $matriz) {

	global $conn, $tb;
	
	$keys=array_keys($matriz);
	for($a=0;$a<count($keys);$a++) {
	
		$parametro=$keys[$a];
		
		if($parametro=='nome' || $parametro=='email') {
			$valor=addslashes($matriz[$parametro]);
		
			# Gravar
			if($parametro == 'email') $valor=trim($valor);
			$sql="INSERT INTO $tb[TicketDetalhes] VALUES (0, $idTicket, '$parametro','$valor')";
			
			$consulta=consultaSQL($sql, $conn);
		}
	}
}


# Fun��o para grava��o em banco de dados
function dbDetalhesTicket($matriz, $tipo)
{
	global $conn, $tb, $modulo, $acao, $sessLogin;
	
	# Data do sistema 
	$data=dataSistema();
	# Busca o ID do usu�rio logado
	if($sessLogin[login]) $idUser=buscaIDUsuario($sessLogin[login], 'login', 'igual', 'login');
	else $idUser=buscaIDUsuario( 'guest', 'login', 'igual', 'login' );
		
	# Incluir Comentarios
	if($tipo=='incluir') {
	
		$sql="INSERT INTO $tb[TicketDetalhes] VALUES (
			0,
			$matriz[ticket],
			$idUser,
			'$data[dataBanco]',
			'$matriz[descricao]'	
		)";
	} #fecha abertura
	
	elseif($tipo=='excluirtodos') {
		$sql="DELETE FROM $tb[TicketDetalhes] WHERE idTicket='$matriz[id]'";
	}
	
	elseif($tipo=='excluir') {
		$sql="DELETE FROM $tb[TicketDetalhes] WHERE id='$matriz[id]'";
	}
	
	elseif($tipo=='alterar') {
		$sql="UPDATE $tb[TicketDetalhes] SET valor='$matriz[valor]' WHERE id='$matriz[id]'";
	}
	
	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
	
} # fecha fun��o de grava��o em banco de dados


# Fun��o para listagem de detalhes do ticket
function listarDetalhesTicket($modulo, $sub, $acao, $matriz, $registro) {
	
	global $html, $corFundo, $corBorda, $conn;

	# Verificar coment�rios j� postados 
	$sql = "SELECT * from ticket_detalhes WHERE idTicket='$registro' AND parametro <> 'unblock' ORDER BY idTicket";
	$consulta = consultaSQL( $sql, $conn );
	//$consulta=buscaTicketDetalhes($registro, 'idTicket','igual','idTicket');

	# Nash 2007-04-30 - it should show companies users which it'd be sents
	$companyUsers = getCompanyUsersByTicket( $registro );
		
	#nova tabela para mostrar informa��es
	novaTabela(_("Forwards"), 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		if(( !$consulta || contaConsulta($consulta)==0) && !count( $companyUsers ) ) {
			novaLinhaTabela($corFundo, '100%');
				itemLinhaNOURL(_("No forwarded message for this ticket"), 'left', $corFundo, 2, 'txtaviso');
			fechaLinhaTabela();
		}
		else {
			
			# Carregar detalhes do ticket
			$detalhesTicket=carregarEncaminhamentosTicket($registro);
			
			if(is_array($detalhesTicket)) {
				$keys=array_keys($detalhesTicket[nome]);
				
				for($i=0;$i<count($keys);$i++) {
					
					# Detalhes dos encaminhamentos
					$id=resultadoSQL($consulta, $i, 'id');
					
					# Atribuir Valores
					$fundo2=$i%2+3;
					
					novaLinhaTabela($corFundo, '100%');
						if( $modulo=='ticket' ) {
							// nash 2007-04-30 - the separator character is "|" instead ":" now.
							$opcAdicional="<a href=?modulo=ticket&sub=encaminhar&acao=alterar&registro=" . $detalhesTicket[idNome][$i] . "|" . $detalhesTicket[idEmail][$i] . " border=0><img src=" .$html[imagem][alterar] . " border=0></a>";
							$opcAdicional.="<a href=?modulo=ticket&sub=encaminhar&acao=excluir&registro=" . $detalhesTicket[idNome][$i] . "|" . $detalhesTicket[idEmail][$i] . " border=0><img src=" .$html[imagem][fechar] . " border=0></a>";
						}
						else {
							$opcAdicionalNome='';
							$opcAdicionalEmail='';
						}
						
						$texto="$opcAdicional<b>"._("Name:")."</b> " . $detalhesTicket[nome][$i] . " - <b>Email:</b> " . $detalhesTicket[email][$i];
						itemLinhaNOURL("$texto", 'left', $corFundo, 2, "tabfundo$fundo2");
					fechaLinhaTabela();
				}				
			}
			
			if( count($companyUsers) ) {
				novaLinhaTabela($corFundo, '100%');
					itemLinhaNOURL("<b>"._("Users of ")." "._("Companies").":</b> ", 'left', $corFundo, 2, "normal");
				fechaLinhaTabela();
				foreach( $companyUsers as $i => $line ){
					# Atribuir Valores
					$fundo2 = $i % 2 + 3;
					$texto = "<b>"._("User:")."</b> ".$line->login." - <b>Email:</b> ".$line->email;
					novaLinhaTabela($corFundo, '100%');
						itemLinhaNOURL($texto, 'left', $corFundo, 2, "tabfundo$fundo2");
					fechaLinhaTabela();
				}
			}
		}
		
	fechaTabela();	
	# fim da tabela
}



# Fun��o para Form encaminhamento de tickets
function formAlterarEncaminhamento($modulo, $sub, $acao, $matriz, $registro) {
	
	global $html, $corFundo, $corBorda;
	
	novaTabela2(_("Forward Ticket:")." $assunto", 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		# Opcoes Adicionais
		menuOpcAdicional($modulo, $sub, $acao, $registro);				
		#fim das opcoes adicionais
		novaLinhaTabela($corFundo, '100%');
		$texto="			
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=$acao>
			<input type=hidden name=registro value=$registro>";
			itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold>"._("Receiver Name:")." </b><br>
				<span class=normal10>"._("Inform the name, contact or company for destiny")."</span>";
			htmlFechaColuna();
			$texto="<input type=text name=matriz[nome] size=60 value='$matriz[nome]'>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold>"._("E-mail Receiver:")." </b><br>
				<span class=normal10>"._("Inform the receiver e-mails (separate by"). ','.")</span>";
			htmlFechaColuna();
			$texto="<input type=text name=matriz[email] size=60 value='$matriz[email]'>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "&nbsp;";
			htmlFechaColuna();
			$texto="<input type=submit name=matriz[bntAlterar] value="._("Change Forward Address")." class=submit>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();
	
	echo "<br>";
	verTicket($modulo, $sub, 'ver', $matriz, $matriz[idTicket]);
	
}


# Fun��o para Form encaminhamento de tickets
function formExcluirEncaminhamento($modulo, $sub, $acao, $matriz, $registro) {
	
	global $html, $corFundo, $corBorda;
	
	novaTabela2(_("Delete Forward Address"), 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		# Opcoes Adicionais
		menuOpcAdicional($modulo, $sub, $acao, $registro);				
		#fim das opcoes adicionais
		novaLinhaTabela($corFundo, '100%');
		$texto="			
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=$acao>
			<input type=hidden name=registro value=$registro>";
			itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold>"._("Receiver Name:")." </b>";
			htmlFechaColuna();
			itemLinhaForm($matriz[nome], 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold>"._("E-mail Receiver:")." </b>";
			htmlFechaColuna();
			itemLinhaForm($matriz[email], 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "&nbsp;";
			htmlFechaColuna();
			$texto="<input type=submit name=matriz[bntExcluir] value="._("Delete Forward Address")." class=submit>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();
	
	echo "<br>";
	verTicket($modulo, $sub, 'ver', $matriz, $matriz[idTicket]);
	
}



function alterarEncaminhamentoTicket($modulo, $sub, $acao, $matriz, $registro) {
	
	global $corFundo, $corBorda, $sessLogin;
	
	$permissao=buscaPermissaoUsuario($sessLogin[login]);
	
	if(!$permissao[abrir] && !$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
		
		# Buscar dados do ticket para o encaminhamento
		$registros=explode("|",$registro);
		$dadosTicketNome=dadosTicketDetalhe($registros[0]);
		$dadosTicketEmail=dadosTicketDetalhe($registros[1]);
		$ticket=dadosTicket($dadosTicketNome[idTicket]);
		$matriz[idTicket]=$ticket[id];
		
		if(!$matriz[nome] || !$matriz[email] || checkMailDominio($matriz[email], 'check')) {
			if($matriz[bntEncaminhar]) {
				$msg=_("ATTENTION: All the fields should be filled out!");
				$url="?modulo=$modulo&sub=$sub&acao=abrir&registro=$idTicket";
				aviso(_("Warning"), $msg, $url, 760);
				echo "<br>";
			}
			
			# Form de abertura de Ticket
			$matriz[nome]=$dadosTicketNome[valor];
			$matriz[email]=$dadosTicketEmail[valor];
			formAlterarEncaminhamento($modulo, $sub, $acao, $matriz, $registro);
		}
		else {
			# Gravar Nome
			$matriz[id]=$registros[0];
			$matriz[valor]=$matriz[nome];
			$grava=dbDetalhesTicket($matriz, 'alterar');
			
			# Gravar Email
			$matriz[id]=$registros[1];
			$matriz[valor]=$matriz[email];
			$grava=dbDetalhesTicket($matriz, 'alterar');
	
			verTicket($modulo, $sub, 'ver', $matriz, $matriz[idTicket]);
		}
	}
}


function excluirEncaminhamentoTicket($modulo, $sub, $acao, $matriz, $registro) {
	
	global $corFundo, $corBorda, $sessLogin;
	
	$permissao=buscaPermissaoUsuario($sessLogin[login]);
	
	if(!$permissao[abrir] && !$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
		
		# Buscar dados do ticket para o encaminhamento
		$registros=explode("|",$registro);
		$dadosTicketNome=dadosTicketDetalhe($registros[0]);
		$dadosTicketEmail=dadosTicketDetalhe($registros[1]);
		$ticket=dadosTicket($dadosTicketNome[idTicket]);
		$matriz[idTicket]=$ticket[id];
		
		if(!$matriz[bntExcluir]) {
			# Form de abertura de Ticket
			$matriz[nome]=$dadosTicketNome[valor];
			$matriz[email]=$dadosTicketEmail[valor];
			formExcluirEncaminhamento($modulo, $sub, $acao, $matriz, $registro);
		}
		else {
			
			$i=0;
			while($registros[$i]) {
				$matriz[id]=$registros[$i++];
				$grava=dbDetalhesTicket($matriz, 'excluir');
			}
	
			verTicket($modulo, $sub, 'ver', $matriz, $matriz[idTicket]);
		}
	}
}



function dadosTicketDetalhe($registro) {
	global $conn, $tb;
	
	$consulta=buscaTicketDetalhes($registro,'id','igual','id');
	
	if($consulta && contaConsulta($consulta)>0) {
		$retorno[id]=resultadoSQL($consulta, 0, 'id');
		$retorno[idTicket]=resultadoSQL($consulta, 0, 'idTicket');
		$retorno[parametro]=resultadoSQL($consulta, 0, 'parametro');
		$retorno[valor]=resultadoSQL($consulta, 0, 'valor');
	}
	
	return($retorno);

}

/**
 * Grava um parametro para desbloqueiar um ticket relacionada a um inadimplente.
 *
 * @author Nash
 * @since 2007-04-20
 * @param integer $idTicket
 */
function unblockTicket( $idTicket ){
	global $conn, $tb;
	
	$sql = "SELECT * FROM $tb[TicketDetalhes] WHERE idTicket='$idTicket' AND parametro='unblock'";
	$busca = consultaSQL($sql, $conn);
	if( !( $busca && contaConsulta($busca) ) ) {	
		$sql="INSERT INTO $tb[TicketDetalhes] VALUES (0, $idTicket, 'unblock','overdue')";
		consultaSQL($sql, $conn);
	}

}

/**
 * Verifica se este ticket n�o foi desbloqueado 
 *
 * @author Nash
 * @since 2007-04-20
 * @param integer $idTicket
 * @return boolean
 */
function isTicketUnblocked( $idTicket){
	global $conn, $tb;
	$sql = "SELECT * FROM $tb[TicketDetalhes] WHERE idTicket='$idTicket' AND parametro='unblock'";
	$busca = consultaSQL( $sql, $conn );
	$return = ( $busca && contaConsulta($busca) );
	return $return;
}

?>