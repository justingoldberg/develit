<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 29/01/2005
# Ultima altera��o: 18/08/2006
#    Altera��o No.: 002
#
# Fun��o:
#		Fun��es para usu�rios de usuarios empresas (tabela associativa)

function empresasUsuariosEmpresas($modulo, $sub, $acao, $registro, $matriz) {
	
	global $conn, $tb, $corFundo, $corBorda;
	
	# Ver usuario
	verUsuarioEmpresa($modulo, $sub, $acao, $registro, $matriz);
	echo "<br>";
	
	# Lista de Empresas do Usuario
	$sql="
		SELECT
			$tb[UsuariosEmpresas].id,
			$tb[UsuariosEmpresas].idEmpresa,".
//			$tb[UsuariosEmpresas].admin,
			"$tb[EmpresasUsuarios].nome,
			$tb[Empresas].nome EmpresaNome
		FROM
			$tb[UsuariosEmpresas],
			$tb[EmpresasUsuarios],
			$tb[Empresas]
		WHERE
			$tb[Empresas].id = $tb[UsuariosEmpresas].idEmpresa
			AND $tb[EmpresasUsuarios].id = $tb[UsuariosEmpresas].idEmpresaUsuario
			AND $tb[UsuariosEmpresas].idEmpresaUsuario = '$registro'
		ORDER BY
			$tb[Empresas].nome
	";
//ECHO "SQL : ".$sql."<br>";
	$consulta=consultaSQL($sql, $conn);
	
	# Cabe�alho		
	# Motrar tabela de busca
	novaTabela("["._("User's Companies")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
	$tmpOpcao=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=".$acao."adicionar&registro=$registro>"._("Add")."</a>",'incluir');
	itemTabelaNOURL($tmpOpcao, 'right', $corFundo, 3, 'tabfundo1');

	# Caso n�o hajam servicos para o servidor
	if(!$consulta || contaConsulta($consulta)==0) {
		# N�o h� registros
		itemTabelaNOURL(_('There is no companies registered for this user'), 'left', $corFundo, 3, 'txtaviso');
	}
	else {
	
		# Cabe�alho
		novaLinhaTabela($corFundo, '100%');
			itemLinhaTabela(_('Company'), 'center', '80%', 'tabfundo0');
			itemLinhaTabela(_('Administrator'), 'center', '80%', 'tabfundo0');
			itemLinhaTabela(_('Options'), 'center', '20%', 'tabfundo0');
		fechaLinhaTabela();

		$i=0;
		
		$total = contaConsulta($consulta);
		while($i < contaConsulta($consulta)) {
			# Mostrar registro

			$id=resultadoSQL($consulta, $i, 'id');
			$nome=resultadoSQL($consulta, $i, 'nome');
			$empresa = resultadoSQL( $consulta, $i, 'EmpresaNome' );
			
			$opcoes="";
			if ( $total > 1 ){
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=$acao"."excluir&registro=$id>"._("Delete")."</a>",'excluir');
			}
			else{
				$opcoes="---";
			}

			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela($empresa, 'left', '70%', 'normal');
				itemLinhaTabela($nome, 'left', '10%', 'normal');
				itemLinhaTabela($opcoes, 'center', '20%', 'normal');
			fechaLinhaTabela();
			
			# Incrementar contador
			$i++;
		} #fecha laco de montagem de tabela
		
		fechaTabela();
	} #fecha servicos encontrados

	
	
}


# Visualiza��o de maquinas
function verUsuarioEmpresa($modulo, $sub, $acao, $registro, $matriz) {

	global $corFundo, $corBorda, $html;

	# ERRO - Registro n�o foi informado
	if(!$registro) {
		# Mostrar Erro
		$msg=_("Record not found!");
		$url="?modulo=$modulo&sub=$sub&acao=$acao";
		aviso(_("Warning"), $msg, $url, 760);
	}
	elseif($registro) {
	
		# Buscar Valores
		$consulta=buscaUsuariosEmpresas($registro, 'id', 'igual', 'id');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# Mostrar Erro
			$msg=_("Record not found!");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning"), $msg, $url, 760);
		}
		else {
			#atribuir valores
 			$id=resultadoSQL($consulta, 0, 'id');
			$login=resultadoSQL($consulta, 0, 'login');
			$email=resultadoSQL($consulta, 0, 'email');
			$nome=resultadoSQL($consulta, 0, 'nome');
			$fone=resultadoSQL($consulta, 0, 'fone');
			$admin=resultadoSQL($consulta, 0, 'admin');
			$status=resultadoSQL($consulta, 0, 'status');
			
			# Motrar tabela de busca
			novaTabela2("["._("View Company User")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				#fim das opcoes adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);
				getCampo('', _('Login:'), 			'', $login, '', '', 30,'bold10');
				getCampo('', _('Full Name:'), 		'', $nome, '', '', 60,'bold10');
				getCampo('', _('E-mail:'), 			'', $email, '', '', 60,'bold10');
				getCampo('', _('Contact Number:'), 	'', $fone, '', '', 40,'bold10');
				getCampo('', _('Administrator:'), 	'', formSelectSimNao($admin, 'admin', 'check'), '', '', 20,'bold10');
				getCampo('', _('Status:'),			'', formSelectStatus($status, 'status','check'), '', '', 20,'bold10');
			fechaTabela();
		} #fecha alteracao
	} #fecha form - !$bntExcluir
}


function empresasUsuariosEmpresasAdicionar($modulo, $sub, $acao, $registro, $matriz) {
	
	global $conn, $tb, $corFundo, $corBorda;
	
	if($registro && is_numeric($registro) ) {
		
		verUsuarioEmpresa($modulo, $sub, 'ver',$registro, $matriz);
		echo "<br>";
//		# Procurar Empresas
//		$dados=dadosusuariosEmpresas($registro);
		
		if(!$matriz[bntAdicionar]) {
			# Motrar tabela de busca
			novaTabela2("["._("Add Company")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			
	//			# Opcoes Adicionais
	//			menuOpcAdicional($modulo, $sub, $acao, $registro);
	//			#fim das opcoes adicionais
	
				
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=acao value=$acao>
					<input type=hidden name=registro value=$registro>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				
	//			getCampo('text', _('Login'), 			'matriz[login]', $login, '', '', 30,'bold10');
	//			getCampo('text', _('Full name'), 		'matriz[nome]',  $nome,  '', '', 60,'bold10');
	//			getCampo('text', _('E-mail'), 			'matriz[email]', $email, '', '', 60,'bold10');
	//			getCampo('text', _('Contact Number'), 	'matriz[fone]',  $fone,  '', '', 40,'bold10');
	//			getCampo('combo', _('Administrator'), 	'matriz[admin]', formSelectSimNao($admin, 'admin', 'form'), '', '', 20,'bold10');
				getCampo('combo', _('Company'),			'matriz[empresa]', formSelectEmpresas( '','empresa','form'),'', '',	20,'bold10');
				getBotao('matriz[bntAdicionar]', _('Add') );
				
				novaLinhaTabela($corFundo, '100%');
				$texto="</form>";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
			
		}
		else {
			# Adicionar ao banco
			# Buscar ID da Tab. EmpresasUsuarios
			$matriz['id'] = novoIDUsuariosEmpresas();
			# id da tab. EmpresasUsuarios
//			$matriz['idUsuario'] = $dados['id'];
			$matriz['idUsuario'] = $registro;
			$matriz['idEmpresa'] = $matriz['empresa'];
			
			dbRelacionarUsuarioEmpresa( $matriz, 'incluir' );
			
			$msg=_("Data Recorded Success full!");
			$url="?modulo=$modulo&sub=$sub&acao=listar";
//			echo "<br>";
			avisoNOURL(_("Warning"), $msg, 400);
		}
		
	}
	else {
		avisoNOURL(_("ERROR"),_("Invalid User's number record or not informed!"), 400);
		echo "<br>";
	}
	
}

function empresasUsuariosEmpresasExcluir($modulo, $sub, $acao, $registro, $matriz) {
	
	global $conn, $tb, $corFundo, $corBorda;
	
	$idUsuario = resultadoSQL( buscaUsuariosEmpresasEmpresas( $registro, 'id', 'igual', 'id'), 0, 'idEmpresaUsuario');
	$idEmpresa = resultadoSQL( buscaUsuariosEmpresasEmpresas( $registro, 'id', 'igual', 'id' ), 0, 'idEmpresa' );
	$nomeEmpresa = resultadoSQL( buscaEmpresas($idEmpresa, 'id', 'igual', 'id'), 0, 'nome');
	
	if($registro && is_numeric($registro) ) {
		
		verUsuarioEmpresa($modulo, $sub, 'ver',$idUsuario, $matriz);
		echo "<br>";
//		# Procurar Empresas
//		$dados=dadosusuariosEmpresas($registro);
		
		if(!$matriz[bntExcluir]) {
			# Motrar tabela de busca
			novaTabela2("["._("Delete")."&nbsp;"._("Company")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=acao value=$acao>
					<input type=hidden name=registro value=$registro>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaNOURL( _('Company').": $nomeEmpresa", 'center', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					$texto="<input type=hidden name='' value=''>&nbsp;";
					itemLinhaNOURL( $texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				
				getBotao('matriz[bntExcluir]', _('Delete') );
				
				novaLinhaTabela($corFundo, '100%');
				$texto="</form>";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
			
		}
		else {
			# Deletar pelo registro em da Tab. UsuariosEmpresas
			dbRelacionarUsuarioEmpresa( $registro, 'excluir' );
			
			$msg=_("Data Recorded Success full!");
			$url="?modulo=$modulo&sub=$sub&acao=listar";
//			echo "<br>";
			avisoNOURL(_("Warning"), $msg, 400);
		}
		
	}
	else {
		avisoNOURL(_("ERROR"),_("Invalid User's number record or not informed!"), 400);
		echo "<br>";
	}
	
}


# fun��o de busca 
function buscaUsuariosEmpresasEmpresas($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[UsuariosEmpresas] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[UsuariosEmpresas] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[UsuariosEmpresas] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[UsuariosEmpresas] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	
} # fecha fun��o de busca de usuarios

?>