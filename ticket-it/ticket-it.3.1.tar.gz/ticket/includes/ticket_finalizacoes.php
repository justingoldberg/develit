<?php
/*
 * Created on May 17, 2005
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 
 # Fun��o para grava��o em banco de dados
function dbFinalizacoesTicket($matriz, $tipo)
{
	global $conn, $tb, $modulo, $acao, $sessLogin;
	
	# Data do sistema 
	$data=dataSistema();
	# Busca o ID do usu�rio logado
	if($sessLogin[login]) $idUser=buscaIDUsuario($sessLogin[login], 'login', 'igual', 'login');
	else $idUser=buscaIDUsuario( 'guest', 'login', 'igual', 'login' );
		
	# Incluir Comentarios
	if($tipo=='incluir') {
	
		$sql="INSERT INTO $tb[TicketFinalizacoes] VALUES (
			0,
			$matriz[ticket],
			'$sessLogin[id]',
			'$data[dataBanco]',
			'$matriz[duracao]',
			'$matriz[expediente]'	
		)";
	} #fecha abertura

	elseif($tipo=='excluirtodos') {
		$sql="DELETE FROM $tb[TicketFinalizacoes] WHERE idTicket='$matriz[id]'";
	}
	
	elseif($tipo=='excluir') {
		$sql="DELETE FROM $tb[TicketFinalizacoes] WHERE id='$matriz[id]'";
	}
	
	elseif($tipo=='alterar') {
		$sql="UPDATE 
				$tb[TicketFinalizacoes] 
			SET 
				data='$matriz[data]',
				segundos='$matriz[duracao]',
				expediente='$matriz[expediente]'
			WHERE 
				id='$matriz[id]'";
	}	
	
	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
	
} 

?>
