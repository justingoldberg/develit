<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 21/01/2005
# Ultima altera��o: 18/08/2006
#    Altera��o No.: 004
#
# Fun��o:
#		Fun��es para usuarios de empresas

# Menu principal de usuarios
# Fun��o para cadastro de usuarios
function usuariosEmpresas($modulo, $sub, $acao, $registro, $matriz) {
	
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;

	# Buscar informa��es sobre usuario - permiss�es
	$sessLogin=$_SESSION["sessLogin"];	
	$permissao=buscaPermissaoUsuario($sessLogin[login]);

	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {

		# Topo da tabela - Informa��es e menu principal do Cadastro
		novaTabela2("["._("Cadaster of Companies Users")."]", "center", '100%', 0, 3, 1, $corFundo, $corBorda, 4);
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('65%', 'left', $corFundo, 0, 'tabfundo1');
					echo "<br><img src=".$html[imagem][empresa]." border=0 align=left><b class=bold>".
					_("Companies Users")."</b><br><span class=normal10>".
					_("The companies user's cadaster manage the external users,")."&nbsp;".
					_("which will have permission and accompaniment for maintenance of the Tickets in the companies.")."</span>";
				htmlFechaColuna();			
				$texto=htmlMontaOpcao("<br>"._("Add"), 'incluir');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=adicionar", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>"._("Search"), 'procurar');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=procurar", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>"._("List"), 'listar');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=listar", 'center', $corFundo, 0, 'normal');
			fechaLinhaTabela();
		fechaTabela();
		echo "<br>";
		
		# Procurar ou Listar
		if( !$acao || ($acao=='procurar' || $acao=='listar') ) {
			# Listar Usu�rios de Empresas
			procurarUsuariosEmpresas($modulo, $sub, $acao, $registro, $matriz);
		}
		
		# Inclus�o
		elseif($acao=="adicionar") {
			adicionarUsuariosEmpresas($modulo, $sub, $acao, $registro, $matriz);
		}
		# Alterar 
		elseif($acao=="alterar") {
			alterarUsuariosEmpresas($modulo, $sub, $acao, $registro, $matriz);
		}
		# Excluir
		elseif($acao=="excluir") {
			excluirUsuariosEmpresas($modulo, $sub, $acao, $registro, $matriz);
		}
		# Usuarios Empresas
		elseif($acao=="empresas") {
			empresasUsuariosEmpresas($modulo, $sub, $acao, $registro, $matriz);
		}
		
		# Usuarios Empresas Adicionar
		elseif($acao=="empresasadicionar") {
			empresasUsuariosEmpresasAdicionar($modulo, $sub, $acao, $registro, $matriz);
		}

		# Usuarios Empresas Excluir
		elseif($acao=="empresasexcluir") {
			empresasUsuariosEmpresasExcluir($modulo, $sub, $acao, $registro, $matriz);
		}
		
	}
}



# Funcao para cadastro de usuarios
function adicionarUsuariosEmpresas($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $conn, $tb;
	
	# Procurar login
	if($matriz[login]) {
		$consulta=buscaUsuariosEmpresas($matriz[login], 'login','igual','id');
		if($consulta && contaConsulta($consulta)>0) {
			$msgAviso="<span class=txtaviso><center>"._("Unavailable Login!")."&nbsp;"._("Please, inform another login")."</center></span>";
			$matriz[login]='';
		}
	}
	
	# Form de inclusao
	if(!$matriz[bntAdicionar] || $msgAviso) {
		# Motrar tabela de busca
		novaTabela2("["._("Add")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
//			#fim das opcoes adicionais
//			menuOpcAdicional($modulo, $sub, $acao, $registro);
			novaLinhaTabela($corFundo, '100%');
			$texto="			
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=$acao>
				<input type=hidden name=registro value=''>
				$msgAviso
				&nbsp;";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			
			#vejo se existe registro na tab. empresasUsuarios
			$sql="SELECT * FROM $tb[EmpresasUsuarios] ORDER BY id";
			$consulta=consultaSQLHide( $sql, $conn );
			
			getCampo('text', _('Login'),			'matriz[login]', $matriz[login], '', '', 30,'bold10');
			getCampo('text', _('Password'),			'matriz[senha]', $matriz[senha], '', '', 20,'bold10');
			getCampo('', _('Company'), '', formSelectEmpresas($matriz[empresa], 'empresa', 'form'), '', '', 20,'bold10');
			getCampo('text', _('Full name'),		'matriz[nome]', $matriz[nome], 	 '', '', 60,'bold10');
			getCampo('text', _('E-mail'), 		 	'matriz[email]', $matriz[email], '', '', 60,'bold10');
			getCampo('text', _('Contact Number'),	'matriz[fone]', $matriz[fone],  '', '', 40,'bold10');
			getCampo('', _("Administrator"), '', formSelectSimNao( (contaConsulta($consulta)==0 ? 'S' : 'N'), 'admin', (contaConsulta($consulta)==0 ? 'check' : 'form' ) ), '', '', 20,'bold10');
			getCampo('', _('Status'), '', formSelectStatus($matriz[status], 'status','form'), '', '', 20,'bold10');
			getBotao('matriz[bntAdicionar]', _('Add'));
		fechaTabela();
	} #fecha form
//	elseif($matriz[bntAdicionar]) {
	if($matriz[bntAdicionar]) {
		# Conferir campos
		if($matriz[login] && $matriz[senha] && $matriz[empresa]) {
			# Conferir, esse login n�o pode ser o mesmo da tab. usuarios
			$consulta = buscaLoginUsuario( $matriz[login], 'login', 'igual', 'login' );
			
			if( $consulta ){
				# acusar usuario j� cadastrado
				# Mensagem de aviso
				$msg=_("Unavailable Login!")."&nbsp;"._("Please, inform another login");
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
				
			}
			else{
				# Conferir, esse login n�o pode ser o mesmo da tab. usuarios
				$consulta = buscaUsuariosEmpresas( $matriz[login], 'login', 'igual', 'login' );
				if(!$consulta || contaConsulta($consulta)==0 ) {
						# Cadastrar em banco de dados
						$matriz[id]=novoIDEmpresasUsuarios();
						$grava=dbUsuarioEmpresa($matriz, 'incluir');
						
						# Verificar inclus�o de registro
						if($grava) {
							
							# Relacionar Usuario a Empresa
							$matriz[idUsuario]=$matriz[id];
							$matriz[idEmpresa]=$matriz[empresa];
							dbRelacionarUsuarioEmpresa($matriz, 'incluir');
							
							# acusar falta de parametros
							# Mensagem de aviso
							$msg=_("Data Recorded Success full!");
							$url="?modulo=$modulo&sub=$sub&acao=$acao";
							avisoNOURL(_("Warning"), $msg, 400);
						}
						echo "<BR>";
						procurarUsuariosEmpresas($modulo, $sub, 'listar', 0, '');
					
				}
				else{
					# acusar usuario j� cadastrado
					# Mensagem de aviso
					$msg=_("Unavailable Login!")."&nbsp;"._("Please, inform another login");
					$url="?modulo=$modulo&sub=$sub&acao=$acao";
					aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
					
				}
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	}
} # fecha funcao de inclusao de usuarios


# Fun��o para grava��o em banco de dados
function dbUsuarioEmpresa($matriz, $tipo)
{
	global $conn, $tb, $modulo, $sub, $acao;
	
	$data=dataSistema();
	
	# Sql de inclus�o
	if($tipo=='incluir') {
		$tmpLogin=strtoupper($matriz[login]);
		# Verificar se servi�o existe
		$tmpBusca=buscaUsuariosEmpresas("upper(login)='$tmpLogin'", $campo, 'custom', 'id');
		
		# Registro j� existe
		if($tmpBusca && contaConsulta($tmpBusca)>0) {
			# Mensagem de aviso
			$msg=_("Record already exists in the database");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: Error when including record"), $msg, $url, 760);
		}
		else {
			# Criptograma senha
			$senhaBanco=crypt($matriz[senha]);
			$sql="INSERT INTO $tb[EmpresasUsuarios] VALUES (
				'$matriz[id]', 
				'$matriz[login]', 
				'$senhaBanco', 
				'$matriz[senha]', 
				'$data[dataBanco]',
				'',
				'',
				'$matriz[email]',
				'$matriz[nome]',
				'$matriz[fone]',
				'$matriz[admin]',
				'$matriz[status]'
			)";
		}
	} #fecha inclusao
	
	elseif($tipo=='alterar') {
		$senhaBanco=crypt($matriz[senha]);
		$sql="
			UPDATE 
				$tb[EmpresasUsuarios] 
			SET 
				senha='$senhaBanco',
				senha_texto='$matriz[senha]',
				nome='$matriz[nome]',
				fone='$matriz[fone]',
				email='$matriz[email]', ";

		switch ($matriz[status]) {
			case 'C':
				$sql.="dtCancelamento='$data[dataBanco]', ";
				break;		
			case 'I':
				$sql.="dtInativacao='$data[dataBanco]', ";
				break;
		}
		$sql.="
					status='$matriz[status]',
					admin='$matriz[admin]'
				WHERE 
					id=$matriz[id]";
	}

	elseif($tipo=='excluir') {
//muda o status do campo para Cancelado
		$sql="UPDATE $tb[EmpresasUsuarios] SET status='C', dtCancelamento='$data[dataBanco]' WHERE id=$matriz[id]";
	}

	
	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
	
} # fecha fun��o de grava��o em banco de dados


# fun��o de busca 
function buscaUsuariosEmpresas($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[EmpresasUsuarios] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[EmpresasUsuarios] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[EmpresasUsuarios] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[EmpresasUsuarios] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	
} # fecha fun��o de busca de usuarios

# Fun��o para checagem de grupo
function checaUsuarioEmpresa($idUsuario) {
	
	$consulta=buscaUsuariosEmpresas($idUsuario, 'id','igual','id');
//echo "consulta: ";print_r ($consulta); echo "<br>";
	if($consulta && contaConsulta($consulta)==1) {
		$retorno=resultadoSQL($consulta, 0, 'login');
	}
	else 	$retorno=$consulta;
	
	return($retorno);
}


# Fun��o para procura de servi�o
function procurarUsuariosEmpresas($modulo, $sub, $acao, $registro, $matriz)
{
	global $conn, $tb, $corFundo, $corBorda, $html, $limite, $textoProcurar;
	
	# Atribuir valores a vari�vel de busca
	if($textoProcurar) {
		$matriz[bntProcurar]=1;
		$matriz[txtProcurar]=$textoProcurar;
	} #fim da atribuicao de variaveis
	
	# Motrar tabela de busca
	novaTabela2("["._("Search")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('30%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b>"._("Search for:")."</b>";
			htmlFechaColuna();
			$texto="
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=procurar>
			<input type=hidden name=nulo value=nulo>
			<input type=text name=matriz[txtProcurar] size=40 value='$matriz[txtProcurar]'>
			<input type=submit name=matriz[bntProcurar] value="._("Search")." class=submit>
			";
			itemLinhaForm($texto, 'left','middle', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();

	# Caso bot�o procurar seja pressionado
	if( ($matriz[txtProcurar] && $matriz[bntProcurar]) || $acao=='listar' || !$acao) {
		#buscar registros
		if($acao=='listar' || !$acao) $consulta=buscaUsuariosEmpresas('','','todos','login ASC');
		else {
			$consulta=buscaUsuariosEmpresas(
				"upper(login) like '%$matriz[txtProcurar]%' 
				OR upper(email) like '%$matriz[txtProcurar]%'
				OR upper(fone) like '%$matriz[txtProcurar]%'
				OR upper(nome) like '%$matriz[txtProcurar]%'",
				$campo, 
				'custom',
				'login'
			);
		}

		echo "<br>";

		novaTabela("["._("Results")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 5);
	
		if(!$consulta || contaConsulta($consulta)==0 ) {
			# N�o h� registros
			itemTabelaNOURL(_('No record found'), 'left', $corFundo, 5, 'txtaviso');
		}
		elseif($consulta && contaConsulta($consulta)>0 && (!$registro || is_numeric($registro)) ) {	
		
			if($acao != 'listar' && $acao) itemTabelaNOURL('Registros encontrados procurando por ('.$matriz[txtProcurar].'): '.contaConsulta($consulta).' registro(s)', 'left', $corFundo, 5, 'txtaviso');

			# Paginador
			$urlADD="&textoProcurar=".$matriz[txtProcurar];
			# Paginador
			paginador($consulta, contaConsulta($consulta), $limite[lista][usuariosempresas], $registro, 'normal10', 5, $urlADD);
		
			# Cabe�alho
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela(_('Login'), 'center', '10%', 'tabfundo0');
				itemLinhaTabela(_('Name'), 'center', '25%', 'tabfundo0');
				itemLinhaTabela(_('Companies'), 'center', '35%', 'tabfundo0');
				itemLinhaTabela(_('Status'), 'center', '10%', 'tabfundo0');
				itemLinhaTabela(_('Options'), 'center', '20%', 'tabfundo0');
			fechaLinhaTabela();

			# Setar registro inicial
			if(!$registro) {
				$i=0;
			}
			elseif($registro && is_numeric($registro) ) {
				$i=$registro;
			}
			else {
				$i=0;
			}

			$limite=$i+$limite[lista][empresas];
			
			while($i < contaConsulta($consulta) && $i < $limite) {
				# Mostrar registro
				$id=resultadoSQL($consulta, $i, 'id');
				$nome=resultadoSQL($consulta, $i, 'nome');
				$login=resultadoSQL($consulta, $i, 'login');
				$status=resultadoSQL($consulta, $i, 'status');
				
				# Buscar Empresas do Usu�rio
				$consultaEmpresas=buscaRegistro($id, 'idEmpresaUsuario', 'igual', 'id', $tb[UsuariosEmpresas]);
				if($consultaEmpresas && contaConsulta($consultaEmpresas)>0) {
					$empresas='';
					for($a=0;$a<contaConsulta($consultaEmpresas);$a++) {
						$idEmpresa=resultadoSQL($consultaEmpresas, $a, 'idEmpresa');
						$empresas.=formSelectEmpresas($idEmpresa, '', 'check');
					
						if( ($a+1) < contaConsulta($consultaEmpresas)) $empresas.="<BR>";

					}
				}
				else {
					$empresas='&nbsp;';
				}
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=empresas&registro=$id>"._("Companies")."</a>",'empresas');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$id>"._("Change")."</a>",'alterar');
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>"._("Delete")."</a>",'excluir');
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($login, 'center', '10%', 'normal10');
					itemLinhaTabela($nome, 'left', '25%', 'normal8');
					itemLinhaTabela($empresas, 'left', '35%', 'normal10');
					itemLinhaTabela(formSelectStatus($status,'','check'), 'center', '10%', 'normal10');
					itemLinhaTabela($opcoes, 'left', '20%', 'normal8 nowrap');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem
		
		fechaTabela();
	} # fecha bot�o procurar
} #fecha funcao de  procurar 


/**
 * Relacionar Usuarios Empresas a Empresas
 *
 * @param array $matriz (campos: id, idEmpresa, idUsuario)
 * @param string $tipo (incluir, alterar, excluir, excluirusuario, excluirempresa)
 */
function dbRelacionarUsuarioEmpresa($matriz, $tipo) {
	global $conn, $tb;
	if($tipo=='incluir') {
//		$sql="INSERT INTO $tb[UsuariosEmpresas] VALUES (0, '$matriz[idUsuario]', '$matriz[idEmpresa]', '$matriz[admin]')";

		$sql="INSERT INTO $tb[UsuariosEmpresas] VALUES ('', '$matriz[idUsuario]', '$matriz[idEmpresa]')";
	}
	elseif($tipo=='excluir') {
		$sql="DELETE FROM $tb[UsuariosEmpresas] WHERE id='$matriz'";
	}
	elseif($tipo=='alterar') {
		$sql="UPDATE $tb[UsuariosEmpresas] SET idUsuario='$matriz[idUsuario]', idEmpresa='$matriz[idEmpresa] WHERE id='$matriz[id]'";
	}
	elseif($tipo=='excluirusuario') {
//		$sql="DELETE FROM $tb[UsuariosEmpresas] WHERE idEmpresaUsuario='$matriz[idUsuario]'";
	}
	elseif($tipo=='excluirempresa') {
		$sql="DELETE FROM $tb[UsuariosEmpresas] WHERE idEmpresa='$matriz[idEmpresa]'";
	}
	if($sql) {
		$consulta=@consultaSQL($sql, $conn);
	}
}


/**
 * Buscar novo ID para EmpresasUsuarios (cadastro de usuarios de empresas)
 *
 * @return int $id
 */
function novoIDEmpresasUsuarios() {
	
	global $conn, $tb;
	
	$sql="SELECT MAX(id)+1 id FROM $tb[EmpresasUsuarios]";
	
	$consulta=consultaSQL($sql, $conn);
	
	if($consulta && contaConsulta($consulta)>0) {
		$id=resultadoSQL($consulta, 0, 'id');
		
		if(!$id || $id<=0 || !is_numeric($id)) {
			$id=1;
		}
	}
		
	return $id;
}

/**
 * Buscar novo ID para UsuariosEmpresas
 *
 * @return int $id
 */
function novoIDUsuariosEmpresas() {
	
	global $conn, $tb;
	
	$sql="SELECT MAX(id)+1 id FROM $tb[UsuariosEmpresas]";
	
	$consulta=consultaSQL($sql, $conn);
	
	if($consulta && contaConsulta($consulta)>0) {
		$id=resultadoSQL($consulta, 0, 'id');
		
		if(!$id || $id<=0 || !is_numeric($id)) {
			$id=1;
		}
	}
		
	return $id;
}


/**
 * 
 */
# Funcao para cadastro de usuarios
function excluirUsuariosEmpresas($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Procurar login
	$consulta=buscaUsuariosEmpresas($registro, 'id','igual','id');
	
	# Form de inclusao
	if(!$matriz[bntExcluir] || $msgAviso) {
		
		$id=resultadoSQL($consulta, 0, 'id');
		$login=resultadoSQL($consulta, 0, 'login');
		$email=resultadoSQL($consulta, 0, 'email');
		$nome=resultadoSQL($consulta, 0, 'nome');
		$fone=resultadoSQL($consulta, 0, 'fone');
		$status=resultadoSQL($consulta, 0, 'status');
		
		# Motrar tabela de busca
		novaTabela2("["._("Delete")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
//			#fim das opcoes adicionais
//			menuOpcAdicional($modulo, $sub, $acao, $registro);
			novaLinhaTabela($corFundo, '100%');
			$texto="			
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=$acao>
				<input type=hidden name=registro value='$id'>
				$msgAviso
				&nbsp;";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			getCampo('', _('Login'), '', $login, '', '', 30,'bold10');
			getCampo('', _('Full name'), '', $nome, '', '', 60,'bold10');
			getCampo('', _('E-mail'), '', $email, '', '', 60,'bold10');
			getCampo('', _('Contact Number'), '', $fone, '', '', 40,'bold10');
			getCampo('', _('Status'), '', formSelectStatus($status, 'status','check'), '', '', 20,'bold10');
			getBotao('matriz[bntExcluir]', _('Delete'));
		fechaTabela();
	} #fecha form
//	elseif($matriz[bntExcluir]) {
	if($matriz[bntExcluir]) {
		$matriz[id]=$registro;
		dbUsuarioEmpresa($matriz, 'excluir');
		
		# Relacionar Usuario a Empresa
		$matriz[idUsuario]=$registro;
//		dbRelacionarUsuarioEmpresa($matriz, 'excluirusuario'); // SEN�O APAGA O RELACIONAMENTO
		
		# Mensagem de aviso
		$msg=_("Record deleted Success Full!");
		avisoNOURL(_("Warning"), $msg, 400);
		echo "<BR>";
		
		procurarUsuariosEmpresas($modulo, $sub, 'listar', 0, '');
	}
} # fecha funcao de inclusao de usuarios



# Funcao para cadastro de usuarios
function alterarUsuariosEmpresas($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $tb, $configAppVersion, $corFundo, $corBorda, $html;

	$consulta=buscaRegistro($registro, 'id','igual','id', $tb[EmpresasUsuarios]);
	
	# Form de inclusao
	if(!$matriz[bntAlterar] || !$matriz[senha] || !$matriz[nome]) {
		
		if(!$matriz[bntAlterar]) {
			$matriz[login]=resultadoSQL($consulta, 0, 'login');
			$matriz[email]=resultadoSQL($consulta, 0, 'email');
			$matriz[senha]=resultadoSQL($consulta, 0, 'senha_texto');
			$matriz[nome]=resultadoSQL($consulta, 0, 'nome');
			$matriz[fone]=resultadoSQL($consulta, 0, 'fone');
			$matriz[admin]=resultadoSQL($consulta, 0, 'admin');
			$matriz[status]=resultadoSQL($consulta, 0, 'status');
		}
		
		# Motrar tabela de busca
		novaTabela2("["._("Change")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
//			#fim das opcoes adicionais
//			menuOpcAdicional($modulo, $sub, $acao, $registro);
			novaLinhaTabela($corFundo, '100%');
			$texto="			
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=$acao>
				<input type=hidden name=registro value='$registro'>
				&nbsp;";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			getCampo('', _('Login'), '', $matriz[login], '', '', 30,'bold10');
			getCampo('text', _('Password'), 'matriz[senha]', $matriz[senha], '', '', 20,'bold10');
			getCampo('text', _('Full name'), 'matriz[nome]', $matriz[nome], '', '', 60,'bold10');
			getCampo('text', _('E-mail'), 'matriz[email]', $matriz[email], '', '', 60,'bold10');
			getCampo('text', _('Contact Number'), 'matriz[fone]', $matriz[fone], '', '', 40,'bold10');
			getCampo('', _("Administrator"), '', formSelectSimNao( $matriz[admin], 'admin', 'form' ), '', '', 20,'bold10');
			getCampo('', _('Status'), '', formSelectStatus($matriz[status], 'status','form'), '', '', 20,'bold10');
			getBotao('matriz[bntAlterar]', _('Change'));
		fechaTabela();
	} #fecha form
	elseif($matriz[bntAlterar]) {
		$matriz[id]=$registro;
		$grava=dbUsuarioEmpresa($matriz, 'alterar');
			
		# Verificar inclus�o de registro
		if($grava) {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Data Recorded Success full!");
			avisoNOURL(_("Warning"), $msg, 400);
			
		}
		#erro
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("An error occurred during the modification of the record.")."&nbsp;"._("Contact the administrator!");
			avisoNOURL(_("Warning: An error has been ocurred"), $msg, 400);
		}
		
		echo "<BR>";
		procurarUsuariosEmpresas($modulo, $sub, 'listar', 0, '');
		
	}
} # fecha funcao de inclusao de usuarios


/**
 * Retona array com todos os campos do BD para o registro de EmpresasUsuarios informado
 *
 * @param int $registro Empresas Usuarios
 * @return array com recordset para registro
 */
function dadosusuariosEmpresas($registro) {
	
	$consulta=buscaUsuariosEmpresas($registro, 'id','igual','id');
	
	if($consulta && contaConsulta($consulta)>0) {
		$retorno[id]=resultadoSQL($consulta, 0, 'id');
		$retorno[login]=resultadoSQL($consulta, 0, 'login');
		$retorno[senha]=resultadoSQL($consulta, 0, 'senha');
		$retorno[senha_texto]=resultadoSQL($consulta, 0, 'senha_texto');
		$retorno[dtCriacao]=resultadoSQL($consulta, 0, 'dtCriacao');
		$retorno[dtInativacao]=resultadoSQL($consulta, 0, 'dtInativacao');
		$retorno[dtCancelamento]=resultadoSQL($consulta, 0, 'dtCancelamento');
		$retorno[email]=resultadoSQL($consulta, 0, 'email');
		$retorno[nome]=resultadoSQL($consulta, 0, 'nome');
		$retorno[fone]=resultadoSQL($consulta, 0, 'fone');
		$retorno[admin]=resultadoSQL($consulta, 0, 'admin');
		$retorno[status]=resultadoSQL($consulta, 0, 'status');
	}
	
	return($retorno);
	
}

##########################################################################################################################################
###############################																			  ################################
#############################################		SISTEMA DE LOGIN PARA USUARIO_EMPRESA		##########################################
###############################																			  ################################
##########################################################################################################################################

# Fu��o para visualiza��o de tickets de um usuario logado como UsuarioEmpresa 
function verTicketUsuarioEmpresa() {


	global $conn, $tb, $corFundo, $corBorda, $html, $sessLogin, $modulo, $sessNavegacao;

//	# Motrar tabela
//	$opcoes=htmlMontaOpcao("<a href=?modulo=$modulo&acao=adicionar class=titulo>"._("New Ticket")."</a>",'incluir');
//	$opcoes.="&nbsp;&nbsp;".htmlMontaOpcao("<a href=?modulo=$modulo&acao=procurar class=titulo>"._("Search")."</a>",'procurar');
	
//	htmlAbreTabelaSH('center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
//		htmlAbreLinha($corBorda);
//			itemLinhaTMNOURL("["._("Tickets")."]", 'left', 'middle', '60%', $corFundo, 2, 'tabtitulo');
//			itemLinhaNOURL($opcoes, 'right', $corFundo, 0, 'tabtitulo');
//		htmlFechaLinha();
//	fechaTabela();
//	novaTabela2SH("right", '100%', 0, 2, 1, $corFundo, $corBorda, 0);
	novaTabela2SH("right", '100%', 0, 2, 0, $corFundo, $corBorda, 0);
		novaLinhaTabela($corFundo, '100%');
		
			htmlAbreColuna('100%', 'right', $corFundo, 2, 'normal');
				# Colunas e quadros de estat�ticas e mostragem de tickets
				htmlAbreTabelaSH('center', '100%', 0, /*5*/5, 0, $corFundo, $corBorda, 2);
				
					novaLinhaTabela($corFundo, '100%');
						# Coluna de Meus Tickets
						htmlAbreColunaForm('50%', 'right','top', $corFundo, 0, 'normal');
							# Buscar as empresas que pertence o UsuarioEmpresa
							$idEmpresa=buscaIDsEmpresaUE($sessLogin['login']);
							# Os usuarios tem que serem convidados
							$idUser=buscaIDUsuario( 'guest', 'login', 'igual', 'login' );
							meusTicketsUsuarioEmpresa( $idUser, $idEmpresa /*$usuario*/ );
						htmlfechaColuna();
						
						# Coluna de Informa��es de Grupo
						htmlAbreColunaForm('50%', 'right', 'top', $corFundo, 0, 'normal');
							# Tickets de Grupo
							htmlAbreTabelaSH('left', '100%', 0, 0, 0, $corFundo, $corBorda, 0);
								novaLinhaTabela($corFundo, '100%');
									htmlAbreColunaForm('100%', 'right', 'top', $corFundo, 0, 'normal');
										novaTabela2("["._("Host")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
											novaLinhaTabela($corFundo, '100%');
												
												# Sele��o de maquinas por empresa
												$sql="
													SELECT 
														Maquinas.id id, 
														Maquinas.nome nome, 
														Maquinas.ip ip 
													FROM 
														Maquinas INNER JOIN Empresas ON (Maquinas.idEmpresa=Empresas.id) 
													WHERE 
														Maquinas.idEmpresa IN ($idEmpresa) 
														AND Empresas.status='A' 
												";
												$consulta=consultaSQL($sql,$conn);
												if(!$consulta || contaConsulta($consulta)==0) {
													# N�o h� registros
													itemTabelaNOURL(_('There are not registered record'), 'left', $corFundo, 3, 'txtaviso');
												}
												else {
													
													# Cabe�alho
													novaLinhaTabela($corFundo, '100%');
														itemLinhaTabela( _('Name'), 'center', '65%', 'tabfundo0');
														itemLinhaTabela( _('IP'), 	'center', '35%', 'tabfundo0');
//														itemLinhaTabela(_('Options'), 'center', '10%', 'tabfundo0');
													fechaLinhaTabela();
													
													# Setar registro inicial
													if(!$registro) {
														$i=0;
													}
													elseif($registro && is_numeric($registro) ) {
														$i=$registro;
													}
													else {
														$i=0;
													}
														
													while( $i < contaConsulta($consulta) /*&& $i < $limite*/ ) {
														# Mostrar registro
														$id=resultadoSQL($consulta, $i, 'id');
														$nome=resultadoSQL($consulta, $i, 'nome');
														$ip=resultadoSQL($consulta, $i, 'ip');
														$url="?modulo=maquinaUE&acao=verUE&registro=$id";
														$fundo=$i%2+1;
														
														novaLinhaTabela($corFundo, '100%');
															itemLinhaTM($nome, $url, 'left', 'middle','65%', $corFundo, 0, /*'normal'*/"tabfundo$fundo");
//															itemLinhaTabela( $nome,  'left',  '65%', 'normal' );
															itemLinhaTabela( $ip, 	'center', '35%', "tabfundo$fundo"/*'normal'*/ );
														fechaLinhaTabela();
														
														# Incrementar contador
														$i++;
													} #fecha laco de montagem de tabela
												} #fecha listagem
												
												
											fechaLinhaTabela();
										fechaTabela();
									htmlFechaColuna();
								htmlFechaLinha();
								itemTabelaNOURL('&nbsp;', 'left', $corFundo, 0, 'normal');
							fechaTabela();
						htmlfechaColuna();
					htmlFechaLinha();
				fechaTabela();
			htmlfechaColuna();
		htmlFechaLinha();
	fechaTabela();	
	
//	listarUltimosTicketsUsuario(buscaIDUsuario($sessLogin[login], 'login','igual','id'), $sessNavegacao[grupo]);
	

} #fecha status 


?>