<?
################################################################################
# Fun��o:
#    Painel - Fun��es para cadastro de tickets

/* Desafio de imagem */
require_once("class/captcha.php");

# Fun��o para cadastro
function protocolo($modulo, $sub, $acao, $registro, $matriz) {
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Carregar Frame
	if($acao=='ver') {
		echo "<frameset rows=0,* border=1>";
		echo "<frame name=none  src=?modulo=protocolo&acao=atualizar&registro=$registro>";
		echo "<frame name=chatprotocolo src=?modulo=protocolo&acao=verprotocolo&registro=$registro>";
		echo "</frameset>";
	}

	# Mostrar Status caso n�o seja informada a a��o
	# Procurar
	elseif(!$acao || $acao=="procurar") {
		procurarProtocolo($modulo, $sub, $acao, $registro, $matriz);
	}
	elseif($sub=='feedback') {
		ticketFeedback($modulo, $sub, $acao, $registro, $matriz);
	}
	elseif($acao=='verprotocolo' || $acao=='comentar' || $acao=='incluir') {
		novaTabela2SH('left',768,0,0,0,$corFundo,$corBorda,0);
		htmlAbreLinha($corFundo);
			htmlAbreColuna(768,'left',$corFundo,0,'normal10');
				verTicketProcotolo($modulo, $sub, $acao, $registro, $matriz);
			htmlFechaColuna();
		htmlFechaLinha();
		fechaTabela();
	}
	elseif($acao=='atualizar') {
		# Checar Chat
		$idTicket=buscaIDTicket($registro,'protocolo','igual','id');
		
		if($idTicket) {
			if(checkChatTicket($idTicket)) {
			echo "
				<script>
					novaJanela(\"?modulo=ticket&sub=chat&acao=montar&registro=$idTicket\",\"chatprotocolo$idTicket\",\"width=640,height=600,resizable=No,scrollbars=Yes,title=ChatOnline,toolbar=No\");
				</script>
				";
			}
		}
		else {
			echo "<meta http-equiv=refresh content=2;URL=?modulo=protocolo&acao=atualizar&registro=$registro>";
		}
	}
} #fecha menu principal

# Fun��o para procura de protocolo
# Fun��o para procura 
function procurarProtocolo($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $conn, $tb, $corFundo, $corBorda, $html, $limite, $textoProcurar, $sessLogin;
	if( $sessLogin['isCompanyUser'] ){
		$UE = "UE";
	}
	else {
		$idUsuario = $sessLogin['id'];
		//$idUsuario = buscaIDUsuario( $sessLogin[login], 'login', 'igual', 'id' );
		
		# Buscar Grupos do Usuario
		$gruposUsuario=buscaUsuariosGrupos($idUsuario,'idUsuario','igual','idUsuario');
		for($a=0;$a<contaConsulta($gruposUsuario);$a++) {
			$idGrupo=resultadoSQL($gruposUsuario, $a, 'idGrupo');
			
			$sqlADD.="$tb[Grupos].id = $idGrupo";
			
			if($a+1 < contaConsulta($gruposUsuario)) $sqlADD.=" OR ";
		}
		
	}
	
	novaTabela2("["._("Protocols")."]", "center", '100%', 0, 3, 1, $corFundo, $corBorda, 3);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('65%', 'left', $corFundo, 0, 'tabfundo1');
				echo "<br><img src=".$html[imagem][protocolos]." border=0 align=left >
				<b class=bold>"._("Protocols")."</b>
				<br><span class=normal10>"._("Protocols are used for")."&nbsp;".
				_("best to organize and to classify the technical calls of supports,")."&nbsp;".
				_("attendances and occurrences managed by the")."&nbsp;".$configAppName."</span>";
			htmlFechaColuna();			
			$texto=htmlMontaOpcao("<br>"._("New Ticket"), 'relatorio');
			itemLinha($texto, "?modulo=ticket$UE&acao=adicionar$UE", 'center', $corFundo, 0, 'normal');
			$texto=htmlMontaOpcao("<br>"._("Search"), 'procurar');
			itemLinha($texto, "?modulo=ticket$UE&acao=procurar$UE", 'center', $corFundo, 0, 'normal');
		fechaLinhaTabela();
	fechaTabela();
	
	# Atribuir valores a vari�vel de busca
	if($textoProcurar) {
		$matriz[bntProcurar]=1;
		$matriz[txtProcurar]=$textoProcurar;
	} #fim da atribuicao de variaveis
	
	echo "<br>";
	# Motrar tabela de busca
	novaTabela2("["._("Search Protocol")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b>"._("Inform the protocol identification:")."</b>";
			htmlFechaColuna();
			$texto="
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=procurar$UE>
			<input type=hidden name=matriz[idEmpresa] value=$idEmpresa>
			<input type=text name=matriz[txtProcurar] size=30 value='$matriz[txtProcurar]'>
			<input type=submit name=matriz[bntProcurar] value="._("Search")." class=submit>";
			itemLinhaForm($texto, 'left','middle', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();

	# Caso bot�o procurar seja pressionado
	if($matriz[txtProcurar] && $matriz[bntProcurar]) {
		#buscar registros
		if( $sessLogin['isCompanyUser'] ){
				# Procurar ver as empresas q o USUARIO-EMPRESA esta relacionado
				$idEmpresa = buscaIDsEmpresaUE( $sessLogin['login'] );
				
				# somente poder� ver os ticket relacionado a empresa, qdo os mesmos foram criados por usuarios convidados.
				$idUsuario = buscaIDUsuario( 'guest', 'login', 'igual', 'id' );
				$sql="
					SELECT 
						idTicket id, 
						assunto, 
						ticket.data, 
						idUsuario, 
						idPrioridade, 
						idCategoria, 
						ticket.status status, 
						protocolo,
						idEmpresa 
					FROM
						ticket INNER JOIN ticket_empresa ON ( ticket.id = ticket_empresa.idTicket ) 
						INNER JOIN Empresas ON (ticket_empresa.idEmpresa = Empresas.id) 
					WHERE
						ticket_empresa.idEmpresa in ($idEmpresa) 
						AND Empresas.status = 'A' 
						AND ticket.idUsuario = $idUsuario 
						AND protocolo LIKE '%$matriz[txtProcurar]%' 
					ORDER BY ticket.data DESC";
				$consulta=consultaSQL($sql, $conn);
		}
		else{
				$consulta=buscaTicket($matriz[txtProcurar],'protocolo','contem','data DESC');
		}
		
		echo "<br>";
		novaTabela("["._("Found protocols")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 5);
	
		if(!$consulta || contaConsulta($consulta)==0 ) {
			# N�o h� registros
			itemTabelaNOURL(_('No record found'), 'left', $corFundo, 5, 'txtaviso');
		}
		elseif($consulta && contaConsulta($consulta)>0 && (!$registro || is_numeric($registro)) ) {	
		
			itemTabelaNOURL(_('Found records looking for').' ('.$matriz[txtProcurar].'): '.contaConsulta($consulta)."&nbsp;"._('record(s)'), 'left', $corFundo, 5, 'txtaviso');
			
			# Paginador
			$urlADD="&textoProcurar=".$matriz[txtProcurar];
			paginador($consulta, contaConsulta($consulta), $limite[lista][tickets], $registro, 'normal', 5, $urlADD);
			
			htmlAbreLinha($corBorda);
				itemLinhaTMNOURL(_('Subject'), 'center', 'middle','40%', $corFundo, 0, "titulo");
				itemLinhaTMNOURL(_('Creation Date'), 'center', 'middle','15%', $corFundo, 0, "titulo");
				itemLinhaTMNOURL(_('Status'), 'center', 'middle','5%', $corFundo, 0, "titulo");
				itemLinhaTMNOURL(_('Category'), 'center', 'middle','20%', $corFundo, 0, "titulo");
				itemLinhaTMNOURL(( $sessLogin['isCompanyUser'] ? _('Company') : _('Created by') ), 'center', 'middle','10%', $corFundo, 0, "titulo");
			htmlFechaLinha();
	
			# Setar registro inicial
			if(!$registro) {
				$i=0;
			}
			elseif($registro && is_numeric($registro) ) {
				$i=$registro;
			}
			else {
				$i=0;
			}
			
			$limite=$i+$limite[lista][usuariosempresas];
			
			while($i < contaConsulta($consulta) && $i < $limite) {			
				# Verificar se registro est� na matriz de tickets selecionads
				$id=resultadoSQL($consulta, $i, 'id');
				$assunto=resultadoSQL($consulta, $i, 'assunto');
				$data=resultadoSQL($consulta, $i, 'data');
				$usuario=resultadoSQL($consulta, $i, 'idUsuario');
				$idPrioridade=resultadoSQL($consulta, $i, 'idPrioridade');
// by nash 30/04/2007				
//				if( $sessLogin['isCompanyUser'] ){
//					# Nome da Empresa
//					$empresa=resultadoSQL( $consulta, $i, 'idEmpresa' );
//					$nome = resultadoSQL( buscaEmpresas( $empresa, 'id', 'igual', 'id' ), 0, 'nome');
//				}
//				else{
//					# aki, se nao axar da um convidado
//					$nome = _(checaUsuario($usuario));					
//				}
				//$nome = getUsername($usuario, $id);
				$nome = getUserOrCompany( $usuario, $id );

				if($idPrioridade) {
					$prioridade=checaPrioridade($idPrioridade);
					
					# Procurar categoria
					$corFundo=$prioridade[cor];
				}
				
				$idCategoria=resultadoSQL($consulta, $i, 'idCategoria');
				if($idCategoria) {
					$categoria=checaCategoria($idCategoria);
				}
				else {
					$categoria='xxx';
				}
					
				$status=buscaUltimoStatusTicket($id);
	
				# Mostrar ticket
				htmlAbreLinha($corFundo);
					$url="?modulo=ticket$UE&sub&acao=ver$UE&registro=$id";
					if($usuario==$idUsuario) $icone="<img src=".$html[imagem][usuario]." border=0>";
					else $icone="<img src=".$html[imagem][grupo]." border=0>";
					itemLinhaTM("$icone <b>$assunto</b>", $url, 'left', 'middle','40%', $corFundo, 0, "normal10");
					itemLinhaTMNOURL(converteData($data,'banco','form'), 'center', 'middle','15%', $corFundo, 0, "normal10");
					itemLinhaTMNOURL($status[nome], 'center', 'middle','5%', $corFundo, 0, "normal10");
					itemLinhaTMNOURL($categoria[nome], 'center', 'middle','20%', $corFundo, 0, "bold10");
					itemLinhaTMNOURL($nome, 'center', 'middle','10%', $corFundo, 0, "normal10");
				htmlFechaLinha();
				
				# Incrementar contador
				$i++;
			}
			
		} #fecha listagem
		
		fechaTabela();
	} # fecha bot�o procurar
} #fecha funcao de  procurar 


# Gerar numero do protocolo
function buscaIDNovoProtocolo($idTicket) {

	$qtdeNumeros=5;

	if($idTicket) {
// by nash 2007-05-04 - let the protocol be alphanumeric or numeric
//		$data=dataSistema();
//	
//		$matLetras=array('A','C','E','F','H','J','R','U','X','Z','Y','W');
//		
//		$letra1=$matLetras[rand(0,(count($matLetras)-1))];
//		$letra2=$matLetras[rand(0,(count($matLetras)-1))];
//		$letra3=$matLetras[rand(0,(count($matLetras)-1))];
//		
//		while($letra1 == $letra2) {
//			$letra2=$matLetras[rand(0,(count($matLetras)-1))];
//		}
//		
//		# Gerar numero do Ticket com zeros a esquerda
//		// ATEN��O: 9 casas num�ricas para idTicket
//		//$complemento='';
//		//for($a=strlen($idTicket);$a<$qtdeNumeros;$a++) $complemento.="0";
//		
//		if(strlen(trim($idTicket)) >= $qtdeNumeros) {
//			$protocolo = $letra1.$letra2.$complemento.trim(substr($idTicket,strlen($idTicket)-$qtdeNumeros,$qtdeNumeros)).$letra3;
//		}
//		else {
//			$protocolo = $letra1.$letra2.$complemento.substr(trim($idTicket),0,strlen(trim($idTicket))).$letra3;
//		}
//		
//		
//		# Verificar a exist�ncia do numero do protocolo
//		$consulta=buscaTicket($protocolo, 'protocolo','igual','protocolo');
//		
//		
//		if($consulta && contaConsulta($consulta)>0) $protocolo=buscaIDNovoProtocolo($idTicket);
//		else return($protocolo);
		
		$parametros=carregaParametros();
		if( !$parametros['protocol_alpha'] ||  strtolower($parametros['protocol_alpha']) != 'n' ) {
			
			$data=dataSistema();
		
			$matLetras=array('A','C','E','F','H','J','R','U','X','Z','Y','W');
			
			$letra1=$matLetras[rand(0,(count($matLetras)-1))];
			$letra2=$matLetras[rand(0,(count($matLetras)-1))];
			$letra3=$matLetras[rand(0,(count($matLetras)-1))];
			
			while($letra1 == $letra2) {
				$letra2=$matLetras[rand(0,(count($matLetras)-1))];
			}
			
			# Gerar numero do Ticket com zeros a esquerda
			// ATEN��O: 9 casas num�ricas para idTicket
			//$complemento='';
			//for($a=strlen($idTicket);$a<$qtdeNumeros;$a++) $complemento.="0";
			
			if(strlen(trim($idTicket)) >= $qtdeNumeros) {
				$protocolo = $letra1.$letra2.$complemento.trim(substr($idTicket,strlen($idTicket)-$qtdeNumeros,$qtdeNumeros)).$letra3;
			}
			else {
				$protocolo = $letra1.$letra2.$complemento.substr(trim($idTicket),0,strlen(trim($idTicket))).$letra3;
			}
			
			
			# Verificar a exist�ncia do numero do protocolo
			$consulta=buscaTicket($protocolo, 'protocolo','igual','protocolo');
			
			
			if($consulta && contaConsulta($consulta)>0) $protocolo = resultadoSQL( $consulta, 0, 'protocolo' );
		} else {
			$protocolo = $idTicket;
		}
		return $protocolo;
	}
	else {
		$msg=_("Protocol cannot be generated!");
		avisoNOURL(_("Warning"), $msg, 400);
	}

}



# Visualiza��o de Ticket atrav�s de informa��o de protocolo
function verProtocolo($protocolo) {

	global $corFundo, $corBorda, $tb, $html, $sessLogin, $sms;

	# Checar permiss�o do usuario
	# Buscar informa��es sobre usuario - permiss�es
	$permissao=buscaPermissaoUsuario($sessLogin[login]);

	if(!$permissao[visualizar] && !$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
	
	
		# Mostar informa��es sobre Servidor
		$consulta=buscaTicket($protocolo, 'protocolo','igual','id');
		
		if($consulta && contaConsulta($consulta)>0) {
			
			$idTicket=resultadoSQL($consulta, 0, 'id');
			$assunto=resultadoSQL($consulta, 0, 'assunto');
			$data=resultadoSQL($consulta, 0, 'data');
			$descricao=resultadoSQL($consulta, 0, 'texto');
			$idUsuario=resultadoSQL($consulta, 0, 'idUsuario');
			$nomeUsuario=resultadoSQL(buscaUsuarios($idUsuario,'id','igual','login'),0,'login');
			$idPrioridade=resultadoSQL($consulta, 0, 'idPrioridade');
			$idCategoria=resultadoSQL($consulta, 0, 'idCategoria');
			$protocolo=resultadoSQL($consulta, 0, 'protocolo');
				
			#nova tabela para mostrar informa��es
			novaTabela2(_("New Generated Protocol"), 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				novaLinhaTabela($corFundo, '100%');
					$mensagem="<span class=txtaviso>
						"._("WARNING: New protocol was generated!")."<br>
						"._("Informations about new protocol:")."<br><br>
					</span>";
					itemLinhaNOURL($mensagem, 'center', $corFundo, 2, 'normal10');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela('<b>'._("Date of Creation:").'</b>', 'right', '40%', 'normal10');
					itemLinhaNOURL(converteData($data, 'banco','form'), 'left', $corFundo, 0, 'normal10');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela('<b>'._("Protocol:").'</b>', 'right', '40%', 'normal10');
					itemLinhaNOURL($protocolo, 'left', $corFundo, 0, 'protocolo');
				fechaLinhaTabela();
				if ($sms["enabled"]) {
					novaLinhaTabela($corFundo, '100%');
						itemLinhaTabela('<b>' . _("Status SMS:") . '</b>', 'right', '40%', 'normal10');
						itemLinhaNOURL($sms["statusSms"], 'left', $corFundo, 0, 'normal10');
					fechaLinhaTabela();
				}
			fechaTabela();	
			# fim da tabela	
		}
		else {
			#erro
		}
	}
}


# Fun��o para Visualia��o de Ticket a partir de protocolo
function verTicketProcotolo($modulo, $sub, $acao, $registro, $matriz) {

	global $corFundo, $corBorda, $tb, $html, $sessLogin, $sms, $protocolo;

	if($registro) {
		# Procurar Ticket a partir de protocolo
		$consulta=buscaTicket($registro, 'protocolo','igual','id');
		
		$sessLogin[modulo]=$modulo;
		$sessLogin[sub]=$sub;
		$sessLogin[acao]=$acao;
	}
	
	if($acao=='verprotocolo' && (!$registro || !$consulta || ($consulta && contaConsulta($consulta)==0)) ) {
		# Form para informar o numero do protocolo
		# Motrar tabela de busca
		novaTabela2SH("center", '100%', 0, 2, 0, $corFundo, $corBorda, 2);
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'center', $corFundo, 0, 'normal10');
					echo "<img src=".$html[imagem][logo].">";
				htmlFechaColuna();
				htmlAbreColuna('60%', 'right', $corFundo, 0, 'normal10');
					novaTabela2("["._("Ticket View - Report Protocol")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
						#fim das opcoes adicionais
						novaLinhaTabela($corFundo, '100%');
							$texto="<form method=post name=matriz action=index.php>
							<input type=hidden name=modulo value=$modulo>
							<input type=hidden name=sub value=$sub>
							<input type=hidden name=acao value=$acao>";
							itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
						fechaLinhaTabela();
						novaLinhaTabela($corFundo, '100%');
							htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
								echo "<b class=bold10>"._("Protocol:")." </b>";
							htmlFechaColuna();
							$texto="<input type=text name=registro size=20>";
							itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
						fechaLinhaTabela();
						# Bot�o de confirma��o
						novaLinhaTabela($corFundo, '100%');
							htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
								echo "&nbsp;";
							htmlFechaColuna();
							$texto="<input type=submit name=matriz[bntOK] value="._("View")." class=submit>";
							itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
						fechaLinhaTabela();
						
					fechaTabela();
				htmlFechaColuna();
			fechaLinhaTabela();
		fechaTabela();
		
	}
	elseif($consulta && contaConsulta($consulta)>0) {

		$idTicket=resultadoSQL($consulta, 0, 'id');
		$assunto=resultadoSQL($consulta, 0, 'assunto');
		$data=resultadoSQL($consulta, 0, 'data');
		$descricao=resultadoSQL($consulta, 0, 'texto');
		$idUsuario=resultadoSQL($consulta, 0, 'idUsuario');
		$nomeUsuario=resultadoSQL(buscaUsuarios($idUsuario,'id','igual','login'),0,'login');
		$idPrioridade=resultadoSQL($consulta, 0, 'idPrioridade');
		$idCategoria=resultadoSQL($consulta, 0, 'idCategoria');
		$protocolo=resultadoSQL($consulta, 0, 'protocolo');
		
		# Pegar o nome do grupo de acordo com o perfil
		$nomeGrupo = comentarNomeGrupo( $idUsuario );
		/*
			Verifica��o de Registro - Em caso de encaminhamento de ticket (envio de url com protocolo)
			para um usu�rio do ticket, fazendo com que haja a necessidade de passagem do ID do ticket
			e n�o mais o protocolo
		*/
		if($sessLogin[login] && $sessLogin[senha]) {
			$modulo='ticket';
			$registro=$idTicket;
		}
		
		# Processos do Ticket
		$processosTicket=buscaProcessosTicket($idTicket, 'idTicket','igual','data DESC');
		
		if($processosTicket && contaConsulta($processosTicket)>0) {
			$statusTicket=resultadoSQL($processosTicket, 0, 'idStatus');
			$status=checaStatusTicket($statusTicket);
			
			if($acao=='verprotocolo') {
				
				#nova tabela para mostrar informa��es
				novaTabela2SH('center', '100%', 0, 2, 0, $corFundo, $corBorda, 2);
					novaLinhaTabela($corFundo, '100%');
						# Menu de op��es na visualiza��o do ticket
						htmlAbreColuna('90%', 'center valign=top', $corFundo, 0, 'normal');
							novaTabela2("Ticket: $assunto", 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
								if($protocolo) {
									novaLinhaTabela($corFundo, '100%');
										itemLinhaTabela('<b>'._("Protocol:").'</b>', 'right', '20%', 'tabfundo1');
										itemLinhaNOURL($protocolo, 'left', $corFundo, 0, 'normal10');
									fechaLinhaTabela();
								}
								novaLinhaTabela($corFundo, '100%');
									itemLinhaTabela('<b>'._("Created by:").'</b>', 'right', '20%', 'tabfundo1');
									itemLinhaNOURL( ( empty( $nomeGrupo ) ? _($nomeUsuario) : $nomeGrupo ), 'left', $corFundo, 0, 'normal10');
								fechaLinhaTabela();
								novaLinhaTabela($corFundo, '100%');
									itemLinhaTabela('<b>'._("Date of Creation:").'</b>', 'right', '20%', 'tabfundo1');
									itemLinhaNOURL(converteData($data, 'banco','form'), 'left', $corFundo, 0, 'normal10');
								fechaLinhaTabela();
								novaLinhaTabela($corFundo, '100%');
									itemLinhaTabela('<b>'._("Status:").'</b>', 'right', '20%', 'tabfundo1');
									itemLinhaNOURL($status[nome], 'left', $corFundo, 0, 'normal10');
								fechaLinhaTabela();
								if($dadosRelacionamento[idEmpresa]) {
										novaLinhaTabela($corFundo, '100%');
										itemLinhaTabela('<b>'._("Company:").'</b>', 'right', '20%', 'tabfundo1');
										itemLinhaNOURL(formSelectEmpresas($dadosRelacionamento[idEmpresa],'','check'), 'left', $corFundo, 0, 'normal10');
									fechaLinhaTabela();
								}
								if($dadosRelacionamento[idMaquina]) {
										novaLinhaTabela($corFundo, '100%');
										itemLinhaTabela('<b>'._("Host:").'</b>', 'right', '20%', 'tabfundo1');
										itemLinhaNOURL(formSelectMaquinasEmpresa($dadosRelacionamento[idMaquina],'','','check'), 'left', $corFundo, 0, 'normal10');
									fechaLinhaTabela();
								}
								novaLinhaTabela($corFundo, '100%');
									itemLinhaTabela('<b>'._("Description:").'</b>', 'right', '20%', 'tabfundo1');
									itemLinhaNOURL(nl2br($descricao), 'left', $corFundo, 0, 'tabfundo3');
								fechaLinhaTabela();
							fechaTabela();
						htmlFechaColuna();
						htmlAbreColuna('10%', 'left nowrap  valign=top', $corFundo, 0, 'normal');
							menuTicket($statusTicket, $registro, _('Options'), 'left', '100%', $corFundo, $corBorda, 'normal10');
						htmlFechaColuna();
					htmlFechaLinha();
				fechaTabela();	
				# fim da tabela	
				
				# Listagem de Processos do Ticket
				echo "<br />";
				listarProcessosTicket($modulo, $sub, $acao, $matriz, $idTicket);

				# Listagem de Coment�rios do Ticket
				echo "<br />";
				listarComentariosTicket($modulo, $sub, $acao, $matriz, $idTicket);
			}
			
			elseif($acao=='comentar') {
				# Carregar Detalhes
				$detalhesTicket=detalhesTicket($idTicket);
				
				# Processos do Ticket
				$processosTicket=buscaProcessosTicket($idTicket, 'idTicket','igual','data DESC LIMIT 1');
				
				if($processosTicket && contaConsulta($processosTicket)>0) {
					$statusTicket=resultadoSQL($processosTicket, 0, 'idStatus');
					$status=checaStatusTicket($statusTicket);
		
					if(!$matriz[descricao] && !$matriz[bntComentar]) {
												
						#nova tabela para mostrar informa��es
						novaTabela2SH('center', '100%', 0, 2, 0, $corFundo, $corBorda, 2);
							novaLinhaTabela($corFundo, '100%');
								# Menu de op��es na visualiza��o do ticket
								htmlAbreColuna('90%', 'center valign=top', $corFundo, 0, 'normal');
									novaTabela2(_("Ticket:")." $assunto", 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
										if($protocolo) {
											novaLinhaTabela($corFundo, '100%');
												itemLinhaTabela('<b>'._("Protocol:").'</b>', 'right', '20%', 'tabfundo1');
												itemLinhaNOURL($protocolo, 'left', $corFundo, 0, 'normal10');
											fechaLinhaTabela();
										}
										novaLinhaTabela($corFundo, '100%');
											itemLinhaTabela('<b>'._("Created by:").'</b>', 'right', '20%', 'tabfundo1');
											itemLinhaNOURL( ( empty( $nomeGrupo ) ? $nomeUsuario : $nomeGrupo ), 'left', $corFundo, 0, 'normal10');
										fechaLinhaTabela();
										novaLinhaTabela($corFundo, '100%');
											itemLinhaTabela('<b>'._("Date of Creation:").'</b>', 'right', '20%', 'tabfundo1');
											itemLinhaNOURL(converteData($data, 'banco','form'), 'left', $corFundo, 0, 'normal10');
										fechaLinhaTabela();
										novaLinhaTabela($corFundo, '100%');
											itemLinhaTabela('<b>'._("Status:").'</b>', 'right', '20%', 'tabfundo1');
											itemLinhaNOURL($status[nome], 'left', $corFundo, 0, 'normal10');
										fechaLinhaTabela();
										if($dadosRelacionamento[idEmpresa]) {
												novaLinhaTabela($corFundo, '100%');
												itemLinhaTabela('<b>'._("Company:").'</b>', 'right', '20%', 'tabfundo1');
												itemLinhaNOURL(formSelectEmpresas($dadosRelacionamento[idEmpresa],'','check'), 'left', $corFundo, 0, 'normal10');
											fechaLinhaTabela();
										}
										if($dadosRelacionamento[idMaquina]) {
												novaLinhaTabela($corFundo, '100%');
												itemLinhaTabela('<b>'._("Host:").'</b>', 'right', '20%', 'tabfundo1');
												itemLinhaNOURL(formSelectMaquinasEmpresa($dadosRelacionamento[idMaquina],'','','check'), 'left', $corFundo, 0, 'normal10');
											fechaLinhaTabela();
										}
										novaLinhaTabela($corFundo, '100%');
											itemLinhaTabela('<b>'._("Description:").'</b>', 'right', '20%', 'tabfundo1');
											itemLinhaNOURL(nl2br($descricao), 'left', $corFundo, 0, 'tabfundo3');
										fechaLinhaTabela();
									fechaTabela();
								htmlFechaColuna();
								htmlAbreColuna('10%', 'left nowrap  valign=top', $corFundo, 0, 'normal');
									menuTicket($statusTicket, $registro, 'Op��es', 'left', '100%', $corFundo, $corBorda, 'normal10');
								htmlFechaColuna();
							htmlFechaLinha();
						fechaTabela();	
						# fim da tabela	
						
						echo "<br>";
						novaTabela2(_('Comment of Ticket'), 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
							#fim das opcoes adicionais
							novaLinhaTabela($corFundo, '100%');
							$texto="			
								<form method=post name=matriz action=index.php>
								<input type=hidden name=modulo value=$modulo>
								<input type=hidden name=sub value=$sub>
								<input type=hidden name=acao value=$acao>
								<input type=hidden name=registro value=$registro>
								<input type=hidden name=matriz[ticket] value=$idTicket>";
								itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
							fechaLinhaTabela();
							novaLinhaTabela($corFundo, '100%');
								htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
									echo "<b class=bold>"._("Commentary:")." </b><br>
									<span class=normal10>"._("Comments on Ticket")."</span>";
								htmlFechaColuna();
								$texto="<textarea name=matriz[descricao] rows=15 cols=60></textarea>";
								itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
							fechaLinhaTabela();
							novaLinhaTabela($corFundo, '100%');
								htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
									echo "&nbsp;";
								htmlFechaColuna();
								$texto="<input type=submit name=matriz[bntComentar] value="._("Comment Ticket")." class=submit>";
								itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
							fechaLinhaTabela();
						fechaTabela();		
					}
					
					else {
						# Gravar
						$grava=dbComentariosTicket($matriz, 'incluir');
						
						if($grava) {
							/*
							$msg="Coment�rio postado com sucesso!";
							$url="?modulo=$modulo&sub=&acao=ver&registro=$idTicket";
							aviso("Aviso", $msg, $url, 760);
							*/
							verTicketProcotolo('protocolo', $sub, 'verprotocolo', $registro, $matriz);
							
							# Enviar mensagem alertando sobre novo ticket Criado
							$matriz[email]=$detalhesTicket;
							$matriz[idTicket]=$matriz[ticket];
							$matriz[protocolo]=$protocolo;
							$matriz[categoria]=$idCategoria;
							mailTicketProtocolo($matriz, $idUsuario, 'comentario');
	
						}
					}
					
				}			
			}
		}
	}
	elseif($acao=='incluir' && is_numeric($matriz[categoria])) {
		/* Concatena em sms, o ddd + numero informado no formul�rio */
		$matriz[sms] = $matriz[smsddd].$matriz[smsnumero];
		
		if($matriz[email] && checkMailDominio($matriz[email], 'check')) {
			$mensagem="<center><span class=txtaviso>"._("WARNING: The given e-mail is invalid!")."<br>" .
						_("Be certified of informing a valid e-mail address!")."<br>" .
						_("To inform more than one e-mail address, use")." \",\" ("._("comma").")<br>" .
						_("Only the valid e-mail address will be used!")."</span></center><br>";
		}elseif (($matriz[smsddd] || $matriz[smsnumero]) && ! validaCelular($matriz[sms])){
			$mensagem="<center><span class=txtaviso>"._("WARNING: The given SMS is invalid!")."<br>" .
						_("Be certified of informing a valid cel phone number!")."<br>";
		}
		else {
			$mensagem = "";
		}
						
		$matriz[email]=checkMailDominio($matriz[email], 'format');

		if(!$matriz[bntAdicionar] || !$matriz[descricao] || !$matriz[nome] || $mensagem || checkMailDominio($matriz[email], 'check')) {
			# Form de inclusao
			$matriz[email]=checkMailDominio($matriz[email], 'format');
			# Motrar tabela de busca
				#fim das opcoes adicionais
			novaTabela2("["._("View Protocol")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				$imagem="<img src=" . $html[imagem][protocolos] . " align=left>";
				novaLinhaTabela($corFundo, '100%');
					$texto="<form method=post name=matriz action=index.php>
					<input type=hidden name=moduloProtocolo value=protocolo>
					<input type=hidden name=sub value=>
					<input type=hidden name=acaoProtocolo value=ver>
					";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('60%', 'right', $corFundo, 0, 'tabfundo1');
						echo "
						<center>
							<table width=400 cellpadding=0 cellspacing=1 border=0 bgcolor=#000000><tr><td>
							<table width=400 cellpadding=0 cellspacing=2 border=0 bgcolor=#ffffff>
							<tr><td width=100%>
								<span class=bold10>$imagem "._("Warning:")."</span><br>"._("If you already have the protocol number,").
								_("inform it in the form on the side and").	
								_("press the button")." \""._("View")."\"<br><br>
								</td>
							</tr>
							</table></td></tr></table>
						</center>
						";
					htmlFechaColuna();
					$texto="
					<table width=270 cellpadding=0 cellspacing=1 border=0 bgcolor=#000000><tr><td>
						<table width=270 cellpadding=0 cellspacing=5 border=0 bgcolor=#ffffff>
							<tr>
								<td width=100 align=right><b class=bold10>"._("Protocol:")." </b></td>
								<td width=170 align=left><input type=text name=registro size=10></td>
							</tr>
							<tr>
								<td width=270 colspan=2 align=center>
									<input type=submit name=matriz[bntProtocolo] class=submit value="._("View").">
								</td>
							</tr>
							</table></td></tr></table>
							</form>
					";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
			echo "<br>";
			
			novaTabela2("["._("Add")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=categoria value=$matriz[categoria]>
					<input type=hidden name=acao value=$acao>&nbsp;$mensagem";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>"._("Name/Company:")." </b><br>
						<span class=normal8>"._("Your Name/Company Name for identification")."</span>";
					htmlFechaColuna();
					$texto="<input type=text name=matriz[nome] size=50 value='$matriz[nome]'>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>"._("E-mail:")." </b><br>
						<span class=normal8>"._("Contact e-mail")."</span>";
					htmlFechaColuna();
					$texto="<input type=text name=matriz[email] size=50 value='$matriz[email]'>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>"._("Subject:")." </b><br>
						<span class=normal8>"._("Ticket subject, used for abbreviated Ticket view")."</span>";
					htmlFechaColuna();
					$texto="<input type=text name=matriz[assunto] size=50 value='$matriz[assunto]'>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				## Campo SMS
				if($sms[enabled]){
					novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>"._("SMS:")." </b><br>
						<span class=normal8>"._("Ticket SMS (DDD+Number): Fill this field with your cel number if you want to receive a SMS message when the ticket is opened / closed.")."</span>";
					htmlFechaColuna();
					$texto="<input type=text name=matriz[smsddd] size=2 maxlength=2 value='$matriz[smsddd]'>";
					$texto.="<input type=text name=matriz[smsnumero] size=8 maxlength=8 value='$matriz[smsnumero]'>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
				}
				## Campo Descricao
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>"._("Description:")." </b><br>
						<span class=normal8>"._("Detailed Ticket Description")."</span>";
					htmlFechaColuna();
					$texto  = "<textarea name=matriz[descricao] rows=10 cols=60>$matriz[descricao]</textarea>";
					/* Imagem do "Desafio de Imagem" */
					$texto .= "<br><br><img src='includes/processa_imagem.php' border='1' style='border-color:#6F6F6F;'>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				
				/* Desafio de IMAGEM */
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10> C�digo de seguran�a: </b><br>
						<span class=normal8> Por favor, Digite os caracteres informados na imagem acima </span>";
					htmlFechaColuna();
					
					$texto  = "<input type='text' name=matriz[codigoSeguranca] value='$matriz[codigoSeguranca]' size=6>";
					$texto .= "&nbsp;&nbsp; <img name='atualizar' id='atualizar' src='imagens/atualizar.gif' title='Atualizar Figura' onclick='window.location.reload();' border='0'' style='cursor:pointer;'>";
					
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
					
					
				fechaLinhaTabela();
				
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntAdicionar] value="._("Add")." class=submit>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		} #fecha form
		elseif($matriz[bntAdicionar]) {
			
			/* Numero celular informado ao abrir o ticket */			
			$matriz["sms"] = $matriz["smsddd"] . $matriz["smsnumero"];
				
			/*
				1.1 Verifica se os seguintes campos est�o preenchidos:
						$matriz[assunto]
						$matriz[descricao]
						
				1.2 Verifica e valida o codigo de seguranca(desafio de imagem)
						$matriz[codigoSeguranca]
						PhpCaptcha::Validate( $matriz[codigoSeguranca])
						
				1.3 Verifica se est� ativo o envio de sms
					1.3.1 Em caso positivo valida os seguintes campos
						$matriz["smsdd"]
						$matriz["smsnumero"]
						
					1.3.2 Em caso negativo retorna verdadeiro para pular essa validac�o
			*/
			if($matriz[assunto] && $matriz[descricao] && ($matriz[codigoSeguranca] && PhpCaptcha::Validate( $matriz[codigoSeguranca]))
					&& ($sms["enabled"]) ? (validaCelular($matriz["sms"])) : true ) {
				
				# Buscar ID de novo Ticket
				$matriz[idCategoria]=$matriz[categoria];
				$matriz[idTicket]=buscaIDNovoTicket();
				
				# Buscar ID de novo Protocolo
				$protocolo = $matriz[protocolo]=buscaIDNovoProtocolo($matriz[idTicket]);
				
				# Alterar Descri��o
				$matriz[descricao]=_("Name/Company:")." $matriz[nome]".
										"\n"._("E-mail:")." $matriz[email]".
										"\n\n$matriz[descricao]";

				
				
				# Incluir Detalhes ao Ticket
				gravaDetalhesTicket($matriz[idTicket], $matriz);
				
				# Cadastrar em banco de dados
				$grava=dbTicket($matriz, 'incluir');
				
				# Verificar inclus�o de registro
				if($grava) {
					# Gravar Status de Ticket - NOVO
					dbProcessosTicket($matriz, 'incluir');
					
					# Buscar Ticket
					if($sessLogin[login]) $idUsuario=buscaIDUsuario($sessLogin[login], 'login', 'igual', 'login');
					else $idUsuario=buscaIDUsuario( 'guest', 'login', 'igual', 'login' );
					
					# Enviar mensagem para autor da mensagem - verificando detalhes
					$detalhesTicket=detalhesTicket($matriz[idTicket]);
					if($detalhesTicket) {
						$matriz[email]=$detalhesTicket;
						mailTicketProtocolo($matriz, $idUsuario, 'incluir');
					}
					
					/* 
						Envia SMS para o cliente e guarda a mensagem
						retornada no array global $sms["statusSms"],
						que � utilizado em protocolo.php, ap�s cadastrar
						um ticket.
					*/
					if ($sms["enabled"]) {
						/* Substitui a palavra reservada #protocolo# pelo protocolo do ticket */
						$sms["msgTicketAberto"] = str_replace("#protocolo#", $protocolo, $sms["msgTicketAberto"]);
						
						/* Envia o sms ao cliente */
						$sms["statusSms"] = sendSms("55" . $matriz["sms"], $sms["from"], $sms["msgTicketAberto"], $matriz["protocolo"] . "A");
					}  
					
					# Mostrar Ticket
					echo "<meta http-equiv=refresh content=0;URL=?modulo=protocolo&acao=ver&registro=$matriz[protocolo]>";
					//verTicketProcotolo("protocolo", '', 'ver', $matriz[protocolo], $matriz);
				}
			}
			
			# falta de parametros
			else {
				# acusar falta de parametros
				# Mensagem de aviso
				$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
				$url="?modulo=$modulo&acao=$acao";
				aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
			}
		}
	}
	else {
	
		if($registro) {
			# Ticket n�o pode ser visualizado
			$msg=_("Ticket cannot be found");
			avisoNOURL(_("Ticket view"), $msg, 760);
		}
	}
}

###########################################################################################################################################
###############################																			  #################################
#############################################		SISTEMA DE LOGIN PARA USUARIO_EMPRESA		###########################################
###############################																			  #################################
###########################################################################################################################################

# Fun��o para cadastro
function protocoloUE($modulo, $sub, $acao, $registro, $matriz) {
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Carregar Frame
	if($acao=='ver') {
		echo "<frameset rows=0,* border=1>";
		echo "<frame name=none  src=?modulo=protocoloUE&acao=atualizarUE&registro=$registro>";
		echo "<frame name=chatprotocolo src=?modulo=protocoloUE&acao=verprotocoloUE&registro=$registro>";
		echo "</frameset>";
	}

	# Mostrar Status caso n�o seja informada a a��o
	# Procurar
	elseif(!$acao || $acao=="procurarUE") {
		procurarProtocolo($modulo, $sub, $acao, $registro, $matriz);
	}
	elseif($sub=='feedbackUE') {
		ticketFeedback($modulo, $sub, $acao, $registro, $matriz);
	}
	elseif($acao=='verprotocoloUE' || $acao=='comentarUE' || $acao=='incluirUE') {
		novaTabela2SH('left',768,0,0,0,$corFundo,$corBorda,0);
		htmlAbreLinha($corFundo);
			htmlAbreColuna(768,'left',$corFundo,0,'normal10');
				verTicketProcotolo($modulo, $sub, $acao, $registro, $matriz);
			htmlFechaColuna();
		htmlFechaLinha();
		fechaTabela();
	}
	elseif($acao=='atualizarUE') {
		# Checar Chat
		$idTicket=buscaIDTicket($registro,'protocolo','igual','id');
		
		if($idTicket) {
//			if(checkChatTicket($idTicket)) {
//			echo "
//				<script>
//					novaJanela(\"?modulo=ticket&sub=chat&acao=montar&registro=$idTicket\",\"chatprotocolo$idTicket\",\"width=640,height=600,resizable=No,scrollbars=Yes,title=ChatOnline,toolbar=No\");
//				</script>
//				";
//			}
		}
		else {
			echo "<meta http-equiv=refresh content=2;URL=?modulo=protocoloUE&acao=atualizarUE&registro=$registro>";
		}
	}
} #fecha menu principal


# Visualiza��o de Ticket atrav�s de informa��o de protocolo
function verProtocoloUE($protocolo) {

	global $corFundo, $corBorda, $tb, $html, $sessLogin;

	# Checar permiss�o do usuario
	# Buscar informa��es sobre usuario - permiss�es
//	$permissao=buscaPermissaoUsuario($sessLogin[login]);

	if(!$sessLogin) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
	
	
		# Mostar informa��es sobre Servidor
		$consulta=buscaTicket($protocolo, 'protocolo','igual','id');
		
		if($consulta && contaConsulta($consulta)>0) {
			
			$idTicket=resultadoSQL($consulta, 0, 'id');
			$assunto=resultadoSQL($consulta, 0, 'assunto');
			$data=resultadoSQL($consulta, 0, 'data');
			$descricao=resultadoSQL($consulta, 0, 'texto');
//			$idUsuario=resultadoSQL($consulta, 0, 'idUsuario');
//			$nomeUsuario=resultadoSQL(buscaUsuarios($idUsuario,'id','igual','login'),0,'login');
			$idPrioridade=resultadoSQL($consulta, 0, 'idPrioridade');
			$idCategoria=resultadoSQL($consulta, 0, 'idCategoria');
			$protocolo=resultadoSQL($consulta, 0, 'protocolo');
				
			#nova tabela para mostrar informa��es
			novaTabela2(_("New Generated Protocol"), 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				novaLinhaTabela($corFundo, '100%');
					$mensagem="<span class=txtaviso>
						"._("WARNING: New protocol was generated!")."<br>
						"._("Informations about new protocol:")."<br><br>
					</span>";
					itemLinhaNOURL($mensagem, 'center', $corFundo, 2, 'normal10');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela('<b>'._("Date of Creation:").'</b>', 'right', '40%', 'normal10');
					itemLinhaNOURL(converteData($data, 'banco','form'), 'left', $corFundo, 0, 'normal10');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela('<b>'._("Protocol:").'</b>', 'right', '40%', 'normal10');
					itemLinhaNOURL($protocolo, 'left', $corFundo, 0, 'protocolo');
				fechaLinhaTabela();
			fechaTabela();	
			# fim da tabela	
		}
		else {
			#erro
		}
	}
}

?>