<?
################################################################################
#       Criado por: Devel IT
#  Data de cria��o: 18/06/2004
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 003
#
# Fun��o:
#    Fun��es para serem utilizadas nos forms de consulta



function evento($modulo, $sub, $acao, $registro, $matriz) {

	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;

	# Mostrar Status caso n�o seja informada a a��o
	# Inclus�o
	if($acao=="agendar") {
		eventoAgendar($modulo, $sub, $acao, $matriz, $registro);
	}
	# Transferir
	else {
		eventoExibirCalendario($matriz, $registro);
	}
	
} #fecha menu principal 



# Fun��o para Form de abertura de ticket
function eventoAgendar($modulo, $sub, $acao, $matriz, $registro) {
	global $html, $corFundo,  $sessLogin, $corBorda, $conn, $tb;
	
	#usuario
	#$idUsuario=buscaIDUsuario($sessLogin[login],'login','igual','id');
	# Buscar Assunto do Ticket
	#$consulta=buscaTicket($matriz[ticket], 'id','igual','id');
	#$assunto=resultadoSQL($consulta, 0, 'assunto');
	# Data de hoje
	$data=dataSistema();
	$ticket=dadosTicket($matriz[ticket]);
	
	if ($matriz[bntAgendar]) {
		if ($matriz[inicio] && $matriz[duracao] && $matriz[horario]) {
			
			#apagar evento deste mesmo ticket ja agendado
			#echo "<br>apagando os eventos";
			$sql="SELECT * FROM $tb[Evento] WHERE idTicket=".$matriz[ticket];
			$consulta=consultaSQLHide($sql, $conn);
			if ( $consulta && contaConsulta( $consulta ) > 0 ){
				$idEvento=resultadoSQL( $consulta, 0, 'id' );
			}
			#eliminar as entradas anteriores do mesmo ticket
			$sql="DELETE FROM $tb[Agenda] WHERE idEvento=".$idEvento;
			consultaSQLHide($sql, $conn);
			
			$sql="DELETE FROM $tb[Evento] WHERE idTicket=".$matriz[ticket];
			consultaSQLHide($sql, $conn);
			

			# Gravar
			$grava=dbEvento($matriz, 'incluir');
			if($grava) {
				#Busco o id do evento do ticket
				$consulta=buscaRegistro($matriz[ticket], "idTicket", "igual", '', $tb[Evento]);
				$matriz[idEvento]=resultadoSQL($consulta, 0, 'id');
				eventoInserirHorarios($matriz);
				if ( $matriz[opcoes] == 'S' ){
					relacionarTicket( 'ticket', '', 'relacionar', $matriz, $registro);
				}
			}
			else {
				$msg=_("WARNING: Error when saving!");
				$url="?modulo=$modulo&sub=$sub&acao=$acao&registro=$idTicket";
				aviso(_("Warning"), $msg, $url, 760);
				echo "<br>";
			}
		}
		else {
			$msg=_("ATTENTION: All the fields should be filled out!");
			$url="?modulo=$modulo&sub=$sub&acao=abrir&registro=$idTicket";
			aviso(_("Warning"), $msg, $url, 400);
			echo "<br>";		
			$matriz[bntAgendar]="";
		}
	}
	if (! $matriz[bntAgendar]) { 
		novaTabela2(_("Schedule Ticket:"). $ticket[assunto], 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);				
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
				$texto="<form method=post name=matriz action=index.php>
						<input type=hidden name=modulo value=evento>
						<input type=hidden name=acao value=agendar>
						<input type=hidden name=registro value=$registro>
						<input type=hidden name=matriz[ticket] value=$registro>
						<input type=hidden name=matriz[opcoes] value=$matriz[opcoes]>
				";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			
			$evento=buscaRegistro($registro, 'idTicket', 'igual', '',$tb[Evento] );
			
			if (contaConsulta($evento)) {
				$dados=dadosEvento(resultadoSQL($evento, 0, 'id'));
			}
			else {
				$dados[inicio]=$data[hoje];
				$dados[horario]=$data[hora];
				$dados[duracao]=1;
			}
			#ticket
			$txt="<b class=bold>"._("Ticket:")."</b>";
			getCampo('sotexto', $txt, 'matriz[assunto]', $ticket[assunto], '', '', 20);
			
			#data inicial
			$txt="<b class=bold>"._("Beginning:")."</b><br>
				  <span class=normal10>"._("Initial day of the execution")."</span>";
			getCampo('text', $txt, "matriz[inicio]", $dados[inicio], "onBlur=verificaData(this.value,5)", '', 10);
			
			#horario
			$txt="<b class=bold>"._("Timetable:")."</b><br>
				  <span class=normal10>"._("Hour of initial day")."</span>";
			getCampo('text', $txt, 'matriz[horario]', $dados[horario], "onBlur=verificaHora(this.value,6)", '', 2);
			
			#Tempo
			$txt="<b class=bold>"._("Duration:")."</b><br>
				  <span class=normal10>"._("Time to complete the operation (in hours)")."</span>";
			getCampo('text', $txt, 'matriz[duracao]', $dados[duracao], '', '', 2);
			
			# botao
			getBotao( 'matriz[bntAgendar]', _("Schedule") );
			
		fechaTabela();		
	}
}

/**
 * @return void
 * @param unknown $modulo
 * @param unknown $sub
 * @param unknown $acao
 * @param unknown $matriz
 * @param unknown $registro
 * @desc Enter description here...
*/
function eventoExibirCalendario($matriz="", $registro="") {
	
	global $html, $corFundo,  $sessLogin, $corBorda, $conn;
	
	#usuario default da sessao
	$defUsuario=buscaIDUsuario($sessLogin[login],'login','igual','id');
	$perfilDef=dadosPerfilUsuario($defUsuario);
	
	if ($perfilDef[grade]) $borda=1;
	else $borda=0;

	if(! $matriz[usuario]) $idUsuario=$defUsuario;
	else $idUsuario=$matriz[usuario];
	
	$perfil=dadosPerfilUsuario($idUsuario);
	
	#horarios
	$expediente[inicio]=$perfil[horarioInicio];
	if (strlen($expediente[inicio]) < 2) $expediente[inicio]="0".$expediente[inicio];
	$expediente[fim]=$perfil[horarioFim];
	if (strlen($expediente[fim]) < 2) $expediente[fim]="0".$expediente[fim];
	
	$hoje=dataSistema();
	
	#Verifica se foi solicitada alguma data especial ou pega a de hoje
	if (is_array($matriz) && $matriz[semana]) {
		$dta=getUnixTime($matriz[semana]);
	} 
	else {
		$dta=getUnixTime($hoje[hoje]);
	}
	
	# Prepara a matriz inicio com as datas iniciais
	$dta=getDate($dta);
	$inicio[dia]=$dta['mday'];
	$inicio[mes]=$dta['mon'];
	$inicio[ano]=$dta['year'];
	
	if (strlen($inicio[dia])<2) $inicio[dia]="0".$inicio[dia];
	if (strlen($inicio[mes])<2) $inicio[mes]="0".$inicio[mes];
	
	#calcular o dia da 1a segunda-feira da semana
	$inicio[primeiroDia]="$inicio[dia]/$inicio[mes]/$inicio[ano]";
	$c=0;
	while (getDiaSemana($inicio[primeiroDia])!=_("Monday") && $c<8) {
		$inicio[primeiroDia]=somaDia($inicio[primeiroDia], -1);
		$c++;
	}
	
	# Semanas 
	$inicio[anterior]=somaDia($inicio[primeiroDia], -7);
	$inicio[proxima]=somaDia($inicio[primeiroDia], 7);
	
	#url para a navega��o das semanas
	$url="<a href=?modulo=evento&acao=exibirCalendario&matriz[usuario]=$idUsuario&";
	$urlAnterior=$url."matriz[semana]=".$inicio[anterior].">".htmlMontaOpcao('', 'setaesquerda')."</a>";
	$urlhoje=$url."matriz[semana]=".$hoje[hoje].">".htmlMontaOpcao('', 'relogio')."</a>";
	$urlProxima=$url."matriz[semana]=".$inicio[proxima].">".htmlMontaOpcao('', 'setadireita')."</a>";
	
	# Monta a matrix com todas as datas do periodo
	$agenda=array();
	
	#posiciona no primeiro dia
	$dta=$inicio[primeiroDia];		
	
	#dias da semana (colunas)
	for($dia=0; $dia<5; $dia++) {
		$linha=0;
		for($hora=$expediente[inicio]; $hora<=$expediente[fim]; $hora++) {
			#hora com 2 digitos
			if (strlen($hora) < 2) $hr="0".$hora;
			else $hr=$hora;
			#coloca a data no formato datetime (yyyy-mm-dd hh:mm:ss)
			$dthr=$dta." ".trim($hr).":00:00";
			$dthr=converteData($dthr, 'form', 'agenda');
			#coloca espa�o na posicao
			$agenda[$dia][$linha++]=$dthr;
		}
		#pula para o proximo dia
		$dta=somaDia($dta, 1);
	}
	
	#busca em agenda os registro da semana
	$periodo="AND agenda.horario >= '". converteData($inicio[primeiroDia]." 00:00:00", 'form', 'agenda')."' ";
	$periodo.="AND agenda.horario < '".converteData($inicio[proxima]." 00:00:00", 'form', 'agenda')."' ";
	$horario="AND hour(agenda.horario) >= $expediente[inicio] ";
	$horario.="AND hour(agenda.horario) <= $expediente[fim] ";
	$sql="SELECT DISTINCT
					evento.id evento, 
					ticket.id ticket, 
					ticket.assunto assunto, 
					ticket.protocolo protocolo,
					ticket.idPrioridade prioridade,
					processos_ticket.idUsuario usuario,
					status.valor status,
					agenda.id agenda, 
					agenda.horario horario 
		    FROM 	ticket, processos_ticket, status, evento, agenda 
			WHERE 	ticket.id=evento.idTicket 
					AND processos_ticket.idTicket=ticket.id
					AND status.id = processos_ticket.idStatus
					AND evento.id=agenda.idEvento
					AND status.valor IN ('N','A','R')
					AND processos_ticket.idUsuario=$idUsuario 
					$periodo
					$horario
		 ORDER BY 	agenda.horario, ticket.protocolo
	";
	
	#echo $sql;
	
	$consulta=consultaSQL($sql, $conn);
	$linha=0;
	$anterior="";
//****	
	$i=0;
	for($dia=0; $dia<5; $dia++) {
		$linha=0;
		for($hora=$expediente[inicio]; $hora<=$expediente[fim]; $hora++) {
			$horario="";
			$linhaAcima[]=array();
			
			if ($i<contaConsulta($consulta)) $horario=resultadoSQL($consulta, $i, 'horario');
			
			if($agenda[$dia][$linha]==$horario) {
				
				#abre uma tabela centro da celula
				$texto="<table width=100% border=0 cellpadding=2 cellspacing=0 bgcolor=$corBorda>";
				$texto.="<tr bgcolor=$corFundo>\n";
				
				#guarda o protocolo da linha de cima pra nao abrir e cabec de evento
				while ($agenda[$dia][$linha]==$horario) {
					#campos
					$ticket=resultadoSQL($consulta, $i, 'ticket');
					$assunto=resultadoSQL($consulta, $i, 'assunto');
					$protocolo=resultadoSQL($consulta, $i, 'protocolo');
					$prioridade=resultadoSQL($consulta, $i, 'prioridade');
					$evento=resultadoSQL($consulta, $i, 'evento');
					
					#verifica se o anterior era igual pra nao re-exibir o conteudo
					if($protocolo!=$anterior && ! in_array($protocolo, $linhaAcima)) {
						$texto.="<td class=p$prioridade><a href=?modulo=ticket&acao=ver&matriz[evento]=$evento&registro=$ticket>"._("Ticket:")." $protocolo</a><br>$assunto</td>";
						$anterior=$protocolo;
						$prioridades[$dia][$linha]="p".$prioridade;
					}
					else {
						$texto.="<td class=pp$prioridade><a href=?modulo=ticket&acao=ver&matriz[evento]=$evento&registro=$ticket>"._("Ticket:")." $protocolo</a></td>";
						$prioridades[$dia][$linha]="pp".$prioridade;
					}
					$linhaAcima[]=$protocolo;
					$i++;
					if ($i<contaConsulta($consulta)) 
						$horario=resultadoSQL($consulta, $i, 'horario');
					else 
						$horario="";
				}//while
				$agenda[$dia][$linha]=$texto."</tr></table>";
			}
			else {
				$agenda[$dia][$linha]="";
				$prioridades[$dia][$linha]="normal";	
			}
			$linha++;
		} //for de hora
	}
	
	#Exibe o calendario
	$celula=0;
	$tamCelula='134';
	$tamHora='50';
	
	#abre um formulario
	echo "<form method=post name=matriz action=index.php>";
	$texto="<input type=hidden name=modulo value=evento>
			<input type=hidden name=acao value=ver>
			<input type=hidden name=matriz value=$matriz>
			<input type=hidden name=matriz[semana] value=$inicio[primeiroDia]>";
	$user=formSelectUsuariosGruposCategorias(buscaIDUsuario($sessLogin[login],'login','igual','id'),'usuario', 'change', $idUsuario);	
	$formUser=$texto.$user;
//**********************	
	#tabela
	$titulo=_("Calendar - of")."&nbsp;".$inicio[primeiroDia]."&nbsp;"._("until")."&nbsp;".somaDia($inicio[primeiroDia],4)."&nbsp;"._("- User:")."&nbsp;".$formUser;
	novaTabela($titulo,'left', '100%', 0, 0, 1, $corFundo, $corBorda, 6);
		
		#imagens
		novaLinhaTabela($corFundo, '100%');
			$img="<IMG SRC='1pixel.gif' width=$tamHora height=1 border=0>";
			itemLinhaTMNOURL($img, 'center nowrap', '', $tamHora,  $corFundo, 0, 'tabfundo0');
			$img="<IMG SRC='1pixel.gif' width=$tamCelula height=1 border=0>";
			for ($a=0; $a<5;$a++) 
				itemLinhaTMNOURL($img, 'center nowrap', '', $tamCelula,  $corFundo, 0, 'tabfundo2');
		fechaLinhaTabela();
		
		#cabecalho/Gravata
		novaLinhaTabela($corFundo, '100%');
			
			itemLinhaTMNOURL($urlAnterior.$urlhoje.$urlProxima, 'center nowrap', '', $tamHora,  $corFundo, 0, 'tabfundo0');
			
			$dta=$inicio[primeiroDia];
			$dias=array();
			#Semana
			for($dia=0; $dia<5; $dia++) {
				$diaSemana=getDiaSemana($dta);
				if($dta==$hoje[hoje]) $cor='tabfundo2r';
				else  $cor='tabfundo2';
				
				itemLinhaTMNOURL("$diaSemana<br>$dta", 'center','top', $tamCelula, $corFundo, 0, $cor);
				
				$dias[]=$dta;
				$dta=somaDia($dta, 1);
			}
			
		fechaLinhaTabela();
		
		#abre for pra hora (linhas)
		#print_r($agenda);
		
		$linha=0;
		for($hora=$expediente[inicio]; $hora<=$expediente[fim]; $hora++) {
			novaLinhaTabela($corFundo, '800');

				#hora
				if (strlen($hora) < 2) $hr="0".$hora;
				else $hr=$hora;
				
				#exibe o horario	
				itemLinhaTMNOURL("$hr:00", 'center', '', $tamHora, $corFundo, 0,'tabfundo2');
				
				#registros
				for($dia=0; $dia<5; $dia++) {
					if ($dia==0) $anterior="";
					
					if($dias[$dia]==$hoje[hoje]) $cor='bold8';			
					else  $cor='normal8';
					
					$dthr=trim($dias[$dia])." ".trim($hr).":00:00";
					$dthr=converteData($dthr, 'form', 'agenda');
					
					itemLinhaTMNOURL($agenda[$dia][$linha], 'center', '', $tamCelula, $corFundo, 0,$prioridades[$dia][$linha]);
				}
				$linha++;
			fechaLinhaTabela();
			
		}
	fechaTabela();
	echo "</form>";
}


function dadosEvento($idEvento) {
	global $conn, $tb;
	
	$consulta=buscaRegistro($idEvento,'id','igual','', $tb[Evento]);
	
	if($consulta && contaConsulta($consulta)>0) {
		$inicio=resultadoSQL($consulta, 0, 'inicio');
		$inicio=converteData($inicio, 'banco', 'form');
		
		$retorno[id]=resultadoSQL($consulta, 0, 'id');
		$retorno[idTicket]=resultadoSQL($consulta, 0, 'idTicket');
		$retorno[inicio]=substr($inicio, 0, 10);
		$retorno[duracao]=resultadoSQL($consulta, 0, 'duracao');
		$retorno[periodicidade]=resultadoSQL($consulta, 0, 'periodicidade');
		$retorno[status]=resultadoSQL($consulta, 0, 'status');
		$retorno[horario]=resultadoSQL($consulta, 0, 'horario');
	}
	
	return($retorno);

}



function dbEvento($matriz, $tipo) {
	global $conn, $tb, $modulo, $acao, $sessLogin;
	
	$matriz[inicio]=converteData($matriz[inicio]." 00:00:00", 'form', 'agenda');
	
	# Sql de inclus�o no evento
	if($tipo=='incluir') {
		$sql="INSERT INTO $tb[Evento] 
				   VALUES ('',
							'$matriz[ticket]',
							'$matriz[inicio]',
							'$matriz[duracao]',
							'S',
							'A',
							'$matriz[horario]'
		)";
	} #fecha inclusao
	
	elseif($tipo=='excluir') {
		# Verificar se ticket existe
		$tmpBusca=buscaTicket($matriz[id], 'id', 'igual', 'id');
		
		# Registro j� existe
		if(!$tmpBusca|| contaConsulta($tmpBusca)==0) {
			# Mensagem de aviso
			$msg=_("Record doesn't exist in the database");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: Error when deleting record"), $msg, $url, 760);
		}
		else {
			$sql="DELETE FROM $tb[Evento] WHERE id=$matriz[id]";
		}
	}
	
	# Alterar
	elseif($tipo=='alterar') {
		# Verificar se o ticket existe
		$sql="UPDATE $tb[Evento] 
				SET idTicket='$matriz[ticket]', 
					inicio='$matriz[inicio]',
					horario='$matriz[horario]',
					duracao=$matriz[duracao],
					status='$matriz[status]'
			  WHERE	id=$matriz[id]";
	}
		
	if($sql) { 
		#echo "Gravando: $sql<br>";
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
} # fecha fun��o de grava��o em banco de dados

function eventoInserirHorarios($matriz) {
	global $conn, $tb, $modulo, $acao, $sessLogin;
	
	#usuario
	$idUsuario=buscaIDUsuario($sessLogin[login],'login','igual','id');
	$perfil=dadosPerfilUsuario($idUsuario);
	$evento=dadosEvento($matriz[idEvento]);
	
	#calcular o horario inicial
	$inicioDia=$matriz[inicio];
	$inicioHora=$matriz[horario];
	
	#verifica se a hora nao ultrapassa o final do expediente
	if($inicioHora > $perfil[horarioFim]) {
		$inicioHora=$perfil[horarioInicio];
		$inicioDia=somaDia($inicioDia, 1);
	}
	
	#verifica se o dia nao ultrapassa o ultimo dia de expediente
	$ctrl=0;
	$inicioSemana=getDiaSemana($inicioDia, 'num');
	while (!$inicioSemana && $inicioSemana > $perfil[diaFim] &&$ctrl<7) {
		$inicioDia=somaDia($inicioDia, 1);
		$inicioSemana=getDiaSemana($inicioDia, 'num');
		$ctrl++;
	}
	$agenda[idEvento]=$evento[id];
	$sql="insert into $tb[Agenda] set idEvento=".$evento[id].", horario=";
	$dia=$inicioDia;
	$hora=$inicioHora;
	
	#gerar os registro da agenda
	for ($i=0; $i<$evento[duracao];$i++) {
		#monta o horario
		if (strlen($hora)<2) $hora='0'.$hora;
		$horario=$dia." ".$hora.":00:00";
		$agenda[horario]=converteData($horario, 'form', 'agenda');
		
		#grava
		#echo "<br>Agendando para ".$sql."'$agenda[horario]'";
		consultaSQL($sql."'$agenda[horario]'", $conn);
		#passa para o proximo horario
		$hora++;
		#verifica se a hora nao ultrapassa o final do expediente
		if($hora > $perfil[horarioFim]) {
			$hora=$perfil[horarioInicio];
			$dia=somaDia($dia, 1);
		}
		
		#verifica se o dia nao ultrapassa o ultimo dia de expediente
		$ctrl=0;
		$diaSemana=getDiaSemana($dia, 'num');
		# ex: Entra na Seg. e sai na Sexta
		if ( $perfil[diaFim] > $perfil[diaInicio] ){
			#echo "<br>$diaSemana > $perfil[diaFim] && $diaSemana < $perfil[diaInicio]";
			while ($diaSemana > $perfil[diaFim] || $diaSemana < $perfil[diaInicio]) {
				#echo "<br>pulando o dia $dia";
				$dia=somaDia($dia, 1);
				$diaSemana=getDiaSemana($dia, 'num');
				$ctrl++;
			}#fim do while
		}
		# ex: Entra na Qui. e sai na Seg
		elseif ( $perfil[diaFim] < $perfil[diaInicio] ){
			while ( !( $diaSemana <= $perfil[diaFim] || $diaSemana >= $perfil[diaInicio] ) ) {
				#echo "<br>pulando o dia $dia";
				$dia=somaDia($dia, 1);
				$diaSemana=getDiaSemana($dia, 'num');
				$ctrl++;
			}#fim do while			
		}
	}#fim do for
	
	if ( $matriz[opcoes] != 'S' ){
		#exibir o calendario
		eventoExibirCalendario($matriz);
	}
}


?>