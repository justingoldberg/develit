<?
################################################################################
# Fun��o:

#    Fun��es para formata��o de pagina e saidas HTML

/**
 * @return void
 * @param unknown $titulo
 * @param unknown $alinhamento
 * @param unknown $tamanho
 * @param unknown $borda
 * @param unknown $spcCel
 * @param unknown $spcCarac
 * @param unknown $corFundo
 * @param unknown $corBorda
 * @param unknown $colunas
 * @desc Fun��o para cria��o de tabelas
*/
function novaTabela($titulo, $alinhamento, $tamanho, $borda, $spcCel, $spcCarac, $corFundo, $corBorda, $colunas)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}

	# Criar nova tabela
	echo "<!-- Cria nova tabela [$titulo] -->\n
	<table width=$tamanho border=$borda cellpadding=0 cellspacing=0 bgcolor=$corBorda>\n
	<tr><td>\n
	<table width=$tamanho border=$borda cellpadding=$spcCel cellspacing=$spcCarac>\n
	<th $colspan width=$tamanho class=tabtitulo align=$alinhamento background=$corFundo>$titulo</th>\n";
} # Fecha fun��o tabelanova


/**
 * @return void
 * @param unknown $titulo
 * @param unknown $alinhamento
 * @param unknown $tamanho
 * @param unknown $borda
 * @param unknown $spcCel
 * @param unknown $spcCarac
 * @param unknown $corFundo
 * @param unknown $corBorda
 * @param unknown $colunas
 * @desc Fun��o para cria��o de tabelas
*/
function novaTabela2($titulo, $alinhamento, $tamanho, $borda, $spcCel, $spcCarac, $corFundo, $corBorda, $colunas)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}
	
	# Criar nova tabela
	echo "<!-- Cria nova tabela [$titulo] -->\n
	<table width=$tamanho border=$borda cellpadding=0 cellspacing=$spcCarac bgcolor=$corBorda>\n
	<tr><td>\n
	<table width=$tamanho border=0 cellpadding=$spcCel cellspacing=0>\n
	<th $colspan width=$tamanho class=tabtitulo align=$alinhamento background=$corFundo>$titulo</th>\n";
} # Fecha fun��o tabelanova


function novaTabela3($titulo, $alinhamento, $tamanho, $borda, $spcCel, $spcCarac, $corFundo, $corBorda, $colunas)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}
	
	# Criar nova tabela
	echo "<!-- Cria nova tabela [$titulo] -->\n
	<table width=$tamanho border=$borda cellpadding=0 cellspacing=$spcCarac bgcolor=$corBorda>\n
	<tr><td>\n
	<table width=100% border=0 cellpadding=$spcCel cellspacing=0>\n
	<th $colspan width=100% class=tabtitulo align=$alinhamento background=$corFundo>$titulo</th>\n";
} # Fecha fun��o tabelanova


/**
 * @return void
 * @param unknown $alinhamento
 * @param unknown $tamanho
 * @param unknown $borda
 * @param unknown $spcCel
 * @param unknown $spcCarac
 * @param unknown $corFundo
 * @param unknown $corBorda
 * @param unknown $colunas
 * @desc Fun��o para cria��o de tabelas - Sem Header
*/
function novaTabela2SH($alinhamento, $tamanho, $borda, $spcCel, $spcCarac, $corFundo, $corBorda, $colunas)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}
	
	# Criar nova tabela***********************************
	echo "<!-- Cria nova tabela [$titulo] -->\n
	<table width=$tamanho border=$borda cellpadding=0 cellspacing=$spcCarac bgcolor=$corBorda>\n
	<tr><td>\n
	<table width=$tamanho border=0 cellpadding=$spcCel cellspacing=0>\n";
} # Fecha fun��o tabelanova

/**
 * @return void
 * @param unknown $alinhamento
 * @param unknown $tamanho
 * @param unknown $borda
 * @param unknown $spcCel
 * @param unknown $spcCarac
 * @param unknown $corFundo
 * @param unknown $corBorda
 * @param unknown $colunas
 * @desc Fun��o para cria��o de tabelas - Sem Header
*/
function htmlAbreTabelaSH($alinhamento, $tamanho, $borda, $spcCel, $spcCarac, $corFundo, $corBorda, $colunas)
{
	# Criar nova tabela
	echo "
	<table width=$tamanho border=$borda cellpadding=0 cellspacing=0 bgcolor=$corBorda>\n
	<tr><td>\n
	<table width=$tamanho border=$borda cellpadding=$spcCel cellspacing=$spcCarac>\n";
} # Fecha fun��o tabelanova

function abreTabela1($alinhamento, $tamanho, $borda, $spcCel, $spcCarac, $corBorda)
{
	# Criar nova tabela
	echo "<table align=$alinhamento width=$tamanho border=$borda cellpadding=$spcCel cellspacing=$spcCarac bgcolor=$corBorda><tr><td>\n";
} # Fecha fun��o tabelanova

/**
 * @return void
 * @param unknown $corFundo
 * @desc Fun��o para cri��o de nova linha
*/
function htmlAbreLinha($corFundo)
{
	echo "<tr bgcolor=$corFundo>\n";
} #fecha fun��o de abertura de nova linha


/**
 * @return void
 * @desc Fun��o para fechar linha aberta
*/
function htmlFechaLinha()
{
	echo "</tr>\n";
} # fecha fun��o de fechamento de linha


function htmlAbreColunaEspecial($tamanho, $alinhamento_h,  $corFundo, $colunas, $classeCSS, $linhas) //******* 
{
	# Adicionar item
	echo "<td width=$tamanho colspan=$colunas rowspan=$linhas align=$alinhamento_h class=$classeCSS>\n";
} # fecha fun��o abrir nova coluna


/**
 * @return void
 * @param unknown $tamanho
 * @param unknown $alinhamento
 * @param unknown $corFundo
 * @param unknown $colunas
 * @param unknown $classeCSS
 * @desc Fun��o para abrir nova coluna - Sem alinhamento vertical
*/
function htmlAbreColuna( $tamanho, $alinhamento, $corFundo, $colunas, $classeCSS, $print=true ){
	# Adicionar item
	$ret = "<td width=\"$tamanho\" colspan=\"$colunas\" align=\"$alinhamento\" class=\"$classeCSS\">\n";
	if( $print ){
		echo $ret;
	}
	else {
		return $ret;
	}
} # fecha fun��o abrir nova coluna

# Fun��o para abrir nova coluna
/**
 * @return void
 * @param unknown $tamanho
 * @param unknown $alinhamento
 * @param unknown $alinhamentov
 * @param unknown $corFundo
 * @param unknown $colunas
 * @param unknown $classeCSS
 * @desc Fun��o para abrir nova coluna - Com alinhamento vertical
*/
function htmlAbreColunaForm($tamanho, $alinhamento, $alinhamentov, $corFundo, $colunas, $classeCSS)
{
	# Adicionar item
	echo "<td width=$tamanho colspan=$colunas align=$alinhamento valign=$alinhamentov class=$classeCSS>\n";
} # fecha fun��o abrir nova coluna

# Fun��o para fechar nova coluna
/**
 * @return void
 * @desc Fun��o para fechar nova coluna
*/
function htmlFechaColuna( $print = true ) {
	# Adicionar item
	$ret = "</td>\n";
	if( $print ){
		echo $ret;
	}
	else {
		return $ret;
	}
} # fecha fun��o fecha coluna aberta


# Fun��o para adicionar items a tabela
/**
 * @return void
 * @param unknown $item
 * @param unknown $url
 * @param unknown $alinhamento
 * @param unknown $corFundo
 * @param unknown $colunas
 * @param unknown $classeCSS
 * @desc Fun��o para adicionar items a tabela - Com link
*/
function itemTabela($item, $url, $alinhamento, $corFundo, $colunas, $classeCSS)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}

	# Adicionar item
	echo "
	<tr bgcolor=$corFundo>\n
	<td $colspan align=$alinhamento class=$classeCSS><a href=$url>$item</a></td>\n
	</tr>\n";
} # fecha fun��o para adicionar items a tabela


# Fun��o para adicionar items a tabela
/**
 * @return void
 * @param unknown $item
 * @param unknown $alinhamento
 * @param unknown $corFundo
 * @param unknown $colunas
 * @param unknown $classeCSS
 * @desc Fun��o para adicionar items a tabela - sem link
*/
function itemTabelaNOURL($item, $alinhamento, $corFundo, $colunas, $classeCSS)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}

	# Adicionar item
	echo "
	<tr bgcolor=$corFundo>\n
	<td $colspan align=$alinhamento class=$classeCSS>$item</td>\n
	</tr>\n";
} # fecha fun��o para adicionar items a tabela


# Fun��o para adicionar items a tabela
function itemLinha($item, $url, $alinhamento, $corFundo, $colunas, $classeCSS)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}

	# Adicionar item
	echo "<td $colspan align=$alinhamento class=$classeCSS><a href=$url>$item</a></td>\n";
} # fecha fun��o para adicionar items a tabela

# Fun��o para adicionar items a tabela
function itemLinhaForm($item, $alinhamento, $alinhamentov, $corFundo, $colunas, $classeCSS, $print=true){
	if( $colunas > 0 ) {
		$colspan="colspan=\"".$colunas."\""; 
	}

	# Adicionar item 
	$ret= "<td $colspan align=\"$alinhamento\" valign=\"$alinhamentov\" class=\"$classeCSS\">$item</td>\n";
	if( $print ){
		echo $ret;
	}
	else {
		return $ret;
	}
} # fecha fun��o para adicionar items a tabela


# Fun��o para adicionar items com link na tabela
/**
 * @return void
 * @param unknown $item
 * @param unknown $url
 * @param unknown $alinhamento
 * @param unknown $alinhamentov
 * @param unknown $tamanho
 * @param unknown $corFundo
 * @param unknown $colunas
 * @param unknown $classeCSS
 * @desc C�lula de tabela com link e com alinhamento h e v
*/
function itemLinhaTM($item, $url, $alinhamento, $alinhamentov, $tamanho, $corFundo, $colunas, $classeCSS)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}

	# Adicionar item 
	echo "<td $colspan align=$alinhamento valign=$alinhamentov class=$classeCSS width=$tamanho><a href=$url>$item</a></td>\n";
} # fecha fun��o para adicionar items a tabela


# Fun��o para adicionar items sem link na tabela
/**
 * @return void
 * @param unknown $item
 * @param unknown $alinhamento
 * @param unknown $alinhamentov
 * @param unknown $tamanho
 * @param unknown $corFundo
 * @param unknown $colunas
 * @param unknown $classeCSS
 * @desc Celula com alinhamento h e v
*/
function itemLinhaTMNOURL($item, $alinhamento='left', $alinhamentov='middle', $tamanho='100%', $corFundo, $colunas, $classeCSS)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}
	
	$align="align=".$alinhamento; 
	$valign="valign=".$alinhamentov; 
	
	# Adicionar item 
	echo "<td $colspan $align $valign width=$tamanho class=$classeCSS>$item</td>\n";
} # fecha fun��o para adicionar items a tabela


/**
 * @return void
 * @param unknown $item
 * @param unknown $alinhamento
 * @param unknown $corFundo
 * @param unknown $colunas
 * @param unknown $classeCSS
 * @desc Fun��o para adicionar celulas a tabela
*/
function itemLinhaNOURL($item, $alinhamento, $corFundo, $colunas, $classeCSS)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}

	# Adicionar item
	echo "<td $colspan align=$alinhamento class=$classeCSS>$item</td>\n";
} # fecha fun��o para adicionar items a tabela


# Fun��o para adicionar items a tabela
function itemLinhaCorNOURL($item, $alinhamento, $corFundo, $colunas, $classeCSS, $cor)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}

	# Adicionar item
	echo "<td $colspan align=$alinhamento class=$classeCSS bgcolor=$cor>$item</td>\n";
} # fecha fun��o para adicionar items a tabela


# Fun��o para adicionar items a tabela
function itemLinhaCor($item, $url, $alinhamento, $corFundo, $colunas, $classeCSS, $cor)
{
	if($colunas>0) {
		$colspan="colspan=".$colunas; 
	}

	# Adicionar item
	echo "<td $colspan align=$alinhamento class=$classeCSS bgcolor=$cor><a href=$url>$item</a></td>\n";
} # fecha fun��o para adicionar items a tabela


# Fun��o para cria��o de linha na tabela (usado para items de coluna)
function novaLinhaTabela($fundo, $tamanho, $print=true) {
	$ret = "<tr bgcolor=$fundo>\n";
	if( $print ){
		echo $ret;
	}
	else {
		return $ret;
	}
} # fecha fun��o de cria��o de linha na tabela


# Fun��o para adicionar itens de coluna
function titLinhaTabela($item, $alinhamento, $tamanho, $classeCSS)
{
	# Adicionar item
	echo "<td class=$classeCSS width=$tamanho align=$alinhamento>$item</td>\n";
} # fecha fun��o para adicionar itens de coluna


# Fun��o para adicionar itens de coluna
function itemLinhaTabela($item, $alinhamento, $tamanho, $classeCSS)
{
	# Adicionar item
	echo "<td width=$tamanho align=$alinhamento class=$classeCSS valign=middle>$item</td>\n";
} # fecha fun��o para adicionar itens de coluna



# Fun��o para fechar linha na tabela (usado para itens de coluna)
function fechaLinhaTabela( $print=true ){
	$ret = "</tr>\n";
	if( $print ){
		echo $ret;
	}
	else {
		return $ret;
	}
} #fecha fun��o para fechar linha da tabela



# fun��o para finalizar tabela
function fechaTabela()
{
	echo "</table></td></tr></table>\n";
} # Fecha fun��o fechatabela

# fun��o para finalizar tabela
function fechaTabela1()
{
	echo "</td></tr></table>\n";
} # Fecha fun��o fechatabela



# Fun��es para resultados HTML em tela
function aviso($titulo, $msg, $url, $tamanho)
{
	global $corFundo, $corBorda;

	novaTabela("$titulo", "left", $tamanho, 0, 2, 1, $corFundo, $corBorda, 0);
	itemTabelaNOURL($msg,'left',$corFundo, 0, 'txtaviso');
	if(!$url) itemTabela(_("Back"),"javascript.history.back(-1)",'right',$corFundo, 0, 'normal');
	fechaTabela();
	
} # fecha fun��o aviso

# Fun��es para resultados HTML em tela
function avisoUrl($titulo, $msg, $url, $tamanho)
{
	global $corFundo, $corBorda;

	novaTabela("$titulo", "left", $tamanho, 0, 2, 1, $corFundo, $corBorda, 0);
	itemTabelaNOURL($msg,'left',$corFundo, 0, 'txtaviso');
	if(!$url) {
		itemTabela(_("Back"),"javascript.history.back(-1)",'right',$corFundo, 0, 'normal');
	}
	else {
		itemTabela(_("Back"),$url,'right',$corFundo, 0, 'normal');
	}
	fechaTabela();
	
} # fecha fun��o aviso

# Fun��es para resultados HTML em tela
function avisoNOURL($titulo, $msg, $tamanho)
{
	global $corFundo, $corBorda;

	novaTabela("$titulo", "left", $tamanho, 0, 2, 1, $corFundo, $corBorda, 0);
	itemTabelaNOURL($msg,'left',$corFundo, 0, 'txtaviso');	
	fechaTabela();
	
} # fecha fun��o aviso



# Fun��es para resultados HTML em tela
function avisoFechar($titulo, $msg, $url, $tamanho)
{
	global $corFundo, $corBorda;

	novaTabela("$titulo", "left", $tamanho, 0, 2, 1, $corFundo, $corBorda, 0);
	itemTabelaNOURL($msg,'left',$corFundo, 0, 'txtaviso');
	itemTabela(_("Close"),$url,'right',$corFundo, 0, 'normal');
	fechaTabela();
	
} # fecha fun��o aviso

# Fun��o de cabe�alho
function html_header($titulo, $versao, $js="")
{
	global $modulo,$sub, $acao;
	
	$opcFocus="";
	
	if( $acao ) {
		# Mostrar cabe�alho HTML
		//$opcFocus="onLoad=\"javascript:if(document.forms[0]){document.forms[0].elements[4].focus()}\"";
	}
	elseif( $modulo == 'logoff' || $modulo == 'login' || ( !$modulo && !$sub && !$acao ) ){
		$opcFocus="onLoad=\"javascript:if(document.forms[0]){document.forms[0].elements[5].focus()}\"";
	}
	echo "<html>
<head>
<title>$titulo - $versao</title>
<link rel=\"stylesheet\" type=\"text/css\" href=\"".( strstr( $_SERVER["SCRIPT_NAME"], 'installer' ) ? "../estilos.css" : "estilos.css" )."\">
$js
</head>\n";
	
if($sub != 'chat' && $modulo != 'protocolo') echo "<body $opcFocus>";

} # fim da fun��o de cabe�alho




# Fun��o de rodap�
function html_footer($rodape)
{
	echo "<p class=rodape align=left>$rodape</p>\n
</body>\n
</html>\n";
} # fim da fun��o de rodap�



# Fun��o para mostrar tipo de Status da Fila de Processos
function fila_chk_status($status)
{
	# Verificar tipo de status recebido
	if($status=="N")
	{
		$retorno="<span class=fila_novo>"._("New")."</span>";
	}
	elseif($status=="L")
	{
		$retorno="<span class=fila_lib>"._("Liberated")."</span>";
	}
	elseif($status=="E")
	{
		$retorno="<span class=fila_exec>"._("Running")."</span>";
	}
	elseif($status=="P")
	{
		$retorno="<span class=fila_proc>"._("Processed")."</span>";
	}
	elseif($status=="I")
	{
		$retorno="<span class=fila_ig>"._("Ignored")."</span>";
	}
	elseif($status=="F")
	{
		$retorno="<span class=fila_falha>"._("FAILED")."</span>";
	}
	else
	{
		$retorno="<span class=fila_erro>"._("INVALID")."</span>";
	}
	
	return($retorno);
	
} # fim da fun��o de mostragem de tipo de status dos processos


# fun��o para montagem de op��es para URLs e Links
function htmlMontaOpcao($texto, $tipo)
{
	global $htmlDirImagem, $html;
	

	return("<span style=\"white-space: nowrap;\"><img src=\"".$html[imagem][$tipo]."\" border=\"0\">$texto&nbsp;</span>");
	
}


# Fun��o para montar campo de formulario
function formStatus()
{
	
	$item="<select name=matriz[status]>\n";
	$item.= "<option value=D>"._("Disabled")."\n";
	$item.= "<option value=A>"._("Activated")."\n";
	$item.="</select>";
	
	return($item);
	
} #fecha funcao de montagem de campo de form

# Fun��o para montar campo de formulario - selecionando atual situacao
function formChecaStatus($status)
{
	# Status ativo
	if($status=='A') { $opcAtivo='selected'; }
	if($status=='D') { $opcDesativo='selected'; }
	
	$item="<select name=matriz[status]>\n";
	$item.= "<option value=D $opcDesativo>"._("Disabled")."\n";
	$item.= "<option value=A $opcAtivo>"._("Activated")."\n";
	$item.="</select>";
	
	return($item);
	
} #fecha funcao de montagem de campo de form

# Fun��o para checagem de status
function checaStatus($status)
{
	if($status=='A') {
		$retorno="<span class=txtok>"._("Activated")."</span>";
	}
	elseif($status=='D') {
		$retorno="<span class=txtaviso>"._("Disabled")."</span>";
	}
	elseif($status=='N') {
		$retorno="<span class=txtaviso>"._("New (disabled)")."</span>";
	}
	
	return($retorno);
}

# Fun��o para montar campo de formulario - selecionando op��es
function formGeraSelect($nome, $opcoes, $valores, $selecionado = "", $conteudoNaoSelecionado = ""){
	# Status ativo
	$item = "<select name=\"$nome\">\n";
	$item.= ( $selecionado == "") ? "<option>$conteudoNaoSelecionado</option>" : "";
	if(count($valores) > 0 && count($opcoes) > 0 && count($valores) == count($opcoes)) {
		for($i = 0; $i < count($valores); $i++) {
			$selected = ($valores[$i] == $selecionado) ? 'selected="selected"' : "";
			$item.= "<option value=\"$valores[$i]\" $selected>$opcoes[$i]</option>\n";
		}
	}
	$item.= "</select>";
	
	return( $item );
} #fecha Fun��o para montar campo de formulario - selecionando op��es

function abreLayer($id, $titulo, $oculto=false, $tamanho=400, $borda=1){
	global $corBordaLayer, $corFundoLayer, $html;
	
	$left = (int)( ( 760 - (int)$tamanho ) / 2 );
	
	$show = ( $oculto ? "none" : "block" );
	
	echo "<div id=\"$id\" style=\"display:$show; position:absolute; left:".$left."px; align:center; top:180px; z-index:2\">\n".
	"<table width=\"$tamanho\" border=\"0\" cellpadding=\"2\" cellspacing=\"0\" style=\"border: 1px solid $corBordaLayer;\">\n".
	"<tr bgcolor=\"$corBordaLayer\">\n".
	"<th width=\"5%\">&nbsp;</th>\n".
	"<th width=\"$tamanho\" class=\"tabtitulo\" align=\"$alinhamento\">$titulo</th>\n".
	"<th width=\"5%\"><img title=\""._("Close")."\" src=\"".$html['imagem']['fechar']."\" border=\"0\" align=\"right\" onclick=\"document.getElementById('$id').style.display='none'\"></th>\n".
	"<tr>\n".
	"<tr><td colspan=\"3\" bgcolor=\"$corFundoLayer\">\n";
}

function fechaLayer(){
	echo "</td></tr>\n".
	"</table>\n".
	"</div>\n";
}

?>