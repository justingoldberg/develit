<?php
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 19/12/2002
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 003
#
# Fun��o:
#    Fun��es para paginador

// Fun��o para pagina��o
function paginador($consulta, $total, $limite, $registro, $classeCSS, $colunas, $urlADD)
{
	# Variaveis globais
	global $html, $conn, $modulo, $sub, $acao, $corFundo, $corBorda;
	
	if((is_numeric($registro) || !$registro) && $registro <= $total) {

		# Paginador - calculo das URLs
		# Calcular P�gina Anterior
		if( ($registro-$limite) >= 0) {
			# Pagina��o anterior, OK
			$paginador[anterior]=$registro-$limite;
		}
		# Calcular P�gina posterior
		if( $registro+$limite <= $total) {
			# Pagina��o Posterior
			$paginador[posterior]=$registro+$limite;
			$paginador[ultima]=(($total/$limite)*$limite-($total%$limite))-$limite;
		}
		if($registro==0 && ($registro+$limite) < $total-1) {
			$paginador[posterior]=$registro+$limite;
			$paginador[ultima]=(($total/$limite)*$limite-($total%$limite))-$limite;
		}
		
		# Caso pagina��o seja realmente feita, montar tabela do paginador
		if($paginador && $total > $limite) {
			novaLinhaTabela($corFundo, '100%');
				# Abrir linha em tabela de modulo para mostrar paginador
				htmlAbreColuna('100%', left, $corFundo, $colunas, 'normal');
		
					htmlAbreTabelaSH('left', '100%', 0, 2, 1, $corFundo, $corBorda, 3);
					# Mostrar marcadores
					htmlAbreLinha($corFundo);
					htmlAbreColuna('100', 'center', $corFundo, 0, 'tabfundo1');
					echo "<b>"._("Navigation")."</b>";
					htmlFechaColuna();
					
					# Verificar PRIMEIRA				
					if(($registro-$limite) > 0 && $registro > $limite )
					{
						$url="?modulo=$modulo&sub=$sub&acao=$acao&registro=$paginador[primeira]".$urlADD;
						$item.="<a href=$url><img src=".$html[imagem][setaprimeira]." border=0 alt="._("First page").">"._("First")."</a>";
					}
					
					# Verificar PAGINA ANTERIOR
					if($registro-$limite >= 0)
					{
						$url="?modulo=$modulo&sub=$sub&acao=$acao&registro=$paginador[anterior]".$urlADD;
						$item.="&nbsp;&nbsp;&nbsp;<a href=$url><img src=".$html[imagem][setaesquerda]." border=0 alt="._("Previous page").">"._("Previous")."</a>";
				
					}
					# Verificar P�GINA POSTERIOR
					if($registro+$limite < $total)
					{
						$url="?modulo=$modulo&sub=$sub&acao=$acao&registro=$paginador[posterior]".$urlADD;
						$item.="&nbsp;&nbsp;&nbsp;<a href=$url>"._("Next page")."<img src=".$html[imagem][setadireita]." border=0 alt="._("Next page")."></a>";
					}
	
					# Verificar ULTIMA
					if($registro+(2*$limite) < $total)
					{
						$url="?modulo=$modulo&sub=$sub&acao=$acao&registro=$paginador[ultima]".$urlADD;
						$item.="&nbsp;&nbsp;&nbsp;<a href=$url>"._("Last page")."<img src=".$html[imagem][setaultima]." border=0 alt="._("Last page")."></a>";
					}
	
					if($item) {
						htmlAbreColuna('130', 'center', $corFundo, 0, 'normal');
						$pgDe=intval((($registro/$limite)))+1;
						$pgAte=($total/$limite);
						# Verificar de pagina (ate) tem valor quebrado
						if(!is_integer($pgAte)){
							# Arredondar
							$pgAte=intval($pgAte)+1;
						}
						# Mostrar pagina��o
						echo _("Page")."&nbsp;".$pgDe."&nbsp;"._("of")."&nbsp;".$pgAte;
						htmlFechaColuna();
						itemLinhaNOURL($item, 'center', $corFundo, 0, 'normal');
					}
	
			# Finaliza tabela do paginador.
				htmlFechaColuna();
			fechaLinhaTabela();
					
			htmlFechaLinha();
			fechaTabela();
		}
	}
} # fecha fun��o de paginador


?>