<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 20/01/2005
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 003
#
# Fun��o:
#    Painel - Fun��es para cadastro de m�quinas

# fun��o de busca 
function buscaMaquinas($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Maquinas] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[Maquinas] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[Maquinas] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[Maquinas] WHERE $texto ORDER BY $ordem";
	}
//echo "SQL: $sql<br>";	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
ECHO"SQL> $sql<br>";	
} # fecha fun��o de busca

function formSelectMaquinasEmpresa($registro, $empresa, $campo, $tipo, $maquina = '', $acao = '') {
	global $isp, $conn, $tb;
	if($tipo=='form') {
		$consulta= buscaMaquinas($empresa,'idEmpresa','igual','nome');
	}
	elseif($tipo=='check') {
		$consulta=buscaMaquinas($registro,'id','igual','id');
	}
	# Condi��o implementada para listar apenas as m�quinas relacionadas � um suporte cadastrado
	# no ISP-IT - por Felipe Assis - 10/06/2008
	elseif($tipo == 'maquinasEmpresa'){
		$sql = "SELECT $tb[Maquinas].id as id, " .
			    "$tb[Maquinas].nome as nome, " . 
			    "$tb[Maquinas].ip as ip "  .
			    "FROM $tb[Empresas] LEFT JOIN $tb[Maquinas] " .
				"ON ($tb[Empresas].id = $tb[Maquinas].idEmpresa) " .
				"LEFT JOIN $tb[MaquinasSuporte] " .
				"ON ($tb[Maquinas].id = $tb[MaquinasSuporte].idMaquina) " .
				"WHERE Empresas.id = $registro ORDER BY Maquinas.id";
		$consulta = consultaSQL($sql, $conn);
	}
		
	if($consulta && contaConsulta($consulta)>0) {
		if($tipo == 'form' || $tipo == 'maquinasEmpresa') {
			$retorno="<select name=matriz[$campo]>\n";
			
			for($a=0;$a<contaConsulta($consulta);$a++) {
				
				$id=resultadoSQL($consulta, $a, 'id');
				$nome=substr(resultadoSQL($consulta, $a, 'nome'),0,40);
				$ip=substr(resultadoSQL($consulta, $a, 'ip'),0,40);
				
				if($maquina == $id){
					$opcSelect='selected';
				} 
				else {
					$opcSelect='';
				}
				
				# Verificar se registro j� est� em banco de dados de Empresas
				$retorno.="<option value=$id $opcSelect>$nome</option>\n";
			}
		}
		elseif($tipo=='check') {
			$nome=resultadoSQL($consulta, 0, 'nome');
			$ip=resultadoSQL($consulta, 0, 'ip');
			
			$retorno="$nome";
			if($ip)
				$retorno.=" - $ip";
		}
	}
	else {
		$retorno = "<font class=txtaviso>";
		$retorno .= _("Isn't possible to relate this Ticket with company because there isn't hosts registred.");
		$retorno .= "</font>";
	}
	
	return($retorno);
}

##########################################################################################################################################
###############################																			  ################################
#############################################		SISTEMA DE LOGIN PARA USUARIO_EMPRESA		##########################################
###############################																			  ################################
##########################################################################################################################################

/**
 * Enter description here...
 *
 * @param unknown_type $modulo
 * @param unknown_type $sub
 * @param unknown_type $acao
 * @param unknown_type $registro
 * @param unknown_type $matriz
 */
function maquinaUE( $modulo, $sub, $acao, $registro, $matriz ){
	if ( !$sub ){
		if ( $acao == 'verUE' ){
			#visualizar as maquinas relacionada com a empresa (pelo login do usuario-empresa)
			verMaquinaUE( $modulo, $sub, $acao, $registro, $matriz );
			echo "<br>";
			# visualizar os tickets relacionados com a maquina.
			verRelacionamento( $modulo, $sub, $acao, $registro, $matriz );
		}
		
	}
}

function verMaquinaUE( $modulo, $sub, $acao, $registro, $matriz ){
	global $corFundo, $corBorda, $html;

	# ERRO - Registro n�o foi informado
	if(!$registro) {
		# Mostrar Erro
		$msg=_("Record not found!");
		$url="?modulo=$modulo&sub=$sub&acao=$acao";
		aviso(_("Warning"), $msg, $url, 760);
	}
	# Form de inclusao
	elseif($registro) {
	
		# Buscar Valores
		$consulta=buscaMaquinas($registro, 'id', 'igual', 'id');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# Mostrar Erro
			$msg=_("Record not found!");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning"), $msg, $url, 760);
		}
		else {
			#atribuir valores
 			$nome		=resultadoSQL($consulta, 0, 'nome');
 			$ip			=resultadoSQL($consulta, 0, 'ip');
 			$cliente	=resultadoSQL( $consulta, 0, 'cliente' );
 			$idEmpresa	=resultadoSQL( $consulta, 0, 'idEmpresa' );
 			$nomeEmpresa=resultadoSQL( buscaEmpresas( $idEmpresa, 'id', 'igual', 'id' ), 0, 'nome' );
 			$data		=resultadoSQL( $consulta, 0, 'data');
 			$obs		=resultadoSQL( $consulta, 0, 'obs');
			
			# Motrar tabela de busca
			novaTabela2("["._("View Host")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>"._("Name:")." </b>";
					htmlFechaColuna();
					itemLinhaForm($nome, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>"._("IP:")." </b>";
					htmlFechaColuna();
					itemLinhaForm($ip, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>"._("Customer's Name").": </b>";
					htmlFechaColuna();
					itemLinhaForm($cliente, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>"._("Name of the Company").": </b>";
					htmlFechaColuna();
					itemLinhaForm($nomeEmpresa, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>"._("Date:")." </b>";
					htmlFechaColuna();
					itemLinhaForm( converteData( $data, 'banco', 'formdata' ), 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>"._("Commentary:")." </b>";
					htmlFechaColuna();
					itemLinhaForm($obs, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaForm("&nbsp;", 'left', 'top', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				
			fechaTabela();
		} #fecha alteracao
	} #fecha form - !$bntExcluir
}

function verRelacionamento( $modulo, $sub, $acao, $registro, $matriz ){
	
	global $conn, $corFundo, $corBorda, $html, $modulo, $sub, $acao, $limite, $matriz, $sessLogin;
	
	$permissao = buscaUsuariosEmpresas( $sessLogin['login'], 'login', 'igual', 'id' );
	if(!$permissao) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
	
//			$selecao="<form name=matriz action=index.php method=post>
//			<input type=hidden name=modulo value=$modulo>
//			<input type=hidden name=sub value=$sub>
//			<input type=hidden name=acao value=$acao>";
			
			htmlAbreTabelaSH('center', '100%', 0, 2, 1, $corFundo, $corBorda, 7);
			htmlAbreLinha($corBorda);
				itemLinhaTMNOURL("["._("Last Tickets")."]", 'center', 'middle', '100%', $corFundo, 7, 'tabtitulo');
			htmlFechaLinha();
//			htmlAbreLinha($corBorda);
//				itemLinhaNOURL($selecao, 'right', $corFundo, 7, 'tabfundo1');
//			htmlFechaLinha();
			# $idEmpresas s�o as empresas a qual o usuario-empresa pertence
			$idEmpresa = buscaIDsEmpresaUE( $sessLogin['login'] );
			$idUsuario = buscaIDUsuario( 'guest', 'login', 'igual', 'id' );
			$sql="
				SELECT 
					ticket.id, 
					ticket.idUsuario idUsuarioTicket, 
					ticket.assunto, 
					ticket.data dataTicket, 
					ticket.status status, 
					ticket.idPrioridade idPrioridade, 
					processos_ticket.data dataProcesso, 
					processos_ticket.idUsuario idUsuarioProcesso 
				FROM 
					ticket 
				INNER JOIN categorias ON (ticket.id=processos_ticket.idTicket ) 
				INNER JOIN processos_ticket ON (ticket.id=processos_ticket.idTicket ) 
				INNER JOIN usuarios ON (ticket.idUsuario=usuarios.id ) 
				INNER JOIN ticket_empresa ON (ticket.id=ticket_empresa.idTicket ) 
				INNER JOIN Maquinas ON (ticket_empresa.idMaquina=Maquinas.id) 
				WHERE 
					ticket_empresa.idEmpresa in ($idEmpresa) 
					AND Maquinas.id=$registro 
					AND ticket.status !='F' 
				GROUP BY
					ticket.id 
				ORDER BY 
					dataProcesso DESC";
//				usuarios.id=$idUsuario AND 
			$consulta=consultaSQL($sql, $conn);
			
			if($consulta && contaConsulta($consulta)>0) {
			
				# Paginador
				paginador($consulta, contaConsulta($consulta), $limite[resumo][ultimos], $registro, 'normal10', 7, $urlADD);
				
				# Listar ultimos tickets de acordo com limite
				$i=0;
				$linha=0;
				
//				# Setar registro inicial
//				if(!$registro) {
//					$i=0;
//				}
//				elseif($registro && is_numeric($registro) ) {
//					$i=$registro;
//				}
//				else {
//					$i=0;
//				}
//	
//				$limite=$i+$limite[resumo][ultimos];
				while($i<contaConsulta($consulta)) {
					# Informa��es sobre ticket
					$id=resultadoSQL($consulta, $i, 'id');
					$assunto=resultadoSQL($consulta, $i, 'assunto');
					$status=checaValorStatus(resultadoSQL($consulta, $i, 'status'));
					$idPrioridade=resultadoSQL($consulta, $i, 'idPrioridade');
					if($idPrioridade) {
						$prioridade=checaPrioridade($idPrioridade);
						$cor=$prioridade[cor];
					}
					else $cor='#ffffff';
					$idUsuarioCriador=resultadoSQL($consulta, $i, 'idUsuarioTicket');
					$dataTicket=converteData(resultadoSQL($consulta, $i, 'dataTicket'), 'banco','formdata');
					$dataProcesso=converteData(resultadoSQL($consulta, $i, 'dataProcesso'), 'banco','formdata');
					
					# Buscar dados do ticket
					$dadosTicket=buscaProcessosTicket($id, 'idTicket','igual','data DESC');
					$comentarioTicket=buscaUltimoComentarioTicket($id);
					$idUsuarioProcesso=resultadoSQL($dadosTicket, 0, 'idUsuario');				
					
					# Busca o usuario
					$usuario=buscaLoginUsuario($idUsuarioProcesso, 'id','igual','id');
											
					if($status[status] != 'F') {
					
						if($linha==0) {
							htmlAbreLinha($corFundo);
								itemLinhaTMNOURL(_("Group Tickets:"), 'center', 'middle', '65%', $corFundo, 2, "tabfundo0");
								itemLinhaTMNOURL(_('Status'), 'center', 'middle', '5%', $corFundo, 0, "tabfundo0");
								itemLinhaTMNOURL(_('Created by'), 'center', 'middle', '15%', $corFundo, 2, "tabfundo0");
								itemLinhaTMNOURL(_('Last Modification'), 'center', 'middle', '15%', $corFundo, 2, "tabfundo0");
							htmlFechaLinha();
						}
							
						# Verificar ultima data
						$fundo=$linha%2+1;
						$linha++;
						
						if(!$comentarioTicket[idUsuario]){
							$icone=iconeTicket($idUsuarioCriador, $idUsuarioProcesso, $id);
						}
						else {
							$icone=iconeTicket($idUsuarioCriador, $comentarioTicket[idUsuario], $id);
							if ($comentarioTicket[data]>resultadoSQL($consulta, $i, 'dataTicket')){
								$dataProcesso=converteData($comentarioTicket['data'], 'banco', 'formdata');
								$usuario=$comentarioTicket['login'];
							}
						}
						
						htmlAbreLinha($corFundo);
							itemLinhaCorNOURL('&nbsp;', 'center', $corFundo, 0, "normal10", $cor);
							$texto="$icone<a href=?modulo=ticketUE&acao=verUE&registro=$id class=bold10>$assunto</a>";
							itemLinhaTMNOURL($texto, 'left', 'middle', '65%', $corFundo, 0, "tabfundo8$fundo");
							itemLinhaTMNOURL($status[nome], 'center', 'middle', '5%', $corFundo, 0, "tabfundo8$fundo");
							itemLinhaTMNOURL(buscaLoginUsuario($idUsuarioCriador,'id','igual','id'), 'center', 'middle', '7%', $corFundo, 0, "tabfundo8$fundo");
							itemLinhaTMNOURL($dataTicket, 'center', 'middle', '8%', $corFundo, 0, "tabfundo8$fundo");
							itemLinhaTMNOURL($usuario, 'center', 'middle', '7%', $corFundo, 0, "tabfundo8$fundo");
							itemLinhaTMNOURL($dataProcesso, 'center', 'middle', '8%', $corFundo, 0, "tabfundo8$fundo");
						htmlFechaLinha();
					}
						
					if($linha >= $limite[resumo][ultimos]) break;
					
					# Incrementar contador
					$i++;
				}
				
				if($linha==0) {
					# Nenhum registro encontrado
					itemTabelaNOURL(_('Select Group for visualization of Last Tickets!'), 'left', $corFundo, 7, 'txtaviso');
				}
			}
			else {
				# Nenhum registro encontrado
				itemTabelaNOURL(_('Select Group for visualization of Last Tickets!'), 'left', $corFundo, 7, 'txtaviso');
			}
		
		fechaTabela();
	
	}
}
?>