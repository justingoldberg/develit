<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 15/04/2003
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 006
#
# Fun��o:
#    Painel - Fun��es para cadastro de categorias


# Fun��o para cadastro
function categorias($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $sessLogin;
	
	# Permiss�o do usuario
	$permissao=buscaPermissaoUsuario($sessLogin[login],'login','igual','login');
	
	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
		
		# Topo da tabela - Informa��es e menu principal do Cadastro
		novaTabela2("["._("Categories")."]", "center", '100%', 0, 3, 1, $corFundo, $corBorda, 4);
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('65%', 'left', $corFundo, 0, 'tabfundo1');
					echo "<br><img src=".$html[imagem][categoria]." border=0 align=left><b class=bold>"._("Categories")."</b>
					<br><span class=normal10>"._("Cadaster of")."&nbsp;"."<b>"._("categories")."</b>"."&nbsp;"._("for organization of the Tickets")."</span>";
				htmlFechaColuna();
				$texto=htmlMontaOpcao("<br>"._("Add"), 'incluir');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=adicionar", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>"._("Search"), 'procurar');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=procurar", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>"._("List"), 'listar');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=listar", 'center', $corFundo, 0, 'normal');
			fechaLinhaTabela();
		fechaTabela();
		
		# Mostrar Status para n�o seja informada a a��o
		if(!$acao) {
			# Mostrar Status
			echo "<br>";
			listarCategorias($modulo, $sub, $acao, $registro, $matriz);
		}
		
		# Inclus�o
		if($acao=="adicionar") {
			echo "<br>";
			incluirCategorias($modulo, $sub, $acao, $registro, $matriz);
		}
		
		# Altera��o
		elseif($acao=="alterar") {
			echo "<br>";
			alterarCategorias($modulo, $sub, $acao, $registro, $matriz);
		}
		
		# Exclus�o
		elseif($acao=="excluir") {
			echo "<br>";
			excluirCategorias($modulo, $sub, $acao, $registro, $matriz);
		}
		
		# Busca
		elseif($acao=="procurar") {
			echo "<br>";
			procurarCategorias($modulo, $sub, $acao, $registro, $matriz);
		} #fecha tabela de busca
		
		# Listar
		elseif($acao=="listar") {
			echo "<br>";
			listarCategorias($modulo, $sub, $acao, $registro, $matriz);
		} #fecha listagem de servicos
		
		# Grupos - listagem
		elseif($acao=="grupos") {
			echo "<br>";
			listarCategoriasGrupos($modulo, $sub, $acao, $registro, $matriz);
		} #fecha listagem de servicos
		
		# Grupos - adicionar
		elseif($acao=="gruposadicionar") {
			echo "<br>";
			adicionarCategoriasGrupos($modulo, $sub, $acao, $registro, $matriz);
		} #fecha listagem de servicos
		
		# Grupos - excluir
		elseif($acao=="gruposexcluir") {
			echo "<br>";
			excluirCategoriasGrupos($modulo, $sub, $acao, $registro, $matriz);
		} #fecha listagem de servicos
	}
		

} #fecha menu principal


# fun��o de busca
function buscaCategorias($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Categorias] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[Categorias] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[Categorias] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[Categorias] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	
} # fecha fun��o de busca


# Listar
function listarCategorias($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $moduloApp, $corFundo, $corBorda, $html, $limite;
	
	# Cabe�alho
	# Motrar tabela de busca
	novaTabela("["._("List")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
		# Sele��o de registros
		$consulta=buscaCategorias($texto, $campo, 'todos','nome');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# N�o h� registros
			itemTabelaNOURL(_('There are not registered record'), 'left', $corFundo, 3, 'txtaviso');
		}
		else {
		
			# Paginador
			paginador($consulta, contaConsulta($consulta), $limite[lista][categorias], $registro, 'normal10', 3, $urlADD);
		
			# Cabe�alho
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela(_('Category'), 'center', '50%', 'tabfundo0');
				itemLinhaTabela(_('Date')."&nbsp;"._("of")."&nbsp;"._('Creation'), 'center', '10%', 'tabfundo0');
				itemLinhaTabela(_('Options'), 'center', '40%', 'tabfundo0');
			fechaLinhaTabela();
		
			# Setar registro inicial
			if(!$registro) {
				$i=0;
			}
			elseif($registro && is_numeric($registro) ) {
				$i=$registro;
			}
			else {
				$i=0;
			}
		
			$limite=$i+$limite[lista][categorias];
		
			while($i < contaConsulta($consulta) && $i < $limite) {
				# Mostrar registro
				$id=resultadoSQL($consulta, $i, 'id');
				$nome=resultadoSQL($consulta, $i, 'nome');
				$dtCriacao=converteData(resultadoSQL($consulta, $i, 'data'), 'banco','formdata');
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$id>"._("Change")."</a>",'alterar');
				$opcoes.="&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>"._("Delete")."</a>",'excluir');
				$opcoes.="&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=grupos&registro=$id>"._("Groups")."</a>",'grupo');
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($nome, 'left', '50%', 'normal10');
					itemLinhaTabela($dtCriacao, 'center', '10%', 'normal10');
					itemLinhaTabela($opcoes, 'center', '40%', 'normal10');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem
	
	fechaTabela();
	
} # fecha fun��o de listagem



# Fu��o para visualiza��o de status
function verStatusCategorias()
{
	global $conn, $tb, $corFundo, $corBorda, $html;
	
	# Motrar tabela de busca
	novaTabela2("["._("Information about Categories")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('60%', 'left', $corFundo, 0, 'tabfundo1');
				echo "<br><img src=".$html[imagem][status]." border=0 align=left><b class=bold>"._("Status of Categories")."</b><br>
				<span class=normal10>"._(" Status and informations about categories.");
			htmlFechaColuna();
			htmlAbreColuna('10', 'left', $corFundo, 0, 'normal');
				echo "&nbsp;";
			htmlFechaColuna();
			
			
			htmlAbreColuna('40%', 'left', $corFundo, 0, 'normal');
				# Mostrar status
				$busca=buscaCategorias($texto, $campo, 'todos', 'id');
				if($busca) {
						 $numBusca=contaConsulta($busca);
				}
				else {
						 $numBusca=0;
				}
				
				htmlAbreTabelaSH('left', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				novaLinhaTabela($corFundo, '100%');
					itemLinhaNOURL(_('Number of records:'), 'right', $corFundo, $colunas, 'bold10');
					itemLinhaNOURL($numBusca."&nbsp;"._("registered categories"), 'left', $corFundo, $colunas, 'normal10');
				fechaLinhaTabela();
			htmlFechaColuna();
		fechaLinhaTabela();
	fechaTabela();
} #fecha status


# Funcao para cadastro
function incluirCategorias($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Form de inclusao
	if(!$matriz[bntAdicionar]) {
		# Motrar tabela de busca
		novaTabela2("["._("Add")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
			$texto="
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=$acao>&nbsp;";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						 echo "<b class=bold>"._("Name").": </b><br>
						 <span class=normal10>"._("Name of the category, used for identification")."</span>";
				htmlFechaColuna();
				$texto="<input type=text name=matriz[nome] size=60>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						 echo "<b class=bold>"._("Description").": </b><br>
						 <span class=normal10>"._("Detailed description about the category")."</span>";
				htmlFechaColuna();
				$texto="<textarea name=matriz[descricao] rows=4 cols=60></textarea>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						 echo "&nbsp;";
				htmlFechaColuna();
				$texto="<input type=submit name=matriz[bntAdicionar] value="._("Add")." class=submit>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
		fechaTabela();
		} #fecha form
		elseif($matriz[bntAdicionar]) {
		# Conferir campos
		if($matriz[nome] && $matriz[descricao]) {
			# Buscar por categoria
			if( contaConsulta(buscaCategorias($matriz[nome], 'nome', 'igual','nome'))>0 ){
				# Erro - campo inv�lido
				# Mensagem de aviso
				$msg=_("Category already registered!");
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				aviso(_("Warning: Incorrect Data"), $msg, $url, 760);
			}
			# continuar - campos OK
			else {
				# Cadastrar em banco de dados
				$grava=dbCategoria($matriz, 'incluir');
				
				# Verificar inclus�o de registro
				if($grava) {
					# acusar falta de parametros
					# Mensagem de aviso
					$msg=_("Data Recorded Success full!");
					$url="?modulo=$modulo&sub=$sub&acao=$acao";
					aviso(_("Warning"), $msg, $url, 760);
				}
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	}

} # fecha funcao de inclusao



# Fun��o para grava��o em banco de dados
function dbCategoria($matriz, $tipo)
{
	global $conn, $tb, $modulo, $sub, $acao;
	
	# Sql de inclus�o
	if($tipo=='incluir') {
	
		$data=dataSistema();
		
		$sql="INSERT INTO $tb[Categorias] VALUES (0,
			'$matriz[nome]',
			'$matriz[descricao]',
			'$data[dataBanco]')";
	} #fecha inclusao
	
	elseif($tipo=='excluir') {
		# Verificar se servidores existe
		$tmpBusca=buscaCategorias($matriz[id], 'id', 'igual', 'id');
		
		# Registro j� existe
		if(!$tmpBusca|| contaConsulta($tmpBusca)==0) {
			# Mensagem de aviso
			$msg=_("Record doesn't exist in the database");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: Error when changing record"), $msg, $url, 760);
		}
		else {
			$sql="DELETE FROM $tb[Categorias] WHERE id=$matriz[id]";
		}
	}
	
	# Alterar
	elseif($tipo=='alterar') {
		# Verificar se servidores existe
		$sql="UPDATE $tb[Categorias] SET texto='$matriz[texto]', nome='$matriz[nome]' WHERE id=$matriz[id]";
	}
	
	if($sql) {
		$retorno=consultaSQL($sql, $conn);
		return($retorno);
	}

} # fecha fun��o de grava��o em banco de dados



# Exclus�o de servicos
function excluirCategorias($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# ERRO - Registro n�o foi informado
	if(!$registro) {
			 # Mostrar Erro
			 $msg=_("Record not found!");
			 $url="?modulo=$modulo&sub=$sub&acao=$acao";
			 aviso(_("Warning"), $msg, $url, 760);
	}
	# Form de inclusao
	elseif($registro && !$matriz[bntExcluir]) {
		
		# Buscar Valores
		$consulta=buscaCategorias($registro, 'id', 'igual', 'id');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# Mostrar Erro
			$msg=_("Record not found!");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning"), $msg, $url, 760);
		}
		else {
			#atribuir valores
			$id=resultadoSQL($consulta, 0, 'id');
			$nome=resultadoSQL($consulta, 0, 'nome');
			$descricao=resultadoSQL($consulta, 0, 'texto');
			$dtCriacao=converteData(resultadoSQL($consulta, 0, 'data'), 'banco','form');
			
			# Motrar tabela de busca
			novaTabela2("["._("Delete")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=acao value=$acao>
					<input type=hidden name=registro value=$registro>
					<input type=hidden name=matriz[id] value=$registro>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Name:")."&nbsp;"."</b>";
					htmlFechaColuna();
					itemLinhaForm($nome, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Description:")."&nbsp;"."</b>";
					htmlFechaColuna();
					itemLinhaForm($descricao, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Date of Creation:")."</b>";
					htmlFechaColuna();
					itemLinhaForm($dtCriacao, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			
				# Bot�o de confirma��o
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntExcluir] value="._("Delete")." class=submit>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		} #fecha alteracao
	} #fecha form - !$bntExcluir
	
	# Altera��o - bntExcluir pressionado
	elseif($matriz[bntExcluir]) {
		# Cadastrar em banco de dados
		$grava=dbCategoria($matriz, 'excluir');
		
		# Verificar inclus�o de registro
		if($grava) {
				# Mensagem de aviso
				$msg=_("Record deleted Success Full! ");
				$url="?modulo=$modulo&sub=$sub";
				aviso(_("Warning"), $msg, $url, 760);
		}
		
	} #fecha bntExcluir

} #fecha exclusao



# Funcao para altera��o
function alterarCategorias($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# ERRO - Registro n�o foi informado
	if(!$registro) {
			 # ERRO
	}
	# Form de inclusao
	elseif($registro && !$matriz[bntAlterar]) {
		
		# Buscar Valores
		$consulta=buscaCategorias($registro, 'id', 'igual', 'id');
		if(!$consulta || contaConsulta($consulta)==0) {
				# Mostrar Erro
				$msg=_("Record not found!");
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				aviso(_("Warning"), $msg, $url, 760);
		}
		else {
			#atribuir valores
			$nome=resultadoSQL($consulta, 0, 'nome');
			$descricao=resultadoSQL($consulta, 0, 'texto');
			
			# Motrar tabela de busca
			novaTabela2("["._("Change")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="
						 <form method=post name=matriz action=index.php>
						 <input type=hidden name=modulo value=$modulo>
						 <input type=hidden name=sub value=$sub>
						 <input type=hidden name=registro value=$registro>
						 <input type=hidden name=matriz[id] value=$registro>
						 <input type=hidden name=acao value=$acao>&nbsp;";
						 itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
						 htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
									echo "<b class=bold>"._("Name:")."&nbsp;"."</b><br>
									<span class=normal10>"._("Name of the category, used for identification")."</span>";
						 htmlFechaColuna();
						 $texto="<input type=text name=matriz[nome] size=60 value='$nome'>";
						 itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
						 htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
									echo "<b class=bold>"._("Description:")."&nbsp;"."</b><br>
									<span class=normal10>"._("Detailed description about the category")."</span>";
						 htmlFechaColuna();
						 $texto="<textarea name=matriz[texto] rows=4 cols=60>$descricao</textarea>";
						 itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
						 htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
									echo "&nbsp;";
						 htmlFechaColuna();
						 $texto="<input type=submit name=matriz[bntAlterar] value="._("Change")." class=submit>";
						 itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		
		} #fecha alteracao
	} #fecha form - !$bntAlterar
	
	# Altera��o - bntAlterar pressionado
	elseif($matriz[bntAlterar]) {
		# Conferir campos
		if($matriz[texto] && $matriz[nome] ) {
			# continuar
			# Cadastrar em banco de dados
			$grava=dbCategoria($matriz, 'alterar');
			
			# Verificar inclus�o de registro
			if($grava) {
				# acusar falta de parametros
				# Mensagem de aviso
				$msg=_("Data Recorded Success full!");
				$url="?modulo=$modulo&sub=$sub";
				aviso(_("Warning"), $msg, $url, 760);
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	} #fecha bntAlterar

} # fecha funcao de altera��o



# Fun��o para procura de servi�o
function procurarCategorias($modulo, $sub, $acao, $registro, $matriz)
{
	global $conn, $tb, $corFundo, $corBorda, $html, $limite, $textoProcurar;
	
	# Atribuir valores a vari�vel de busca
	if(!$matriz) {
		$matriz[bntProcurar]=1;
		$matriz[txtProcurar]=$textoProcurar;
	} #fim da atribuicao de variaveis
	
	# Motrar tabela de busca
	novaTabela2("["._("Search")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('30%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b>"._("Search for:")."</b>";
			htmlFechaColuna();
			$texto="
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=procurar>
			<input type=text name=matriz[txtProcurar] size=40 value='$matriz[txtProcurar]'>
			<input type=submit name=matriz[bntProcurar] value="._("Search")." class=submit>";
			itemLinhaForm($texto, 'left','middle', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();
	
	# Caso bot�o procurar seja pressionado
	if( $matriz[bntProcurar] && $matriz[txtProcurar] ) {
		#buscar registros
		$consulta=buscaCategorias("upper(texto) like '%$matriz[txtProcurar]%' OR upper(nome) like '%$matriz[txtProcurar]%'",$campo, 'custom','nome');
		
		echo "<br>";
		
		novaTabela("["._("Results")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
		
		if(!$consulta || contaConsulta($consulta)==0 ) {
			# N�o h� registros
			itemTabelaNOURL(_('No record found'), 'left', $corFundo, 3, 'txtaviso');
		}
		elseif($consulta && contaConsulta($consulta)>0 && (!$registro || is_integer($registro)) ) {
			
			itemTabelaNOURL(_('Found records looking for')."&nbsp;".'('.$matriz[txtProcurar].'): '.contaConsulta($consulta)."&nbsp;"._('record(s)'), 'left', $corFundo, 3, 'txtaviso');
			
			# Paginador
			$urlADD="&textoProcurar=".$matriz[txtProcurar];
			paginador($consulta, contaConsulta($consulta), $limite[lista][categorias], $registro, 'normal', 3, $urlADD);
			
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela(_('Name'), 'center', '50%', 'tabfundo0');
				itemLinhaTabela(_('Date of Creation'), 'center', '10%', 'tabfundo0');
				itemLinhaTabela(_('Options'), 'center', '40%', 'tabfundo0');
			fechaLinhaTabela();
			
			# Setar registro inicial
			if(!$registro) {
					  $i=0;
			}
			elseif($registro && is_numeric($registro) ) {
					  $i=$registro;
			}
			else {
					  $i=0;
			}
			
			
			$limite=$i+$limite[lista][categorias];
			
			while($i < contaConsulta($consulta) && $i < $limite) {
				# Mostrar registro
				$id=resultadoSQL($consulta, $i, 'id');
				$nome=resultadoSQL($consulta, $i, 'nome');
				$data=resultadoSQL($consulta, $i, 'data');
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$id>"._("Change")."</a>",'alterar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>"._("Delete")."</a>",'excluir');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=grupos&registro=$id>"._("Groups")."</a>",'grupo');
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($nome, 'left', '50%', 'normal10');
					itemLinhaTabela(converteData($data, 'banco','formdata'), 'center', '10%', 'normal10');
					itemLinhaTabela($opcoes, 'center', '40%', 'normal10');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem
		fechaTabela();
	} # fecha bot�o procurar
} #fecha funcao de  procurar de servi�cos (Procurar



# Fun��o para visualizar as informa��es do servidor
function verCategoria($registro)
{
	global $conn, $corFundo, $corBorda, $tb, $html;
	
	# Mostar informa��es sobre Servidor
	$consulta=buscaCategorias($registro, 'id','igual','id');
	
	$idCategoria=resultadoSQL($consulta, 0, 'id');
	$nome=resultadoSQL($consulta, 0, 'nome');
	$descricao=resultadoSQL($consulta, 0, 'texto');
	$data=converteData(resultadoSQL($consulta, 0, 'data'),'banco','formdata');
	
	#nova tabela para mostrar informa��es
	novaTabela2(_('Information on Category'), 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
	//htmlAbreTabelaSH('center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		novaLinhaTabela($corFundo, '100%');
			itemLinhaTabela('<b>'._('Name:').'</b>', 'right', '30%', 'tabfundo1');
			itemLinhaNOURL($nome, 'left', $corFundo, 0, 'normal10');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			itemLinhaTabela('<b>'._('Description:').'</b>', 'right', '30%', 'tabfundo1');
			itemLinhaNOURL($descricao, 'left', $corFundo, 0, 'normal10');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			itemLinhaTabela('<b>'._('Date of Creation:').'</b>', 'right', '30%', 'tabfundo1');
			itemLinhaNOURL($data, 'left', $corFundo, 0, 'normal10');
		fechaLinhaTabela();
	fechaTabela();
	# fim da tabela
	
	echo "<br>";

} #fecha visualizacao



# Fun��o para montar campo de formulario
function formCategorias($categoria, $campo)
{
	global $conn, $tb, $sessLogin;
	
	$idUsuario=buscaIDUsuario($sessLogin[login],'login','igual','id');
	
	# Buscar Servi�os de servidor (ja cadastrados)
	$sql="
		SELECT 
			* 
		FROM 
			categorias, 
			grupos, 
			usuarios, 
			categorias_grupos, 
			usuarios_grupos 
		WHERE 
			categorias.id=categorias_grupos.idCategoria 
			AND grupos.id=categorias_grupos.idGrupo 
			AND usuarios.id=usuarios_grupos.idUsuario 
			AND usuarios_grupos.idGrupo=grupos.id 
			AND usuarios.id=$idUsuario
		GROUP BY
			categorias.id
		ORDER BY
			categorias.nome ASC";
			
	$consulta=consultaSQL($sql, $conn);
	
	$item="<select name=matriz[$campo]>\n";
	
	# Listargem
	for($i=0;$i<contaConsulta($consulta);$i++) {
		# Valores dos campos
		$nome=resultadoSQL($consulta, $i, 'nome');
		$id=resultadoSQL($consulta, $i, 'id');
		
		$opcSelect='';
		if($id == $categoria) $opcSelect='selected';
		
		$item.="<option value=$id $opcSelect>$nome\n";
	}
	
	$item.="</select>";
	
	return($item);

} #fecha funcao de montagem de campo de form



# Fun��o para checagem de status
function checaCategoria($categoria) {
	global $conn;
	
	$consulta=buscaCategorias($categoria, 'id','igual','id');
	
	if($consulta) {
		$retorno[nome]=resultadoSQL($consulta, 0, 'nome');
		$retorno[texto]=resultadoSQL($consulta, 0, 'texto');
	}
	
	return($retorno);
}


# Fun��o para atualiza��o de Prioridade de Ticket
function atualizaCategoriaTicket($ticket, $categoria) {
	global $conn, $tb, $modulo, $sub, $acao;
	
	$sql="UPDATE $tb[Ticket] SET idCategoria=$categoria WHERE id=$ticket";
	$consulta=consultaSQL($sql, $conn);
	
	if(!$consulta) {
		# Erro
		$msg=_("Error when updating Category of Ticket!");
		$url="?modulo=$modulo&sub=$sub&acao=ver&registro=$ticket";
		aviso(_("Error"), $msg, $url, 760);
	}
}

?>
