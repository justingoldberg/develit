<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 14/10/2002
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 002
#
# Fun��o:
#    Fun��es de conex�o com banco de dados


# Conecta ao MySQL
function conectaMySQL($host, $usuario, $senha)
{
	# Conectar a banco de dados MySQL
	return(mysql_connect($host, $usuario, $senha));
	
} // fecha fun��o conectaMysQL


# Seleciona banco de dados
function selecionaDB($banco)
{
	# Selecionar banco de dados
	return(mysql_select_db($banco));
	
} // fecha fun��o selecionaDB


# Executa query
function consultaSQL($sql, $conn)
{
	$retorno=mysql_query($sql, $conn);

	if( !$retorno ){
		# Erro - Consulta nao retorna valor
		aviso(_("Consultation"),_("Error when accomplishing consultation in Database").". <br>"._("Verify configurations")."!", "?modulo=",300);
		echo mysql_error()."<br>$sql";
		//@mysql_query($sql."\n\nerro aquiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii ". mysql_error(), $conn);
	}
	
	# retornar consulta
	return($retorno);
	
} #fecha fun��o para executar query no MySQL

# Executa query
function consultaSQLHide($sql, $conn)
{
	$retorno=mysql_query($sql, $conn);
	
	# retornar consulta
	return($retorno);
	
} #fecha fun��o para executar query no MySQL


# Fun��o para contar linhas retornadas pela matriz de consulta SQL
function contaConsulta($consulta)
{
	# Contar linhas da consulta
	return(mysql_num_rows($consulta));
	
} # fecha fun��o para contagem da consultaSQL


# Mostrar resultado da consulta
function resultadoSQL($consulta, $linha, $coluna)
{
	# retornar valor da coluna
	$ret = ( @mysql_result($consulta, $linha, $coluna) );
//	if( $ret===false ){
//		var_dump($ret);
//		echo "debug resultadoSQL(): $coluna<br>";
//		@mysql_query("aqui----------------------");
//	}
	return $ret;
	
} # fecha fun��o para retorno de valor da coluna



/**
 * @return resultset
 * @param id     $texto
 * @param string $campo
 * @param string $tipo
 * @param string $ordem
 * @param string $tabela
 * @desc Busca registros na tabela
 texto=conteudo do campo ser pesquisado ou a propria condicao no caso de custom
 campo=Coluna do banco a ser pesquisada
 tipo=default todos, contem, igual ou custom
 tabela=nome da tabela a ser pesquisada
*/
function buscaRegistro($texto, $campo='', $tipo="", $ordem="", $tabela)
{
	global $conn, $tb, $corFundo, $modulo;
	#condicao padrao
	$sql="SELECT * FROM $tabela ";
	
	if($tipo=='contem' && $campo) {
		$sql.="WHERE $campo LIKE '%$texto%' ";
	}
	elseif($tipo=='igual' && $campo) {
		$sql.="WHERE $campo='$texto' ";
	}
	elseif($tipo=='custom' && $texto) {
		$sql.="WHERE $texto ";
		
	}
	
	if ($ordem) $sql.="ORDER BY $ordem";
	# Verifica consulta
	if($sql){
		#echo "<br>Consulta: $sql<br>";
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	
} # fecha fun��o de busca

function getLastId(){
	return mysql_insert_id();
}

/**
 * Returns query result in an array of objects.
 *
 * @param string $sql
 * @param resource $conn
 * @return array/object
 */
function runQuery( $sql, $conn=false ){
	if( !$conn ){
		global $conn;
	}
	$result = mysql_query( $sql, $conn );
	$return = array();
	if( $result ){
		if( mysql_num_rows( $result ) > 0 ){
			while( $line = mysql_fetch_object( $result ) ){
				$return[] = $line;
			}
		}
	}
	else {
		aviso(_("Consultation"),_("Error when accomplishing consultation in Database").". <br>"._("Verify configurations")."!", "?modulo=",300);
	}
	return $return;
}

?>
