<?php
################################################################################
# Fun��o:
#    Configura��es utilizadas pela aplica��o - Integra��o com Servidor de Mail


# Enviar e-mail de notifica��o de Ticket
/**
 * It sends e-mails notifications to Users, and Company Users.
 *
 * @param integer $idTicket
 * @param integer $idUsuario
 * @param stirng  $acao
 * @param string  $textoAcao
 * @return void
 */
function mailTicket( $idTicket, $idUsuario, $acao, $textoAcao="" ) {

	global $conn, $tb, $configAppName, $configAppVersion, $configAppHost, $sessLogin;

	/*
	Procedimentos:
	1 - Carrega os dados iniciais.
	2- verifica o tipo de usu�rio:
	   2.1 - se for usu�rio do ticket, recolhe o login dele e armazena uma condi��o para filtragem.
	   2.2 - sen�o armazena apenas o login do usu�rio empresa.
	3- se no ticket tiver definida alguma caterogia, recolhe o nome desta
	4- se no ticket tiver definida alguma prioridade,  recolhe a descri��o dela
	5- cria a mensagem de acordo com a $acao.
	6- busca os usu�rios padr�es dos tickets e recolhe seus e-mails.
	7- busca os usu�rios de usu�rios e recolhe seus e-mails.
	8- envia o e-mail para os usu�rios.
	*/

	# 1
	$data = dataSistema();
	$sqlPerfil = "";
	$isCompanyUser = isCompanyUser();
	$url = "http://$configAppHost/index.php?modulo=ticket&acao=ver&registro=$idTicket";

	# Checar dados do ticket
	$dadosTicket = buscaTicket( $idTicket, 'id','igual','id' );
	if( contaConsulta( $dadosTicket ) ) {
		$assunto 		 = resultadoSQL( $dadosTicket, 0, 'assunto' );
		$numProtocolo    = resultadoSQL( $dadosTicket, 0, 'protocolo' );
		$dataCriacao 	 = converteData( resultadoSQL( $dadosTicket, 0, 'data' ), 'banco', 'form' );
		$texto 			 = resultadoSQL( $dadosTicket, 0, 'texto' );
		$idUsuarioTicket = resultadoSQL( $dadosTicket, 0, 'idUsuario' );
		$idCategoria 	 = resultadoSQL( $dadosTicket, 0, 'idCategoria' );
		$idPrioridade 	 = resultadoSQL( $dadosTicket, 0, 'idPrioridade' );
	}
	# 2
	if( !$isCompanyUser ){
		# Busca perfil do usuario para identificar o grupo padr�o
		$dadosPerfil = buscaPerfil( $idUsuarioTicket, 'id', 'igual', 'id' );
		if( $dadosPerfil && contaConsulta( $dadosPerfil ) > 0 ) {
			$idGrupoPadrao = resultadoSQL( $dadosPerfil, 0, 'idGrupo' );

			if( is_numeric( $idGrupoPadrao ) && $idGrupoPadrao > 0 ) {
				# Sql adicional de idGrupo padrao do perfil do usuario
				# para restringir o aviso de ticket novo apenas para o grupo
				# selecionado como padr�o pelo usuairo
				$sqlPerfil = " AND $tb[Grupos].id=$idGrupoPadrao ";
			}
		}

	}
	$i = 0;
	$usuario = getUsername($idUsuario, $idTicket);

	# 3
	if( $idCategoria ) {
		$consultaCategoria = buscaCategorias( $idCategoria, 'id','igual','id' );
		if( $consultaCategoria && contaConsulta( $consultaCategoria ) > 0 ) {
			$nomeCategoria = resultadoSQL( $consultaCategoria, 0, 'nome' );
		}
	}

	# 4
	if( $idPrioridade ) {
		$consultaPrioridade = buscaPrioridades( $idPrioridade, 'id','igual','id' );
		if( $consultaPrioridade && contaConsulta( $consultaPrioridade ) > 0 ) {
			$nomePrioridade = resultadoSQL( $consultaPrioridade, 0, 'nome' );
		}
	}

	# 5
	if( $acao == 'incluir' ) {
		# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
		# ticket
		$msg="\n$configAppName - $configAppVersion\n\n".
		_("ALERT: Ticket was created")."\n".
		_("Protocol:")." $numProtocolo\n".
		_("URL:")." $url\n".
		_("Subject:")." $assunto\n".
		_("Created by:")." $usuario\n"._("Date:").
		" $dataCriacao\n\n".
		"--------------------------------------------------------------------------------\n".
		_("Text:")."\n$texto\n".
		"--------------------------------------------------------------------------------";

		$acaoTicket = _("New Ticket");

	}
	else {
		# Dados do processo do Ticket

		if( $acao == 'abrir' ){
			# Informa��es sobre ultimo processo do ticket;
			$dadosProcessoTicket = ultimoProcessoTicket( $idTicket );

			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$msg = "\n$configAppName - $configAppVersion\n\n".
			_("WARNING: Ticket was opened!")."\n\n".
			_("For making reference to this attendance,")." "._("please, enter in contact using")."\n".
			_("the following protocol number:")." $numProtocolo\n\n".
			_("Protocol:")." $numProtocolo\n".
			_("URL:")." $url\n".
			_("Subject:")." $assunto\n".
			_("Created by:")." $usuario\n".
			_("Created in:")." $dataCriacao\n".
			"--------------------------------------------------------------------------------\n".
			_("Text:")."$texto\n".
			"--------------------------------------------------------------------------------\n\n".
			_("Opening Date:")." $dadosProcessoTicket[data]\n".
			_("Priority:")." $nomePrioridade\n".
			_("Category:")." $nomeCategoria\n".
			_("Current status:")." $dadosProcessoTicket[status]\n".
			_("Modified by:")." $dadosProcessoTicket[login]\n\n".
			_("Opening comment:\n").
			"--------------------------------------------------------------------------------\n".
			"$dadosProcessoTicket[texto]\n".
			"--------------------------------------------------------------------------------\n";

			$acaoTicket = _("Opened Ticket");
		}
		elseif( $acao == 'reabrir' ) {
			# Informa��es sobre ultimo processo do ticket;
			$dadosProcessoTicket = ultimoProcessoTicket( $idTicket );

			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$msg = "\n$configAppName - $configAppVersion\n\n".
			_("WARNING: Ticket was reopened!")."\n\n".
			_("For making reference to this attendance,")." "._("please, enter in contact using")."\n".
			_("the following protocol number:")." $numProtocolo\n\n".
			_("Protocol:")." $numProtocolo\n".
			_("URL:")." $url\n".
			_("Subject:")." $assunto\n".
			_("Created by:")." $usuario\n".
			_("Created in:")." $dataCriacao\n".
			"--------------------------------------------------------------------------------\n".
			_("Text:")."\n$texto\n".
			"--------------------------------------------------------------------------------\n\n".
			_("Reopening Date:")." $dadosProcessoTicket[data]\n".
			_("Priority:")." $nomePrioridadezn".
			_("Category:")." $nomeCategoria\n".
			_("Current status:")." $dadosProcessoTicket[status]\n".
			_("Modified by:")." $dadosProcessoTicket[login]\n\n".
			_("Reopening comment:")."\n".
			"--------------------------------------------------------------------------------\n".
			$dadosProcessoTicket[texto]."\n".
			"--------------------------------------------------------------------------------\n";

			$acaoTicket = _("Reopened Ticket");
		}
		elseif( $acao == 'fechar' ) {
			# Informa��es sobre ultimo processo do ticket;
			$dadosProcessoTicket = ultimoProcessoTicket( $idTicket );

			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$msg = "\n$configAppName - $configAppVersion\n\n".
			_("WARNING: Ticket was closed!")."\n\n".
			_("For making reference to this attendance,")." "._("please, enter in contact using")."\n".
			_("the following protocol number:")." $numProtocolo\n\n".
			_("Protocol:")." $numProtocolo\n".
			_("URL:")." $url\n".
			_("Subject:")." $assunto\n".
			_("Created by:")." $usuario\n".
			_("Created in:")." $dataCriacao\n".
			"--------------------------------------------------------------------------------\n".
			_("Text:")."\n$texto\n".
			"--------------------------------------------------------------------------------\n\n".
			_("Date of Closing:")." $dadosProcessoTicket[data]\n".
			_("Priority:")." $nomePrioridade\n".
			_("Category:")." $nomeCategoria\n".
			_("Current status:")." $dadosProcessoTicket[status]\n".
			_("Modified by:")." $dadosProcessoTicket[login]\n\n\n".
			_("Closing comment:")."\n".
			"--------------------------------------------------------------------------------\n".
			$dadosProcessoTicket['texto']."\n".
			"--------------------------------------------------------------------------------\n";
			$acaoTicket = _("Closed Ticket");
		}
		elseif( $acao == 'alterar' ){
			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$msg = "\n$configAppName - $configAppVersion\n\n".
			_("WARNING: Ticket was Modified!")."\n\n".
			_("For making reference to this attendance,")." "._("please, enter in contact using")."\n".
			_("the following protocol number:")." $numProtocolo\n\n".
			_("Protocol:")." $numProtocolo\n".
			_("URL:")." $url\n".
			_("Subject:")." $assunto\n".
			_("Created by:")." $usuario\n".
			_("Created in:")." $dataCriacao\n".
			_("Modification Date:")." $data[dataNormal]\n".
			_("Priority:")." $nomePrioridade\n".
			_("Category:")." $nomeCategoria\n\n".
			"--------------------------------------------------------------------------------\n".
			_("Text:")."\n $texto\n".
			"--------------------------------------------------------------------------------\n";

			$acaoTicket = _("Altered Ticket");
		}
		elseif( $acao == 'prioridade' ) {
			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$msg = "\n$configAppName - $configAppVersion\n\n".
			_("WARNING: Ticket priority was modified!")."\n\n".
			_("For making reference to this attendance,")." "._("please, enter in contact using")."\n".
			_("the following protocol number:")." $numProtocolo\n\n".
			_("Protocol:")." $numProtocolo\n".
			_("URL:")." $url\n".
			_("Subject:")." $assunto\n".
			_("Created by:")." $usuario\n".
			_("Created in:")." $dataCriacao\n".
			_("Modification Date:")." $data[dataNormal]\n".
			_("Priority:")." $nomePrioridade\n".
			_("Category:")." $nomeCategoria\n\n".
			"--------------------------------------------------------------------------------\n".
			_("Text:")."\n$texto\n".
			"--------------------------------------------------------------------------------\n";

			$acaoTicket = _("Altered Priority");
		}
		elseif( $acao == 'comentario' ) {
			# Buscar ultimo coment�rio do Ticket
			$dadosUltimoComentario = buscaUltimoComentarioTicket( $idTicket );

			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$msg = "\n$configAppName - $configAppVersion\n\n".
			_("WARNING: Commentary was added to the Ticket!")."\n\n".
			_("For making reference to this attendance,")." "._("please, enter in contact using")."\n".
			_("the following protocol number:")." $numProtocolo\n\n".
			_("Protocol:")." $numProtocolo\n".
			_("URL:")." $url\n".
			_("Subject:")." $assunto\n".
			_("Created by:")." $usuario\n".
			_("Created in:")." $dataCriacao\n".
			_("Post Date:")." $data[dataNormal]\n".
			_("Priority:")." $nomePrioridade\n".
			_("Category:")." $nomeCategoria\n\n".
			_("Commented by:")." $dadosUltimoComentario[login]\n\n".
			"--------------------------------------------------------------------------------\n".
			_("Text:")."\n$dadosUltimoComentario[texto]\n".
			"--------------------------------------------------------------------------------\n";



			$acaoTicket = _("Commented Ticket");
		}

		elseif( $acao == 'transferir' ) {
			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$msg = "\n$configAppName - $configAppVersion\n\n".
			_("WARNING: Ticket was transferred!")."\n\n".
			_("For making reference to this attendance,")." "._("please, enter in contact using")."\n".
			_("the following protocol number:")." $numProtocolo\n\n".
			_("Protocol:")." $numProtocolo\n".
			_("URL:")." $url\n".
			_("Subject:")." $assunto\n".
			_("Date of Creation:")." $dataCriacao\n".
			_("Transferred by:")." $sessLogin[login]\n".
			_("Transferred to:")." $usuario\n".
			_("Transferred in:")." $data[dataNormal]\n".
			_("Priority:")." $nomePrioridade\n".
			_("Category:")." $nomeCategoria\n\n".
			_("Commented by:")." $sessLogin[login]\n".
			"--------------------------------------------------------------------------------\n".
			_("Text:")."\n$textoAcao\n".
			"--------------------------------------------------------------------------------\n";

			$acaoTicket = _("Transferred Ticket");
		}
		elseif( $acao == 'verfeedback' ) {
			# Buscar ultimo coment�rio do Ticket
			$dadosUltimoFeedback = buscaUltimoFeedbackTicket( $idTicket );

			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$msg = "\n$configAppName - $configAppVersion\n\n".
			_("WARNING: Evaluation was made to the Ticket!")."\n\n".
			_("To view this attendance,")." "._("please, enter in contact using")."\n".
			_("the following protocol number:")." $numProtocolo\n\n".
			_("Protocol:")." $numProtocolo\n".
			_("URL:")." $url\n".
			_("Subject:")." $assunto\n".
			_("Created by:")." $usuario\n".
			_("Created in:")." $dataCriacao\n".
			_("Post Date:")." $data[dataNormal]\n".
			_("Priority:")." $nomePrioridade\n".
			_("Category:")." $nomeCategoria\n\n".
			_("Evaluated by:")." $dadosUltimoFeedback[login]\n".
			"--------------------------------------------------------------------------------\n".
			_("Grade:")." $dadosUltimoFeedback[nota]\n".
			_("Commentary:")."\n$dadosUltimoFeedback[comentario]\n".
			"--------------------------------------------------------------------------------\n";

			$acaoTicket = _("Evaluated Ticket");
		}

	}
//	$dadosMsg = getMessageUsers( $acao );
//	$msg = $dadosMsg['message'];
//	$acaoTicket = $dadosMsg['subject'];

	# 6
	if( $acao == 'incluir' || !$idCategoria ) {
		# listar Grupos do Usu�rio
		$consultaGrupos = buscaUsuariosGrupos( $idUsuario, 'idUsuario', 'igual', 'idUsuario' );
		$totalUsuariosGrupos = contaConsulta( $consultaGrupos );
		$sqlGrupos = "";
		if( $totalUsuariosGrupos ){
			$grupos = array();
			for( $a = 0 ; $a < $totalUsuariosGrupos; $a++) {
				$grupos[] = resultadoSQL($consultaGrupos, $a, 'idGrupo');
			}
			$sqlGrupos = " AND $tb[Grupos].id IN (" . implode( ', ', $grupos ) . ") ";
		}
		# Lista de usuarios - pertencentes ao grupo do usuario
		$sql =	"SELECT ".
					"$tb[Perfil].email, ".
					"$tb[Perfil].titulo_email, ".
					"$tb[Grupos].nome ".
				"FROM $tb[Grupos] ".
					" INNER JOIN $tb[UsuariosGrupos] ON ($tb[Grupos].id=$tb[UsuariosGrupos].idGrupo)".
					" INNER JOIN $tb[Usuarios] ON ($tb[Usuarios].id=$tb[UsuariosGrupos].idUsuario)".
					" INNER JOIN $tb[Perfil] ON ($tb[Usuarios].id=$tb[Perfil].id) ".
				"WHERE ".
					"$tb[Usuarios].status='A' AND ".
					"$tb[Perfil].notificar_email='S' ".
					$sqlGrupos .
					$sqlPerfil .
				"GROUP BY $tb[Usuarios].id";
	}
	else {
		/*
		Busca os e-mails dos usu�rios que est�o no grupo relacionado a categoria em que foi relacionado o ticket de $idTicket
		*/
		# Verificar Grupos do Usuario
		# Lista de usuarios
		#query ordenada
		$sql =	"SELECT ".
					"$tb[Perfil].email, ".
					"$tb[Perfil].titulo_email ".
				"FROM $tb[Ticket] ".
					" INNER JOIN $tb[CategoriasGrupos] ON ($tb[Ticket].idCategoria = $tb[CategoriasGrupos].idCategoria)".
					" INNER JOIN $tb[UsuariosGrupos] ON ($tb[CategoriasGrupos].idGrupo = $tb[UsuariosGrupos].idGrupo)".
					" INNER JOIN $tb[Usuarios] ON ($tb[Usuarios].id=$tb[UsuariosGrupos].idUsuario)".
					" INNER JOIN $tb[Perfil] ON ($tb[Usuarios].id=$tb[Perfil].id) ".
				"WHERE ".
					"$tb[Ticket].id='$idTicket' AND ".
					"$tb[Usuarios].status='A' ".
					"AND $tb[Perfil].notificar_email = 'S' ".
				"GROUP BY $tb[Usuarios].id";
	}

	$emails = array();
	$titulos = array();

	$consulta = consultaSQL( $sql, $conn );
	$contaConsulta = contaConsulta( $consulta );
	if( $consulta && $contaConsulta > 0 ) {
		for( $i = 0 ; $i < $contaConsulta; $i++ ) {
			$emails[] = resultadoSQL( $consulta, $i, 'email' );
			$titulo = resultadoSQL( $consulta, $i, 'titulo_email' );
			$titulos[] = ( !$titulo ? "Ticket-IT:" :  $titulo ).' '.$acaoTicket;
		}
	}

	# 7
	// buscar usu�rios da empresa
//	$sql =	"SELECT ".
//				"$tb[EmpresasUsuarios].email ".
//			"FROM $tb[Ticket]".
//				" INNER JOIN $tb[TicketEmpresa] ON ($tb[Ticket].id=$tb[TicketEmpresa].idTicket)".
//				" INNER JOIN $tb[Empresas] ON ($tb[TicketEmpresa].idEmpresa=$tb[Empresas].id)".
//				" INNER JOIN $tb[UsuariosEmpresas] ON ($tb[Empresas].id=$tb[UsuariosEmpresas].idEmpresa)".
//				" INNER JOIN $tb[EmpresasUsuarios] ON ($tb[UsuariosEmpresas].idEmpresaUsuario=$tb[EmpresasUsuarios].id) ".
//			"WHERE ".
//				"$tb[Ticket].id='$idTicket' ".
//			"GROUP BY $tb[EmpresasUsuarios].id";
//
//	$consulta = consultaSQL( $sql, $conn );
//	$contaConsulta = contaConsulta( $consulta );
//	if( $contaConsulta ){
//		for( $i = 0 ; $i < $contaConsulta; $i++ ) {
//			$emails[] = resultadoSQL( $consulta, $i, 'email' );
//			$titulos[] = 'Ticket-IT: '.$acaoTicket;
//		}
//	}

	$consulta = getCompanyUsersByTicket( $idTicket );
	if( count( $consulta ) ){
		foreach( $consulta as $linha ) {
			$emails[] = $linha->email;
			$titulos[] = 'Ticket-IT: '.$acaoTicket;
		}
	}


	// envia e-mail para os usu�rios
	# 8
	$qtdDestinatarios = count( $emails );
	for( $i=0; $i < $qtdDestinatarios; $i++ ){
		mailEnviar( 'naoresponda@devel-it.com.br', $emails[$i], $titulos[$i], $msg );
	}

}


# funcao para envio de email
/**
 * Sends a e-mail message. Return 1 if it was sent rightly or 0 it wasn't sent.
 *
 * @param string $origem => the senter e-mail address
 * @param string $destino => the destiny e-mail addres
 * @param string $assunto => the message subject
 * @param string $texto => the message e-mail
 * @return unknown
 */
function mailEnviar( $origem, $destino, $assunto, $texto ) {

	global $configMail;

	$headerADD = "From: $origem\nReply-To: $origem\nX-Mailer: PHP-Mail (by Devel-IT)";
	// by nash 2007-04-17 - debug - uncomment these lines to know if the system is sending the mail messages rightly
	// start debug
//	$conteudo = "Destary: $destino - $assunto\n\n\$texto\n******************************************\n";
//	$fp = fopen("/tmp/mail_ticket", "a");
//	fwrite($fp, $conteudo);
//	fclose($fp);
//	return 1;
	// ends debug

	return ( mail( $destino, $assunto, $texto, $headerADD ) ? 1 : 0 );
} # fecha fun��o de envio de mail

/**
 * It sends e-mails notifications the following situations:
 * - to send notifications to a guest, in any condition
 * - when a guest user create a ticket or send a comment, it is send to users and guests
 * - to send a invitation to a company user that has created the ticket to evaluate the attendence
 *
 * @param array   $matriz
 * @param integer $idUsuario
 * @param string  $acao
 * @return unknown
 */
function mailTicketProtocolo($matriz, $idUsuario, $acao) {

	global $conn, $tb, $configAppName, $configAppVersion, $configAppHost;
	$data=dataSistema();
	$idTicket=$matriz[idTicket];
	$categoria=$matriz[categoria];

	# Checar dados do ticket
	$dadosTicket=buscaTicket($matriz[idTicket], 'id','igual','id');

	$assunto = resultadoSQL($dadosTicket, 0, 'assunto');
	$numProtocolo = resultadoSQL($dadosTicket, 0, 'protocolo');
	$dataCriacao = converteData(resultadoSQL($dadosTicket, 0, 'data'),'banco','form');
	$texto = resultadoSQL($dadosTicket, 0, 'texto');
	$idUsuarioTicket = resultadoSQL($dadosTicket, 0, 'idUsuario');
	$idCategoria = resultadoSQL($dadosTicket, 0, 'idCategoria');

	# Pegar o nome do grupo de acordo com o perfil
	$nomeGrupo = comentarNomeGrupo( resultadoSQL( $dadosTicket, 0, 'idUsuario' ), $aceita='sim' );

	# Busca perfil do usuario para identificar o grupo padr�o
	$dadosPerfil=buscaPerfil($idUsuarioTicket, 'id', 'igual','id');

	if( $dadosPerfil && contaConsulta($dadosPerfil) > 0 ) {
		$idGrupoPadrao = resultadoSQL($dadosPerfil, 0, 'idGrupo');

		if( is_numeric($idGrupoPadrao) && $idGrupoPadrao>0 ) {
			# Sql adicional de idGrupo padrao do perfil do usuario
			# para restringir o aviso de ticket novo apenas para o grupo
			# selecionado como padr�o pelo usuairo
			$sqlPerfil=" AND $tb[Grupos].id=$idGrupoPadrao ";
		}
	}

	if( $idCategoria ) {
		$consultaCategoria=buscaCategorias( $idCategoria, 'id','igual','id' );
		if( $consultaCategoria && contaConsulta($consultaCategoria)>0 ) {
			$nomeCategoria=resultadoSQL($consultaCategoria, 0, 'nome');
		}
	}

	$idPrioridade=resultadoSQL($dadosTicket, 0, 'idPrioridade');
	if( $idPrioridade ) {
		$consultaPrioridade = buscaPrioridades($idPrioridade, 'id','igual','id');
		if( $consultaPrioridade && contaConsulta($consultaPrioridade) > 0 ){
			$nomePrioridade = resultadoSQL( $consultaPrioridade, 0, 'nome' );
		}
	}
	// by nash - 2007-04-12 - quando postava qualquer coisa com o usu�rio empresa aparecia como visitante
//	if( $sessLogin['isCompanyUser'] ){
//		$usuario = $sessLogin['login'];
//	}
//	else {
//		$usuario = buscaLoginUsuario( $idUsuario, 'id', 'igual', 'id' );
//	}
	$usuario = getUsername($idUsuario, $idTicket);
	$url="http://$configAppHost/index.php?modulo=ticket&acao=ver&registro=$idTicket";


	if( $acao=='incluir' ) {
		# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
		# ticket
		$msg="\n$configAppName - $configAppVersion\n\n".
		_("Protocol:")." $numProtocolo\n\n".
		_("URL:")." $url\n".
		_("Subject:")." $assunto\n".
		_("Created by:")." $usuario\n".
		_("Date:")." $dataCriacao\n\n".
		"--------------------------------------------------------------------------------\n".
		_("Text:")."\n$texto\n".
		"--------------------------------------------------------------------------------\n";

$url="http://$configAppHost/index.php?modulo=protocolo&acao=ver&registro=$matriz[protocolo]";
$msgOrigem="
$configAppName - $configAppVersion

"._("ALERT: Ticket was created")."

"._("For making reference to this attendance,")." "._("please, enter in contact using")."
"._("the following protocol number:")." $numProtocolo

"._("Protocol:")." $numProtocolo
"._("URL:")." $url
"._("Subject:")." $assunto
"._("Created by:")." $usuario
"._("Date:")." $dataCriacao

--------------------------------------------------------------------------------
"._("Text:")."
$texto
--------------------------------------------------------------------------------";

		$acaoTicket=_("New Ticket");

	}
	else {
		# Dados do processo do Ticket
		if($acao=='comentario' || $acao=='comentar_origem') {
			# Buscar ultimo coment�rio do Ticket
			$dadosUltimoComentario=buscaUltimoComentarioTicket($idTicket);

			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$msg="
$configAppName - $configAppVersion

"._("WARNING: Commentary was added to the Ticket!")."

"._("Protocol:")." $numProtocolo
"._("URL:")." $url
"._("Subject:")." $assunto
"._("Created by:")." $usuario
"._("Created in:")." $dataCriacao
"._("Post Date:")." $data[dataNormal]
"._("Priority:")." $nomePrioridade
"._("Category:")." $nomeCategoria

"._("Commented by:")." $dadosUltimoComentario[login]
--------------------------------------------------------------------------------
"._("Text:")."
$dadosUltimoComentario[texto]
--------------------------------------------------------------------------------";

$url="http://$configAppHost/index.php?modulo=protocolo&acao=ver&registro=$matriz[protocolo]";
$msgOrigem="
$configAppName - $configAppVersion

"._("WARNING: Commentary was added to the Ticket!")."

"._("For making reference to this attendance,")." "._("please, enter in contact using")."
"._("the following protocol number:")." $numProtocolo

"._("Protocol:")." $numProtocolo
"._("URL:")." $url
"._("Subject:")." $assunto
"._("Created by:")." $usuario
"._("Created in:")." $dataCriacao
"._("Post Date:")." $data[dataNormal]
"._("Priority:")." $nomePrioridade
"._("Category:")." $nomeCategoria

"._("Commented by:")." $dadosUltimoComentario[login]
--------------------------------------------------------------------------------
"._("Text:")."
$dadosUltimoComentario[texto]
--------------------------------------------------------------------------------";

			$acaoTicket=_("Commented Ticket");
		}

		elseif($acao=='abrir_origem') {
			# Informa��es sobre ultimo processo do ticket;
			$dadosProcessoTicket=ultimoProcessoTicket($idTicket);

			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$url="http://$configAppHost/index.php?modulo=protocolo&acao=ver&registro=$matriz[protocolo]";
			$msgOrigem="
$configAppName - $configAppVersion

"._("WARNING: Ticket was opened!")."

"._("For making reference to this attendance,")." "._("please, enter in contact using")."
"._("the following protocol number:")." $numProtocolo

"._("Protocol:")." $numProtocolo
"._("URL:")." $url
"._("Subject:")." $assunto
"._("Created by:")." $usuario
"._("Created in:")." $dataCriacao
--------------------------------------------------------------------------------
"._("Text:")."
$texto
--------------------------------------------------------------------------------

"._("Opening Date:")." $dadosProcessoTicket[data]
"._("Priority:")." $nomePrioridade
"._("Category:")." $nomeCategoria
"._("Current status:")." $dadosProcessoTicket[status]
"._("Modified by:")." $dadosProcessoTicket[login]

"._("Opening comment:")."
--------------------------------------------------------------------------------
$dadosProcessoTicket[texto]
--------------------------------------------------------------------------------
";
			$acaoTicket=_("Opened Ticket");
		}
		elseif($acao=='encaminhar') {
			# Informa��es sobre ultimo processo do ticket;
			$dadosProcessoTicket=ultimoProcessoTicket($idTicket);

			# Pegar o nome do grupo de acordo com o perfil
			$nomeGrupoProcesso = comentarNomeGrupo( $dadosProcessoTicket['idUsuario'], $aceita='sim' );

			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$url="http://$configAppHost/index.php?modulo=protocolo&acao=ver&registro=$matriz[protocolo]&lang=$lang";
			$msgOrigem="
$configAppName - $configAppVersion

"._("WARNING: Forward Ticket!")."

"._("To:")." $matriz[nome]

"._("WARNING: For making reference to this attendance,")." "._("please, enter in contact using")."
"._("the following protocol number:")." $numProtocolo

"._("Protocol:")." $numProtocolo
"._("URL:")." $url
"._("Subject:")." $assunto
"._("Created by:")." ".( empty( $nomeGrupo ) ? $usuario : $nomeGrupo )."
"._("Created in:")." $dataCriacao
--------------------------------------------------------------------------------
"._("Text:")."
$texto
--------------------------------------------------------------------------------

"._("Opening Date:")." $dadosProcessoTicket[data]
"._("Priority:")." $nomePrioridade
"._("Category:")." $nomeCategoria
"._("Current status:")." $dadosProcessoTicket[status]
"._("Modified by:")." ".( empty( $nomeGrupoProcesso ) ? $dadosProcessoTicket[login] : $nomeGrupoProcesso )."

"._("Opening comment:")."
--------------------------------------------------------------------------------
$dadosProcessoTicket[texto]
--------------------------------------------------------------------------------
";

			$acaoTicket=_("Opened Ticket");
		}
		elseif($acao=='reabrir_origem') {
			# Informa��es sobre ultimo processo do ticket;
			$dadosProcessoTicket=ultimoProcessoTicket($idTicket);

			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$url="http://$configAppHost/index.php?modulo=protocolo&acao=ver&registro=$matriz[protocolo]";
			$msgOrigem="
$configAppName - $configAppVersion

"._("WARNING: Ticket was reopened!")."

"._("For making reference to this attendance,")." "._("please, enter in contact using")."
"._("the following protocol number:")." $numProtocolo

"._("Protocol:")." $numProtocolo
"._("URL:")." $url
"._("Subject:")." $assunto
"._("Created by:")." $usuario
"._("Created in:")." $dataCriacao
--------------------------------------------------------------------------------
"._("Text:")."
$texto
--------------------------------------------------------------------------------

"._("Reopening Date:")." $dadosProcessoTicket[data]
"._("Priority:")." $nomePrioridade
"._("Category:")." $nomeCategoria
"._("Current status:")." $dadosProcessoTicket[status]
"._("Modified by:")." $dadosProcessoTicket[login]

"._("Reopening comment:")."
--------------------------------------------------------------------------------
$dadosProcessoTicket[texto]
--------------------------------------------------------------------------------
";

			$acaoTicket=_("Reopened Ticket");
		}
		elseif($acao=='fechar_origem') {
			# Informa��es sobre ultimo processo do ticket;
			$dadosProcessoTicket=ultimoProcessoTicket($idTicket);

			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$url="http://$configAppHost/index.php?modulo=protocolo&acao=ver&registro=$matriz[protocolo]";
			$msgOrigem="
$configAppName - $configAppVersion

"._("WARNING: Ticket was closed!")."

"._("Protocol:")." $matriz[protocolo]
"._("URL:")." $url
"._("Subject:")." $assunto
"._("Created by:")." $usuario
"._("Created in:")." $dataCriacao
--------------------------------------------------------------------------------
"._("Text:")."
$texto
--------------------------------------------------------------------------------

"._("Date of Closing:")." $dadosProcessoTicket[data]
"._("Priority:")." $nomePrioridade
"._("Category:")." $nomeCategoria
"._("Current status:")." $dadosProcessoTicket[status]
"._("Modified by:")." $dadosProcessoTicket[login]


"._("Closing comment:")."
--------------------------------------------------------------------------------
$dadosProcessoTicket[texto]
--------------------------------------------------------------------------------
";
			$acaoTicket=_("Closed Ticket");
		} #come�o da mensagem de e-mail (Alexandre)
		elseif( $acao == 'feedback' ) {
			# Informa��es em parametros sobre a mensagem;
			$parametros=carregaParametros();
			if( $parametros['feedback_msg'] ){
				$texto = $parametros['feedback_msg'];
			}

			# Informa��es sobre ultimo processo do ticket;
			$dadosProcessoTicket = ultimoProcessoTicket( $idTicket );

			# Alertar membros dos grupos pertencentes ao usuario, da cria��o do novo
			# ticket
			$url = "http://$configAppHost/index.php?modulo=protocolo&sub=feedback&acao=incluir&registro=$matriz[protocolo]";
			$msgOrigem="\n$configAppName - $configAppVersion\n\n".
			_("WARNING: Ticket was closed!")." "._("We would like to ask for its evaluation.")."\n\n".
			_("Protocol:")." $matriz[protocolo]\n".
			_("URL:")." $url\n".
			_("Subject:")." $assunto\n".
			_("Created by:")." $usuario\n".
			_("Created in:")." $dataCriacao\n".
			"--------------------------------------------------------------------------------\n".
			_("Text:")."\n$texto\n".
			"--------------------------------------------------------------------------------\n\n".
			_("Date of Closing:")." $dadosProcessoTicket[data]\n".
			_("Priority:")." $nomePrioridade\n".
			_("Category:")." $nomeCategoria\n".
			_("Current status:")." $dadosProcessoTicket[status]\n".
			_("Modified by:")." $dadosProcessoTicket[login]\n\n\n".
			_("Closing comment:").
			"--------------------------------------------------------------------------------\n".
			$dadosProcessoTicket['texto']."\n".
			"--------------------------------------------------------------------------------\n".
			$parametros['feedback_feet']."\n";

			$acaoTicket= "Senhor "._("- Evaluation of Attendance");
		}
		# Fim da mensagem de e-mail (Alexandre)

	}


	# Buscar Usu�rio de uma Categoria

	if( $acao=='incluir' || $acao=='comentario' ) {
		# Listar Grupos do usu�rio
		$sql="
			SELECT
				$tb[Usuarios].login,
				$tb[Perfil].email,
				$tb[Perfil].titulo_email
			FROM
				$tb[Perfil],
				$tb[Usuarios],
				$tb[UsuariosGrupos],
				$tb[CategoriasGrupos],
				$tb[Categorias]
			WHERE
				$tb[Perfil].id=$tb[Usuarios].id
				AND $tb[Usuarios].id=$tb[UsuariosGrupos].idUsuario
				AND $tb[UsuariosGrupos].idGrupo = $tb[CategoriasGrupos].idGrupo
				AND $tb[CategoriasGrupos].idCategoria = $tb[Categorias].id
				AND $tb[Categorias].id='$categoria'
				AND $tb[Perfil].notificar_email='S'
			GROUP BY
				$tb[Usuarios].id";
		$consulta=consultaSQL($sql, $conn);
		$contaConsulta = contaConsulta( $consulta );
		if( $consulta && $contaConsulta > 0 ) {
			for( $i=0; $i < $contaConsulta; $i++ ) {
				$email = resultadoSQL($consulta, $i, 'email');
				$titulo_email = resultadoSQL($consulta, $i, 'titulo_email');
				$titulo = ( !$titulo_email ? "Ticket-IT:" : $titulo_email ) . " " . $acaoTicket;
				mailEnviar('naoresponda@devel-it.com.br',$email, $titulo, $msg);
			}
		}
	}
	// by nash 2007-04-17 - the feedback invite should be sent for companie users
	elseif( $acao == 'feedback' ){
		$usuarioEmpresa = getCompanyUserByTicket($idTicket);
		mailEnviar( 'naoresponda@devel-it.com.br', $usuarioEmpresa['email'], "Ticket-IT: $assunto", $msgOrigem );
	}

	$destinos = $matriz['email'];
	for( $x=0; $x < count($destinos); $x++ ) {
		# Enviar email para criador do ticket
		mailEnviar( 'naoresponda@devel-it.com.br', $destinos[$x], "Ticket-IT: $assunto", $msgOrigem );
	}
	return(0);

}

?>
