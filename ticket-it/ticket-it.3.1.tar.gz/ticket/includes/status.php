<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 16/04/2003
# Ultima altera��o: 18/08/2006
#    Altera��o No.: 007
#
# Fun��o:
#    Painel - Fun��es para cadastro de status


# Fun��o para cadastro
function status($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $sessLogin;
	
	# Permiss�o do usuario
	$permissao=buscaPermissaoUsuario($sessLogin[login],'login','igual','login');
	
	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
		else {	
	
		# Topo da tabela - Informa��es e menu principal de cadastro
		novaTabela2("["._("Status")."]", "center", '100%', 0, 3, 1, $corFundo, $corBorda, 4);
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('65%', 'left', $corFundo, 0, 'tabfundo1');
					echo "<br><img src=".$html[imagem][statusg]." border=0 align=left><b class=bold>"._("Status")."</b>
					<br><span class=normal10>"._("Cadaster of")."&nbsp;"."<b>"._("status")."</b>"."&nbsp;"._("for the tickets.")."</span>";
				htmlFechaColuna();			
				$texto=htmlMontaOpcao("<br>"._("Add"), 'incluir');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=adicionar", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>"._("Search"), 'procurar');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=procurar", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>"._("List"), 'listar');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=listar", 'center', $corFundo, 0, 'normal');
			fechaLinhaTabela();
		fechaTabela();
		
		# Mostrar Status caso n�o seja informada a a��o
		if(!$acao) {
			# Mostrar Status
			echo "<br>";
			listarStatus($modulo, $sub, $acao, 0, $matriz);
		}
	
		# Inclus�o
		if($acao=="adicionar") {
			echo "<br>";
			incluirStatus($modulo, $sub, $acao, $registro, $matriz);
		}
		
		# Altera��o
		elseif($acao=="alterar") {
			echo "<br>";
			alterarStatus($modulo, $sub, $acao, $registro, $matriz);
		}
		
		# Exclus�o
		elseif($acao=="excluir") {
			echo "<br>";
			excluirStatus($modulo, $sub, $acao, $registro, $matriz);
		}
	
		# Busca
		elseif($acao=="procurar") {
			echo "<br>";
			procurarStatus($modulo, $sub, $acao, $registro, $matriz);
		} #fecha tabela de busca
		
		# Listar
		elseif($acao=="listar") {
			echo "<br>";
			listarStatus($modulo, $sub, $acao, $registro, $matriz);
		} #fecha listagem 
	}


} #fecha menu principal 


# fun��o de busca 
function buscaStatus($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Status] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * FROM $tb[Status] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * FROM $tb[Status] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * FROM $tb[Status] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	
} # fecha fun��o de busca


# Listar 
function listarStatus($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $moduloApp, $corFundo, $corBorda, $html, $limite;

	# Cabe�alho		
	# Motrar tabela de busca
	novaTabela("["._("List")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 5);
		# Sele��o de registros
		$consulta=buscaStatus($texto, $campo, 'todos','nome');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# N�o h� registros
			itemTabelaNOURL(_('There are not registered record'), 'left', $corFundo, 3, 'txtaviso');
		}
		else {
		
			# Paginador
			paginador($consulta, contaConsulta($consulta), $limite[lista][status], $registro, 'normal10', 5, $urlADD);
		
			# Cabe�alho
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela(_('Name'), 'left', '30%', 'tabfundo0');
				itemLinhaTabela(_('Description'), 'left', '30%', 'tabfundo0');
				itemLinhaTabela(_('Value'), 'center', '10%', 'tabfundo0');
				itemLinhaTabela(_('Options'), 'center', '30%', 'tabfundo0');
			fechaLinhaTabela();

			# Setar registro inicial
			if(!$registro) {
				$i=0;
			}
			elseif($registro && is_numeric($registro) ) {
				$i=$registro;
			}
			else {
				$i=0;
			}

			$limite=$i+$limite[lista][status];
			
			while($i < contaConsulta($consulta) && $i < $limite) {
				# Mostrar registro
				$id=resultadoSQL($consulta, $i, 'id');
				$nome=resultadoSQL($consulta, $i, 'nome');
				$descricao=resultadoSQL($consulta, $i, 'texto');
				$valor=resultadoSQL($consulta, $i, 'valor');
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$id>"._("Change")."</a>",'alterar');
				$opcoes.="&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>"._("Delete")."</a>",'excluir');
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($nome, 'left', '30%', 'normal10');
					itemLinhaTabela($descricao, 'left', '30%', 'normal10');
					itemLinhaTabela($valor, 'center', '10%', 'normal10');
					itemLinhaTabela($opcoes, 'center', '30%', 'normal10');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem

	fechaTabela();
	
} # fecha fun��o de listagem



# Fu��o para visualiza��o de status 
function verStatusStatus()
{
	global $conn, $tb, $corFundo, $corBorda, $html;

	# Motrar tabela de busca
	novaTabela2("["._("Status Information.")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('60%', 'left', $corFundo, 0, 'tabfundo1');
			echo "<br><img src=".$html[imagem][status]." border=0 align=left><b class=bold>"._("Status")."</b><br>
			<span class=normal10>"._("Status Information.");
			htmlFechaColuna();
			htmlAbreColuna('10', 'left', $corFundo, 0, 'normal');
			echo "&nbsp;";
			htmlFechaColuna();
			
			
			htmlAbreColuna('40%', 'left', $corFundo, 0, 'normal');
				# Mostrar status
				$busca=buscaStatus($texto, $campo, 'todos', 'id');
				if($busca) {
					$numBusca=contaConsulta($busca);
				}
				else {
					$numBusca=0;
				}
				
				htmlAbreTabelaSH('left', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				novaLinhaTabela($corFundo, '100%');
					itemLinhaNOURL(_('Number of records:'), 'right', $corFundo, $colunas, 'bold10');
					itemLinhaNOURL("$numBusca "._("status")."&nbsp;"._("existent(s)"), 'left', $corFundo, $colunas, 'normal10');
				fechaLinhaTabela();
				
			
			htmlFechaColuna();
		fechaLinhaTabela();
	fechaTabela();	
} #fecha status 


# Funcao para cadastro 
function incluirStatus($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;

	# Form de inclusao
	if(!$matriz[bntAdicionar]) {
		# Motrar tabela de busca
		novaTabela2("["._("Add")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);				
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
			$texto="			
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=$acao>&nbsp;";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold>"._("Name:")." </b><br>
					<span class=normal10>"._("Status name, used for status of the Tickets")."</span>";
				htmlFechaColuna();
				$texto="<input type=text name=matriz[nome] size=60>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold>"._("Description:")." </b><br>
					<span class=normal10>"._("Detailed description about status")."</span>";
				htmlFechaColuna();
				$texto="<textarea name=matriz[descricao] rows=4 cols=60></textarea>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold>"._("Value:")." </b><br>";
				htmlFechaColuna();
				itemLinhaForm(formSelectLetras('A','valor'), 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "&nbsp;";
				htmlFechaColuna();
				$texto="<input type=submit name=matriz[bntAdicionar] value="._("Add")." class=submit>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
		fechaTabela();
	} #fecha form
	elseif($matriz[bntAdicionar]) {
		# Conferir campos
		if($matriz[nome] && $matriz[descricao]) {
			# Buscar por status
			if(contaConsulta(buscaStatus($matriz[nome], 'nome', 'igual','nome'))>0){
				# Erro - campo inv�lido
				# Mensagem de aviso
				$msg=_("This priority already exists!");
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				aviso(_("Warning: Incorrect Data"), $msg, $url, 760);
			}
			# continuar - campos OK
			else {
				# Cadastrar em banco de dados
				$grava=dbStatus($matriz, 'incluir');
				
				# Verificar inclus�o de registro
				if($grava) {
					# acusar falta de parametros
					# Mensagem de aviso
					$msg=_("Data Recorded Success full!");
					$url="?modulo=$modulo&sub=$sub&acao=$acao";
					aviso(_("Warning"), $msg, $url, 760);
				}
				
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	}

} # fecha funcao de inclusao



# Fun��o para grava��o em banco de dados
function dbStatus($matriz, $tipo)
{
	global $conn, $tb, $modulo, $sub, $acao;
	
	# Sql de inclus�o
	if($tipo=='incluir') {
		$sql="INSERT INTO $tb[Status] VALUES (0,
		'$matriz[nome]',
		'$matriz[descricao]',
		'$matriz[valor]')";
	} #fecha inclusao
	
	elseif($tipo=='excluir') {
		# Verificar se o status existe
		$tmpBusca=buscaStatus($matriz[id], 'id', 'igual', 'id');
		
		# Registro j� existe
		if(!$tmpBusca|| contaConsulta($tmpBusca)==0) {
			# Mensagem de aviso
			$msg=_("Record doesn't exist in the database");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: Error when changing record"), $msg, $url, 760);
		}
		else {
			$sql="DELETE FROM $tb[Status] WHERE id=$matriz[id]";
		}
	}
	
	# Alterar
	elseif($tipo=='alterar') {
		# Verificar se status existe
		$sql="UPDATE $tb[Status] SET texto='$matriz[texto]', nome='$matriz[nome]', valor='$matriz[valor]' WHERE id=$matriz[id]";
	}
	
	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno);
	}
	
} # fecha fun��o de grava��o em banco de dados



# Exclus�o de servicos
function excluirStatus($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# ERRO - Registro n�o foi informado
	if(!$registro) {
		# Mostrar Erro
		$msg=_("Record not found!");
		$url="?modulo=$modulo&sub=$sub&acao=$acao";
		aviso(_("Warning"), $msg, $url, 760);
	}
	# Form de inclusao
	elseif($registro && !$matriz[bntExcluir]) {
	
		# Buscar Valores
		$consulta=buscaStatus($registro, 'id', 'igual', 'id');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# Mostrar Erro
			$msg=_("Record not found!");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning"), $msg, $url, 760);
		}
		else {
			#atribuir valores
			$id=resultadoSQL($consulta, 0, 'id');
			$nome=resultadoSQL($consulta, 0, 'nome');
			$descricao=resultadoSQL($consulta, 0, 'texto');
			$valor=resultadoSQL($consulta, 0, 'valor');
			
			# Motrar tabela de busca
			novaTabela2("["._("Delete")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=acao value=$acao>
					<input type=hidden name=registro value=$registro>
					<input type=hidden name=matriz[id] value=$registro>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("Status:")." </b>";
					htmlFechaColuna();
					itemLinhaForm($nome, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("Description:")." </b>";
					htmlFechaColuna();
					itemLinhaForm($descricao, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("Value:")." </b>";
					htmlFechaColuna();
					itemLinhaForm($valor, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
	
				# Bot�o de confirma��o
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntExcluir] value="._("Delete")." class=submit>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		} #fecha alteracao
	} #fecha form - !$bntExcluir
	
	# Altera��o - bntExcluir pressionado
	elseif($matriz[bntExcluir]) {
		# Cadastrar em banco de dados
		$grava=dbStatus($matriz, 'excluir');
				
		# Verificar inclus�o de registro
		if($grava) {
			# Mensagem de aviso
			$msg=_("Record deleted Success Full! ");
			$url="?modulo=$modulo&sub=$sub";
			aviso(_("Warning"), $msg, $url, 760);
		}
		
	} #fecha bntExcluir
	
} #fecha exclusao 



# Funcao para altera��o
function alterarStatus($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# ERRO - Registro n�o foi informado
	if(!$registro) {
		# ERRO
	}
	# Form de inclusao
	elseif($registro && !$matriz[bntAlterar]) {
	
		# Buscar Valores
		$consulta=buscaStatus($registro, 'id', 'igual', 'id');
		if(!$consulta || contaConsulta($consulta)==0) {
			# Mostrar Erro
			$msg=_("Record not found!");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning"), $msg, $url, 760);
		}
		else {
			 #atribuir valores
 			 $nome=resultadoSQL($consulta, 0, 'nome');
 			 $descricao=resultadoSQL($consulta, 0, 'texto');
 			 $valor=resultadoSQL($consulta, 0, 'valor');
					
			# Motrar tabela de busca
			novaTabela2("["._("Change")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=registro value=$registro>
					<input type=hidden name=matriz[id] value=$registro>
					<input type=hidden name=acao value=$acao>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("Status:")." </b><br>
						<span class=normal10>"._("Status name, used in Tickets")."</span>";
					htmlFechaColuna();
					$texto="<input type=text name=matriz[nome] size=60 value='$nome'>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("Description:")." </b><br>
						<span class=normal10>"._("Detailed description about the status")."</span>";
					htmlFechaColuna();
					$texto="<textarea name=matriz[texto] rows=4 cols=60>$descricao</textarea>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>"._("Value:")." </b><br>";
					htmlFechaColuna();
					itemLinhaForm(formSelectLetras($valor,'valor'), 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntAlterar] value="._("Change")." class=submit>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();				

		} #fecha alteracao
	} #fecha form - !$bntAlterar
	
	# Altera��o - bntAlterar pressionado
	elseif($matriz[bntAlterar]) {
		# Conferir campos
		if($matriz[texto] && $matriz[nome]) {
			# continuar
			# Cadastrar em banco de dados
			$grava=dbStatus($matriz, 'alterar');
			
			# Verificar inclus�o de registro
			if($grava) {
				# acusar falta de parametros
				# Mensagem de aviso
				$msg=_("Data Recorded Success full!");
				$url="?modulo=$modulo&sub=$sub";
				aviso(_("Warning"), $msg, $url, 760);
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg=_("Lack of necessary parameters.")."&nbsp;"._("Fill the required fields and try again ");
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
		}
	} #fecha bntAlterar
	
} # fecha funcao de altera��o



# Fun��o para procura de servi�o
function procurarStatus($modulo, $sub, $acao, $registro, $matriz)
{
	global $conn, $tb, $corFundo, $corBorda, $html, $limite, $textoProcurar;
	
	# Atribuir valores a vari�vel de busca
	if(!$matriz) {
		$matriz[bntProcurar]=1;
		$matriz[txtProcurar]=$textoProcurar;
	} #fim da atribuicao de variaveis
	
	# Motrar tabela de busca
	novaTabela2("["._("Search")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('30%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b>"._("Search for:")."</b>";
			htmlFechaColuna();
			$texto="
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=procurar>
			<input type=text name=matriz[txtProcurar] size=40 value='$matriz[txtProcurar]'>
			<input type=submit name=matriz[bntProcurar] value="._("Search")." class=submit>";
			itemLinhaForm($texto, 'left','middle', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();

	# Caso bot�o procurar seja pressionado
	if( $matriz[bntProcurar] && $matriz[txtProcurar] ) {
		#buscar registros
		$consulta=buscaStatus("upper(texto) like '%$matriz[txtProcurar]%' OR upper(nome) like '%$matriz[txtProcurar]%' OR upper(valor) like '%$matriz[txtProcurar]%'",$campo, 'custom','nome');

		echo "<br>";

		novaTabela("["._("Results")."]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
	
		if(!$consulta || contaConsulta($consulta)==0 ) {
			# N�o h� registros
			itemTabelaNOURL(_('No record found'), 'left', $corFundo, 3, 'txtaviso');
		}
		elseif($consulta && contaConsulta($consulta)>0 && (!$registro || is_integer($registro)) ) {	
		
			itemTabelaNOURL(_('Found records looking for').' ('.$matriz[txtProcurar].'): '.contaConsulta($consulta)."&nbsp;"._('record(s)'), 'left', $corFundo, 5, 'txtaviso');

			# Paginador
			$urlADD="&textoProcurar=".$matriz[txtProcurar];
			paginador($consulta, contaConsulta($consulta), $limite[lista][status], $registro, 'normal', 5, $urlADD);

			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela(_('Status'), 'left', '30%', 'tabfundo0');
				itemLinhaTabela(_('Description'), 'left', '30%', 'tabfundo0');
				itemLinhaTabela(_('Value'), 'center', '10%', 'tabfundo0');
				itemLinhaTabela(_('Options'), 'center', '30%', 'tabfundo0');
			fechaLinhaTabela();

			# Setar registro inicial
			if(!$registro) {
				$i=0;
			}
			elseif($registro && is_numeric($registro) ) {
				$i=$registro;
			}
			else {
				$i=0;
			}
			
			
			$limite=$i+$limite[lista][status];
			
			while($i < contaConsulta($consulta) && $i < $limite) {
				# Mostrar registro
				$id=resultadoSQL($consulta, $i, 'id');
				$nome=resultadoSQL($consulta, $i, 'nome');
				$descricao=resultadoSQL($consulta, $i, 'texto');
				$valor=resultadoSQL($consulta, $i, 'valor');
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$id>"._("Change")."</a>",'alterar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>"._("Delete")."</a>",'excluir');
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($nome, 'left', '30%', 'normal10');
					itemLinhaTabela($descricao, 'left', '30%', 'normal10');
					itemLinhaTabela($valor, 'center', '10%', 'normal10');
					itemLinhaTabela($opcoes, 'center', '20%', 'normal10');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem
		fechaTabela();
	} # fecha bot�o procurar
} #fecha funcao de  procurar de servi�cos (Procurar



# Fun��o para busca de ID de status
function buscaIDStatus($status, $campo) {
	global $conn;
	
	$consulta=buscaStatus($status, $campo,'igual','valor');
	
	if($consulta && contaConsulta($consulta)==1) return(resultadoSQL($consulta, 0, 'id'));
	else return($consulta);

}



# Fun��o para busca de ID de status
function buscaUltimoStatusTicket($ticket) {
	global $conn;
	
	
	$sql="
		SELECT 
			idStatus,
			MAX(data) data		
		FROM
			processos_ticket
		WHERE
			idTicket=$ticket
		GROUP BY
			idStatus
		ORDER BY 
			data DESC";
			
	$consulta=consultaSQL($sql, $conn);
	
	if($consulta && contaConsulta($consulta)>0) {
		$status=checaStatusTicket(resultadoSQL($consulta, 0, 'idStatus'));
		return($status);
	}
	else return($consulta);

}



# Fun��o para checagem de status
function checaStatusTicket($idStatus) {
	global $conn;
	
	$consulta=buscaStatus($idStatus, 'id','igual','id');
	
	if($consulta) {
		$retorno[status]=resultadoSQL($consulta, 0, 'valor');
		$retorno[nome]=resultadoSQL($consulta, 0, 'nome');
	}
	
	return($retorno);

}



# Fun��o para checagem de status
function checaValorStatus($valor) {
	global $conn;
	
	$consulta=buscaStatus($valor, 'valor','igual','id');
	
	if($consulta) {
		$retorno[status]=resultadoSQL($consulta, 0, 'valor');
		$retorno[nome]=resultadoSQL($consulta, 0, 'nome');
	}
	
	return($retorno);
}

?>