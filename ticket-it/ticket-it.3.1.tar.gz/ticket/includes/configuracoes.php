<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 16/01/2003
# Ultima altera��o: 19/01/2005
#    Altera��o No.: 005
#
# Fun��o:
#    Painel - Fun��es para configura��es



# Fun��o de configura��es
function config($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $sessLogin;

	# Permiss�o do usuario
	$permissao=buscaPermissaoUsuario($sessLogin[login],'login','igual','login');
	
	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
		
		if(!$sub) {
			### Menu principal - usuarios logados apenas
			novaTabela2("["._("Configurations")."]", "center", '100%', 0, 3, 1, $corFundo, $corBorda, 3);
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('65%', 'left', $corFundo, 0, 'tabfundo1');
						echo "<br><img src=".$html[imagem][configuracoes]." border=0 align=left >
						<b class=bold>"._("Configurations")."</b>
						<br><span class=normal10>"._("Configurations")." $configAppName.</span>";
					htmlFechaColuna();			
					$texto=htmlMontaOpcao("<br>"._("Users"), 'usuario');
					itemLinha($texto, "?modulo=$modulo&sub=usuarios", 'center', $corFundo, 0, 'normal');
					$texto=htmlMontaOpcao("<br>"._("Groups"), 'grupo');
					itemLinha($texto, "?modulo=$modulo&sub=grupos", 'center', $corFundo, 0, 'normal');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('65%', 'left', $corFundo, 0, 'tabfundo1');
					echo "&nbsp;";
					htmlFechaColuna();			
					$texto=htmlMontaOpcao("<br>"._("Categories"), 'categorias');
					itemLinha($texto, "?modulo=$modulo&sub=categorias", 'center', $corFundo, 0, 'normal');
					$texto=htmlMontaOpcao("<br>"._("Priorities"), 'prioridades');
					itemLinha($texto, "?modulo=$modulo&sub=prioridades", 'center', $corFundo, 0, 'normal');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('65%', 'left', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();			
					$texto=htmlMontaOpcao("<br>"._("Status"), 'status');
					itemLinha($texto, "?modulo=$modulo&sub=status", 'center', $corFundo, 0, 'normal');
					$texto=htmlMontaOpcao("<br>"._("Parameters"), 'parametros');
					itemLinha($texto, "?modulo=$modulo&sub=parametros", 'center', $corFundo, 0, 'normal');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('65%', 'left', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();			
					$texto=htmlMontaOpcao("<br>"._("Companies"), 'empresas');
					itemLinha($texto, "?modulo=$modulo&sub=empresas", 'center', $corFundo, 0, 'normal');
					$texto=htmlMontaOpcao("<br>"._("Users of ")."<br>"._("Companies"), 'usuariosempresas');
					itemLinha($texto, "?modulo=$modulo&sub=usuariosempresas", 'center', $corFundo, 0, 'normal');
				fechaLinhaTabela();
			fechaTabela();
		}
		
		# Usu�rios
		elseif($sub=='usuarios') {
			# Menu de modulos
			cadastroUsuarios($modulo, $sub, $acao, $registro, $matriz);	
		}
		
		# Grupos
		elseif($sub=='grupos') {
			# Menu de parametros
			cadastroGrupos($modulo, $sub, $acao, $registro, $matriz);
		}
		# verifica��o dos submodulos
		elseif($sub=='categorias') {
			categorias($modulo, $sub, $acao, $registro, $matriz);
		}
		elseif($sub=='prioridades') {
			prioridades($modulo, $sub, $acao, $registro, $matriz);
		}
		elseif($sub=='status') {
			status($modulo, $sub, $acao, $registro, $matriz);
		}
		elseif($sub=='categorias_grupos') {
			categoriasGrupos($modulo, $sub, $acao, $registro, $matriz);
		}
		elseif($sub=='parametros') {
			parametros($modulo, $sub, $acao, $registro, $matriz);
		}
		elseif($sub=='empresas') {
			empresas($modulo, $sub, $acao, $registro, $matriz);
		}
		elseif($sub=='usuariosempresas') {
			usuariosEmpresas($modulo, $sub, $acao, $registro, $matriz);
		}
	}
	
}
?>