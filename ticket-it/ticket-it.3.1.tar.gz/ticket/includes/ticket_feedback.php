<?php
################################################################################
# Fun��o:
#    Fun��es realacionados aos Feedback de atendimentos


/**
 * Fun��o construtora
 *
 * @param str $modulo
 * @param str $sub
 * @param str $acao
 * @param str $registro
 * @param str $matriz
 */
function ticketFeedback( $modulo, $sub, $acao, $registro, $matriz ) {
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	if( $acao == 'incluir' ) {
		formTicketFeedback( $modulo, $sub, $acao, $registro, $matriz );
	}
	elseif( $acao == "listar" ) {
		listarFeedback( $modulo, $sub, $acao, $matriz, $registro );
	}
	elseif( $acao == "excluir" ) {
		excluirFeedback( $modulo, $sub, $acao, $matriz, $registro );			
	}
	elseif( $acao == "alterar" ) {
		alteraFeedback( $modulo, $sub, $acao, $matriz, $registro );			
	}
	
}

/**
 * Fun��o que adiciona coment�rio ao Ticket
 *
 * @param str $modulo
 * @param str $sub
 * @param str $acao
 * @param str $registro
 * @param str $matriz
 * @return void
 */
function formTicketFeedback( $modulo, $sub, $acao, $registro, $matriz ) {

	global $corFundo, $corBorda, $tb, $html, $sessLogin;
	
	if( $registro ) {
		# Procurar Ticket a partir de protocolo
		
		if( $modulo == "ticket" ) {
			$idTicket  = $registro;
			$consulta  = buscaTicket( addslashes( $registro ), 'id', 'igual', 'id' );
			$idUsuario = resultadoSQL( $consulta, 0, 'idUsuario' );
		}
		else {
			$consulta = buscaTicket( addslashes( $registro ), 'protocolo', 'igual', 'protocolo' );
			$idTicket = resultadoSQL( $consulta, 0, 'id' );
			$idUsuario = resultadoSQL( $consulta, 0, 'idUsuario' );	
		}
		
		$matriz[idTicket] = $idTicket;
		$sessLogin[modulo] = $modulo;
		$sessLogin[sub]  = $sub;
		$sessLogin[acao] = $acao;
	}
	if( $acao == 'incluir' ) {
		
		if( !$matriz[bntConfirmar] || $mensagem ) {

			mostraFormTicketFeedback( _('Send Feedback'), $modulo, $sub, $acao, $registro, $matriz );
		
		} #fecha form
		elseif( $matriz[bntConfirmar] && $matriz[nota] && $matriz[nota] <= 10 && $matriz[nota] >= 0 ) {

			$matriz[idTicket] = $idTicket;
			$matriz[protocolo] = $registro;
			# Verificar qual � o sistema que pertence o usuario
			if( $sessLogin['isCompanyUser'] ){
				$matriz[idUsuario] =  buscaIDUsuario( 'guest', 'login', 'igual', 'login' );
			}
			else{
				$matriz[idUsuario] = ( $sessLogin[login] ) 
					? buscaIDUsuario( $sessLogin[login], 'login', 'igual', 'login' ) 
					: buscaIDUsuario( 'guest', 'login', 'igual', 'login' );				
			}
			
			$grava = dbTicketFeedback( $matriz, 'incluir' );
			
			if($grava) {
				
				echo "<br />";
				if($sessLogin[login]) {
					listarFeedback($modulo, $sub, "listar", $matriz, $idTicket);
					echo "<br />";
					$url = "?modulo=$modulo&sub=$sub&acao=$acao";
					$msg = _("Record was written success full! Thanks for your collaboration!");
					avisoNOURL( _("Warning"), $msg, '100%' );
				}
				else {
					$msg = _("Record was written success full! Thanks for your collaboration!");
					avisoNOURL( _("Warning"), $msg, '100%' );
					echo "<p align=\"center\"><input type=\"button\" value=\""._("Close Window")."\" onclick=\"window.close();\" /></p>";
				}
				mailTicket( $idTicket, $idUsuario, 'verfeedback' );
			}
		}
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			
			$msg = _("Lack of necessary parameters."). _("Fill the required fields and try again ");
			avisoNOURL( _("Warning: An error has been ocurred"), $msg, '100%' );
			echo "<br />";
			mostraFormTicketFeedback( _('Send Feedback'), $modulo, $sub, $acao, $registro, $matriz );
		}	

	}
	else {
		if( $registro ) {
			# Ticket n�o pode ser visualizado
			$msg = _("Ticket cannot be found");
			avisoNOURL( _("Feedback View"), $msg, '100%' );
		}
	}
}

/**
 * Imprime o Formul�rio de avalia��o do Ticket
 *
 * @param str $modulo
 * @param str $sub
 * @param str $acao
 * @param str $registro
 * @param arr $matriz
 */
function mostraFormTicketFeedback($titulo, $modulo, $sub, $acao, $registro, $matriz ) {
	
	global $corFundo, $corBorda, $tb, $html, $sessLogin;

	$notas = array( "10", "9", "8", "7", "6", "5", "4", "3", "2", "1", "0" );


	$idTicket= ($acao == "alterar") 
		? resultadoSQL(buscaFeedbackTicket( $registro, 'id','igual','id' ), 0, 'idTicket') 
		: $registro;

	if( $modulo == "protocolo" && $sub == "feedback" && $acao == "incluir" ){
		$idTicket = resultadoSQL(buscaTicket($registro, 'protocolo', 'igual', 'id' ), 0, 'id' );
	}
	$opcListar = "
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr>
		 <td width=\"50%\" align=\"left\" class=\"tabtitulo\">$titulo<td>
		 <td width=\"50%\" align=\"right\">
	";
	if( $sessLogin['isCompanyUser'] ){
		$opcListar.=htmlMontaOpcao("<a href=\"?modulo=ticketUE&sub=feedbackUE&acao=listarUE&registro=$idTicket\" class=\"titulo\">"._("List")."</a>",'listar');
	}
	else{
		$opcListar.= ( !$sessLogin[login] ) 
			? "&nbsp;" 
			: htmlMontaOpcao("<a href=\"?modulo=ticket&sub=feedback&acao=listar&registro=$idTicket\" class=\"titulo\">"._("List")."</a>",'listar');
	}
	$opcListar.= "
		 </td>
		</tr></table>
	";

	novaTabela2( $opcListar, "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2 );
		#fim das opcoes adicionais
	novaLinhaTabela( $corFundo, '100%' );
	$texto = "			
		<form method=\"post\" name=\"matriz\" action=\"index.php\">
		<input type=\"hidden\" name=\"modulo\" value=\"$modulo\">
		<input type=\"hidden\" name=\"sub\" value=\"$sub\">
		<input type=\"hidden\" name=\"registro\" value=\"$registro\">
		<input type=\"hidden\" name=\"acao\" value=\"$acao\">&nbsp;$mensagem
	";
	itemLinhaNOURL( $texto, 'left', $corFundo, 2, 'tabfundo1' );
	fechaLinhaTabela();

	novaLinhaTabela( $corFundo, '100%' );
	htmlAbreColuna( '30%', 'right', $corFundo, 0, 'tabfundo1' );
	echo "<b class=\"bold10\">"._("Grade:")." </b>";
	htmlFechaColuna();
	$texto = formGeraSelect( "matriz[nota]", $notas, $notas, $matriz[nota], "" );
	itemLinhaForm( $texto, 'left', 'top', $corFundo, 0, 'tabfundo1' );
	fechaLinhaTabela();
	
	novaLinhaTabela( $corFundo, '100%' );
	htmlAbreColuna( '30%', 'right', $corFundo, 0, 'tabfundo1' );
	echo "<b class=\"bold10\">"._("Commentary:")." </b><br />(Opcional)";
	htmlFechaColuna();
	$texto = "
	<textarea cols=\"40\" rows=\"5\" name=\"matriz[comentario]\" 
	onkeyup=\"javascript:caracteresRestantes(this, 'faltam', 255)\">$matriz[comentario]</textarea>
		<br /><span id=\""._("remains")."\">255</span> "._("Remaining characters")."
	";
	itemLinhaForm( $texto, 'left', 'top', $corFundo, 0, 'tabfundo1' );
	fechaLinhaTabela();
	
	novaLinhaTabela( $corFundo, '100%' );
	htmlAbreColuna( '30%', 'right', $corFundo, 0, 'tabfundo1' );
	echo "&nbsp;";
	htmlFechaColuna();
	$texto = "
	<input type=\"submit\" name=\"matriz[bntConfirmar]\" value=\""._("Confirm")."\" class=\"submit\">
	";
	itemLinhaForm( $texto, 'left', 'top', $corFundo, 0, 'tabfundo1' );
	fechaLinhaTabela();
	
	fechaTabela();

	echo "<br />";
	novaTabela2SH( 'left', '100%', 0, 0, 0, $corFundo, $corBorda, 0 );
	htmlAbreLinha( $corFundo );
	htmlAbreColuna('100%', 'left', $corFundo, 0, 'normal10');
		if( $sessLogin['isCompanyUser'] ){
			mostraTicketUE( $matriz[idTicket], 0 );
		} else{
			mostraTicket( $matriz[idTicket], 0 );
		}
	htmlFechaColuna();
	htmlFechaLinha();
	fechaTabela();
}

/**
 * Fun��o para grava��o em banco de dados
 *
 * @param arr $matriz
 * @param str $tipo
 * @return unknown
 */
function dbTicketFeedback( $matriz, $tipo ){
	global $conn, $tb, $modulo, $acao, $sessLogin;
	
	$data = dataSistema();
	if( $sessLogin['isCompanyUser'] ){
		$idUser = buscaIDUsuario( 'guest', 'login', 'igual', 'id' );
		$matriz['idUsuario']=$idUser;
	}
	else{
		$idUser = ( $sessLogin[login] )
			? $sessLogin['id']
			: buscaIDUsuario( 'guest', 'login', 'igual', 'login' );
	}
	
	if( $tipo == 'incluir' ) {
		$sql = "
			INSERT INTO $tb[TicketFeedback] 
			VALUES (0, '$matriz[idTicket]', '$matriz[idUsuario]', '$data[dataBanco]', '$matriz[nota]', 
			'" . addslashes($matriz[comentario]) . "')";
	}
	elseif( $tipo == 'excluir' ) {
		$sql = "DELETE FROM $tb[TicketFeedback] WHERE id='$matriz[id]'";
	}
	elseif( $tipo == 'alterar' ) {
		$sql = "
			UPDATE 
				$tb[TicketFeedback] 
			SET 
				idUsuario='$matriz[idUsuario]', data='$data[dataBanco]', 
				nota='$matriz[nota]', comentario='" . addslashes($matriz[comentario]) . "'
			WHERE 
				id='$matriz[id]'
		";
	}
	
	if( $sql ) { 
		$retorno = consultaSQL( $sql, $conn );
		return( $retorno ); 
	}
	
}

# fun��o de busca 
/**
 * Lista o �ltimo feedback realizado para o $idTicket
 *
 * @param int $idTicket
 * @return unknown
 */
function buscaUltimoFeedbackTicket( $idTicket ){
	global $conn, $tb;
	
	$sql = "SELECT * from $tb[TicketFeedback] WHERE idTicket=$idTicket ORDER BY data DESC LIMIT 1";

	$consulta = consultaSQL( $sql, $conn );
	
	if( $consulta && contaConsulta( $consulta ) > 0 ) {
		$retorno[idTicket]   = resultadoSQL( $consulta, 0, 'idTicket' );
		$retorno[data]		 = resultadoSQL( $consulta, 0, 'data' );
		$retorno[idUsuario]  = resultadoSQL( $consulta, 0, 'idUsuario' );
		$retorno[login] 	 = buscaLoginUsuario( $retorno[idUsuario], 'id', 'igual', 'id' );
		$retorno[nota] 		 = resultadoSQL( $consulta, 0, 'nota' );
		$retorno[comentario] = resultadoSQL( $consulta, 0, 'comentario' );
	}
	
	return( $retorno );
	
} # fecha fun��o de busca

/**
 * Listagem de Avalia��es
 *
 * @param str $modulo
 * @param str $sub
 * @param str $acao
 * @param str $matriz
 * @param str $registro
 * @return void
 */
function listarFeedback( $modulo, $sub, $acao, $matriz, $registro ) {
	global $html, $corFundo, $corBorda, $sessLogin;
	if( !$sessLogin[login] ) {
		$msg = _("To list the feedbacks you must be logged in!");
		aviso( _("Warning: An error has been ocurred"), $msg, "javascript:history:back(-1)", '100%' );
	}
	else {

		$contadorNotas = 0;
		$acumuladorNotas = 0;
		
		$perfil = dadosPerfilUsuario( buscaIDUsuario( $sessLogin[login], 'login', 'igual', 'id' ) );
	
		$sqlOPC = ( $perfil[ordemComentarios] == 'D' ) ? "DESC" : "";
	
		$consulta = buscaFeedbackTicket( $registro, 'idTicket', 'igual', "data $sqlOPC" );
	
		$opcListar = "
			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr>
			 <td width=\"50%\" align=\"left\" class=\"tabtitulo\">"._("List Feedback")."<td>
			 <td width=\"50%\" align=\"right\">
		";
		$opcListar.= htmlMontaOpcao("<a href=\"?modulo=ticket&sub=feedback&acao=incluir&registro=$registro\" class=\"titulo\">"._("Add Feedback")."</a>",'feedback');
		$opcListar.= "
			 </td>
			</tr></table>
		";
		
		novaTabela2( $opcListar, 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2 );
	
			if( !$consulta || contaConsulta( $consulta ) == 0 ) {
				novaLinhaTabela( $corFundo, '100%' );
					itemLinhaNOURL( _("No feedback was posted for this Ticket"), 'left', $corFundo, 2, 'txtaviso' );
				fechaLinhaTabela();
			}
			else {
				for( $i = 0; $i < contaConsulta( $consulta ); $i++ ) {
					$usuario  = resultadoSQL( $consulta, $i, 'idUsuario' );
					$id       = resultadoSQL( $consulta, $i, 'id' );
					$idTicket = resultadoSQL( $consulta, $i, 'idTicket' );
					$data     = converteData( resultadoSQL( $consulta, $i, 'data' ), 'banco', 'formdata' );
					$hora     = converteData( resultadoSQL( $consulta, $i, 'data' ), 'banco', 'formhora' );
					$texto    = resultadoSQL( $consulta, $i, 'comentario' );
					$nota     = resultadoSQL( $consulta, $i, 'nota' );
					$acumuladorNotas += $nota; 
					# Informa��es do usuario
					$consultaUsuario = buscaUsuarios( $usuario, 'id', 'igual', 'id' );
					$loginUsuario = resultadoSQL( $consultaUsuario, 0, 'login' );
					
					# Atribuir Valores
					$fundo  = $i % 2 + 1;
					$fundo2 = $i % 2 + 3;
					
					$tmpData = converteData( resultadoSQL( $consulta, $i, 'data' ), 'banco', 'timestamp' );
					novaLinhaTabela( $corFundo, '100%' );
						if( $modulo == 'ticket' ) {
							$opcAdicional = "<a href=\"?modulo=ticket&sub=feedback&acao=excluir&registro=$id\"><img title=\""._("Delete")."\" src=\"".$html[imagem][fechar]."\" border=\"0\" align=\"right\" /></a>";
							$opcAdicional.= "<a href=\"?modulo=ticket&sub=feedback&acao=alterar&registro=$id\"><img title=\""._("Change")."\" src=\"".$html[imagem][alterar]."\" border=\"0\" align=\"right\" /></a>";
						}
						else {
							$opcAdicional = "";
						}
					
						$info = "$opcAdicional
						<b>"._("Posted By:")."</b>&nbsp;"._($loginUsuario)."<br />
						<b>"._("Date:")."</b> $data<br />
						<b>"._("Hour:")."</b> $hora<br />
						";
						$corpo = "<b>"._("Grade:")." $nota</b><br>" . nl2br( $texto );
						itemLinhaTabela( $info, 'left', '30%', "tabfundo$fundo" );
						itemLinhaNOURL( $corpo, 'left', $corFundo, 0, "tabfundo$fundo2" );
					fechaLinhaTabela();
				}
				novaLinhaTabela( $corFundo, '100%');
					$media = number_format($acumuladorNotas / contaConsulta( $consulta ), 2, ',', '.');
					itemLinhaNOURL(_("Average Grade:")." <b>$media</b>", "right", $corFundo, 2, "tabfundo1");
				fechaLinhaTabela();		
			}
		fechaTabela();	
	
		echo "<br />";
		
		novaTabela2SH( 'left', '100%', 0, 0, 0, $corFundo, $corBorda, 0 );
		htmlAbreLinha( $corFundo );
		htmlAbreColuna('100%', 'left', $corFundo, 0, 'normal10');
			mostraTicket( $registro, 0 );
		htmlFechaColuna();
		htmlFechaLinha();
		fechaTabela();
	}
}

/**
 * Fun��o de busca de Feedback
 *
 * @param str $texto
 * @param str $campo
 * @param str $tipo
 * @param str $ordem
 * @return unknown
 */
function buscaFeedbackTicket( $texto, $campo, $tipo, $ordem ) {
	global $conn, $tb, $corFundo, $modulo;
	
	if( $tipo == 'todos' ) {
		$sql = "SELECT * FROM $tb[TicketFeedback] ORDER BY $ordem";
	}
	elseif( $tipo == 'contem' ) {
		$sql = "SELECT * FROM $tb[TicketFeedback] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif( $tipo == 'igual' ) {
		$sql = "SELECT * FROM $tb[TicketFeedback] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif( $tipo == 'custom' ) {
		$sql = "SELECT * FROM $tb[TicketFeedback] WHERE $texto ORDER BY $ordem";
	}
	# Verifica consulta
	if( $sql ){
		$consulta = consultaSQL( $sql, $conn );
		# Retornvar consulta
		return( $consulta );
	}
	else {	
		# Mensagem de aviso
		$msg = _("Consultation cannot be accomplished by lack of parameters");
		$url = "?modulo=$modulo";
		aviso( _("Warning: An error has been ocurred"), $msg, $url, 760 );
	}
	
}

/**
 * Exclus�o de avalia��es de tickets
 *
 * @param $modulo
 * @param $sub
 * @param $acao
 * @param $matriz
 * @param $registro
 */
function excluirFeedback( $modulo, $sub, $acao, $matriz, $registro ) {

	global $conn, $corFundo, $corBorda, $tb, $html, $sessLogin;
	
	# Checar permiss�o do usuario
	# Buscar informa��es sobre usuario - permiss�es
	$permissao = buscaPermissaoUsuario( $sessLogin[login] );

	if(!$permissao[excluir] && !$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, "", '100%');
	}
	else {
	
		# Buscar avalia��o
		$consulta = buscaFeedbackTicket( $registro, 'id','igual','id' );

		if($consulta && contaConsulta($consulta)>0) {
			$matriz[id]=resultadoSQL($consulta, 0, 'id');
			$matriz[idTicket]=resultadoSQL($consulta, 0, 'idTicket');
			$matriz[idUsuario]=resultadoSQL($consulta, 0, 'idUsuario');
			$matriz[data]=resultadoSQL($consulta, 0, 'data');
			$matriz[nota]=resultadoSQL($consulta, 0, 'nota');
			$matriz[comentario]=resultadoSQL($consulta, 0, 'comentario');
			
				
			if(!$matriz[bntExcluir]) {					
				# Form de exclus�o
				$opcListar = "
					<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr>
					 <td width=\"50%\" align=\"left\" class=\"tabtitulo\">"._("Delete Feedback")."<td>
					 <td width=\"50%\" align=\"right\">
				";
				$opcListar.= ( !$sessLogin[login] ) 
					? "&nbsp;" 
					: htmlMontaOpcao("<a href=\"?modulo=ticket&sub=feedback&acao=listar&registro=$matriz[idTicket]\" class=\"titulo\">"._("List")."</a>",'listar');
				$opcListar.= "
					 </td>
					</tr></table>
				";
				
				novaTabela2($opcListar, 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
					novaLinhaTabela($corFundo, '100%');
					$texto="			
						<form method=post name=matriz action=index.php>
						<input type=hidden name=modulo value=$modulo>
						<input type=hidden name=sub value=$sub>
						<input type=hidden name=acao value=$acao>
						<input type=hidden name=registro value=$registro>
					";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
					fechaLinhaTabela();
					
					novaLinhaTabela($corFundo, '100%');
						itemLinhaForm('&nbsp;', 'left', 'top', $corFundo, 2, 'tabfundo1');
					fechaLinhaTabela();
			
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Grade:")." </b>";
						htmlFechaColuna();
						itemLinhaForm($matriz[nota], 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Commentary:")." </b>";
						htmlFechaColuna();
						itemLinhaForm(nl2br($matriz[comentario]), 'left', 'top', $corFundo, 0, 'tabfundo3');
					fechaLinhaTabela();
					
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "<b class=bold>"._("Date:")." </b>";
						htmlFechaColuna();
						itemLinhaForm(converteData($matriz[data],'banco','form'), 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
					novaLinhaTabela($corFundo, '100%');
						htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
							echo "&nbsp;";
						htmlFechaColuna();
						$texto="<input type=submit name=matriz[bntExcluir] value="._("Delete Feedback")." class=submit>";
						itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					
				fechaTabela();

				echo "<br />";
				novaTabela2SH( 'left', '100%', 0, 0, 0, $corFundo, $corBorda, 0 );
				htmlAbreLinha( $corFundo );
				htmlAbreColuna('100%', 'left', $corFundo, 0, 'normal10');
					mostraTicket( $matriz[idTicket], 0 );
				htmlFechaColuna();
				htmlFechaLinha();
				fechaTabela();

			}
			else {
				# Excluir
				$grava = dbTicketFeedback($matriz, 'excluir');
				
				if(!$grava) {
					$msg = _("Error deleting Feedback of this Ticket");
					avisoNOURL( _("Warning: An error has been ocurred"), $msg, '100%' );
				}
				
				# Listagem de Feedbacks do Ticket
				listarFeedback($modulo, $sub, 'listar', $matriz, $matriz[idTicket]);
			}		
		}	
	}	
}

/**
 * Fun��o que altera feedback do Ticket
 *
 * @param str $modulo
 * @param str $sub
 * @param str $acao
 * @param str $registro
 * @param str $matriz
 * @return void
 */
function alteraFeedback( $modulo, $sub, $acao, $matriz, $registro ) {

	global $corFundo, $corBorda, $tb, $html, $sessLogin;

	# Buscar informa��es sobre usuario - permiss�es
	$permissao = buscaPermissaoUsuario( $sessLogin[login] );

	if(!$permissao[excluir] && !$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, "", '100%');
	}
	else {
		# Buscar avalia��o
		$consulta = buscaFeedbackTicket( $registro, 'id','igual','id' );

		if($consulta && contaConsulta($consulta)>0) {
			$matriz[id]=resultadoSQL($consulta, 0, 'id');
			$matriz[idTicket]=resultadoSQL($consulta, 0, 'idTicket');
			$matriz[idUsuario]=resultadoSQL($consulta, 0, 'idUsuario');
						
			$sessLogin[modulo] = $modulo;
			$sessLogin[sub]  = $sub;
			$sessLogin[acao] = $acao;
				
			if( !$matriz[bntConfirmar] || $mensagem ) {
				$matriz[data]=resultadoSQL($consulta, 0, 'data');
				$matriz[nota]=resultadoSQL($consulta, 0, 'nota');
				$matriz[comentario]=resultadoSQL($consulta, 0, 'comentario');			
				mostraFormTicketFeedback(_("Change Feedback"), $modulo, $sub, $acao, $registro, $matriz);
			} #fecha form
			elseif( $matriz[bntConfirmar] && $matriz[nota] <= 10 && $matriz[nota] >= 0 ) {

				# Conferir campos
				if( $matriz[nota] ) {
		
					$matriz[idUsuario] =  buscaIDUsuario( $sessLogin[login], 'login', 'igual', 'login' );
					$grava = dbTicketFeedback( $matriz, 'alterar' );
					
					if($grava) {
						$msg = _("Data Recorded Success full!");
						$url = "?modulo=$modulo&sub=$sub&acao=$acao";
						avisoNOURL( _("Warning"), $msg, 400 );
						echo "<br />";
						listarFeedback($modulo, $sub, "listar", $matriz, $matriz[idTicket]);				
					}
				}
				else {
					# acusar falta de parametros			
					$msg = _("Lack of necessary parameters.")._("Fill the required fields and try again ");
					avisoNOURL( _("Warning: An error has been ocurred"), $msg, '100%' );
					echo "<br />";
					mostraFormTicketFeedback(_("Change Feedback"), $modulo, $sub, $acao, $registro, $matriz);
				}	
			}
		}
	}
}

###########################################################################################################################################
###############################																			  #################################
#############################################		SISTEMA DE LOGIN PARA USUARIO_EMPRESA		###########################################
###############################																			  #################################
###########################################################################################################################################

/**
 * Fun��o construtora
 *
 * @param str $modulo
 * @param str $sub
 * @param str $acao
 * @param str $registro
 * @param str $matriz
 */
function ticketFeedbackUE( $modulo, $sub, $acao, $registro, $matriz ) {
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	if( $acao == 'incluirUE' ) {
		formTicketFeedbackUE( $modulo, $sub, $acao, $registro, $matriz );
	}
	elseif( $acao == "listarUE" ) {
		listarFeedbackUE( $modulo, $sub, $acao, $matriz, $registro );
	}

}

/**
 * Fun��o que adiciona coment�rio ao Ticket
 *
 * @param str $modulo
 * @param str $sub
 * @param str $acao
 * @param str $registro
 * @param str $matriz
 * @return void
 */
function formTicketFeedbackUE( $modulo, $sub, $acao, $registro, $matriz ) {

	global $corFundo, $corBorda, $tb, $html, $sessLogin;
	
	if( $registro ) {
		# Procurar Ticket a partir de protocolo
		
		if( $modulo == "ticketUE" ) {
			$idTicket  = $registro;
			$consulta  = buscaTicket( addslashes( $registro ), 'id', 'igual', 'id' );
			$idUsuario = resultadoSQL( $consulta, 0, 'idUsuario' );
		}
		else {
			$consulta = buscaTicket( addslashes( $registro ), 'protocolo', 'igual', 'protocolo' );
			$idTicket = resultadoSQL( $consulta, 0, 'id' );
			$idUsuario = resultadoSQL( $consulta, 0, 'idUsuario' );	
		}
		
		$matriz[idTicket] = $idTicket;
		$sessLogin[modulo] = $modulo;
		$sessLogin[sub]  = $sub;
		$sessLogin[acao] = $acao;
	}
	if( $acao == 'incluirUE' ) {
		
		if( !$matriz[bntConfirmar] || $mensagem ) {

			mostraFormTicketFeedback( _('Send Feedback'), $modulo, $sub, $acao, $registro, $matriz );
		
		} #fecha form
		elseif( $matriz[bntConfirmar] && $matriz[nota] && $matriz[nota] <= 10 && $matriz[nota] >= 0 ) {

			$matriz[idTicket] = $idTicket;
			$matriz[protocolo] = $registro;
			$matriz[idUsuario] = buscaIDUsuario( 'guest', 'login', 'igual', 'login' );

			$grava = dbTicketFeedback( $matriz, 'incluir' );
			
			if($grava) {
				
				echo "<br />";
				if($sessLogin[login]) {
					listarFeedbackUE($modulo, $sub, "listarUE", $matriz, $idTicket);
					$url = "?modulo=$modulo&sub=$sub&acao=$acao";
					echo "<br />";
					$msg = _("Record was written success full! Thanks for your collaboration!");
					avisoNOURL( _("Warning"), $msg, '100%' );
				}
//				else {
//					$msg = _("Record was written success full! Thanks for your collaboration!");
//					avisoNOURL( _("Warning"), $msg, '100%' );
//					echo "<p align=\"center\"><input type=\"button\" value=\""._("Close Window")."\" onclick=\"window.close();\" /></p>";
//				}
				mailTicket( $idTicket, $idUsuario, 'verfeedback' );
			}
		}
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			
			$msg = _("Lack of necessary parameters."). _("Fill the required fields and try again ");
			avisoNOURL( _("Warning: An error has been ocurred"), $msg, '100%' );
			echo "<br />";
			mostraFormTicketFeedback( _('Send Feedback'), $modulo, $sub, $acao, $registro, $matriz );
		}	

	}
	else {
		if( $registro ) {
			# Ticket n�o pode ser visualizado
			$msg = _("Ticket cannot be found");
			avisoNOURL( _("Feedback View"), $msg, '100%' );
		}
	}
}


/**
 * Listagem de Avalia��es
 *
 * @param str $modulo
 * @param str $sub
 * @param str $acao
 * @param str $matriz
 * @param str $registro
 * @return void
 */
function listarFeedbackUE( $modulo, $sub, $acao, $matriz, $registro ) {
	global $html, $corFundo, $corBorda, $sessLogin;
	if( !$sessLogin[login] ) {
		$msg = _("To list the feedbacks you must be logged in!");
		aviso( _("Warning: An error has been ocurred"), $msg, "javascript:history:back(-1)", '100%' );
	}
	else {

		$contadorNotas = 0;
		$acumuladorNotas = 0;
		
//		$perfil = dadosPerfilUsuario( buscaIDUsuario( $sessLogin[login], 'login', 'igual', 'id' ) );
//	
//		$sqlOPC = ( $perfil[ordemComentarios] == 'D' ) ? "DESC" : "";
	
		$consulta = buscaFeedbackTicket( $registro, 'idTicket', 'igual', "data $sqlOPC" );
		
		$opcListar = "
			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr>
			 <td width=\"50%\" align=\"left\" class=\"tabtitulo\">"._("List Feedback")."<td>
			 <td width=\"50%\" align=\"right\">
		";
		$opcListar.= htmlMontaOpcao("<a href=\"?modulo=ticketUE&sub=feedbackUE&acao=incluirUE&registro=$registro\" class=\"titulo\">"._("Add Feedback")."</a>",'feedback');
		$opcListar.= "
			 </td>
			</tr></table>
		";
		
		novaTabela2( $opcListar, 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2 );
	
			if( !$consulta || contaConsulta( $consulta ) == 0 ) {
				novaLinhaTabela( $corFundo, '100%' );
					itemLinhaNOURL( _("No feedback was posted for this Ticket"), 'left', $corFundo, 2, 'txtaviso' );
				fechaLinhaTabela();
			}
			else {
				for( $i = 0; $i < contaConsulta( $consulta ); $i++ ) {
					$usuario  = resultadoSQL( $consulta, $i, 'idUsuario' );
					$id       = resultadoSQL( $consulta, $i, 'id' );
					$idTicket = resultadoSQL( $consulta, $i, 'idTicket' );
					$data     = converteData( resultadoSQL( $consulta, $i, 'data' ), 'banco', 'formdata' );
					$hora     = converteData( resultadoSQL( $consulta, $i, 'data' ), 'banco', 'formhora' );
					$texto    = resultadoSQL( $consulta, $i, 'comentario' );
					$nota     = resultadoSQL( $consulta, $i, 'nota' );
					$acumuladorNotas += $nota; 
					# Informa��es do usuario
					$consultaUsuario = buscaUsuarios( $usuario, 'id', 'igual', 'id' );
					$loginUsuario = resultadoSQL( $consultaUsuario, 0, 'login' );

					# Pegar o nome do grupo de acordo com o perfil				
					$nomeGrupo = comentarNomeGrupo( resultadoSQL( $consultaUsuario, 0, 'id' ) );
					if( $sessLogin['isCompanyUser'] ){
						$nomeGrupo = comentarNomeGrupo( resultadoSQL( $consultaUsuario, 0, 'id' ), 'sim' );
					}
					
					# Atribuir Valores
					$fundo  = $i % 2 + 1;
					$fundo2 = $i % 2 + 3;
					
					$tmpData = converteData( resultadoSQL( $consulta, $i, 'data' ), 'banco', 'timestamp' );
					novaLinhaTabela( $corFundo, '100%' );
//						if( $modulo == 'ticketUE' ) {
//							$opcAdicional = "<a href=\"?modulo=ticketUE&sub=feedbackUE&acao=excluirUE&registro=$id\"><img title=\""._("Delete")."\" src=\"".$html[imagem][fechar]."\" border=\"0\" align=\"right\" /></a>";
//							$opcAdicional.= "<a href=\"?modulo=ticketUE&sub=feedbackUE&acao=alterarUE&registro=$id\"><img title=\""._("Change")."\" src=\"".$html[imagem][alterar]."\" border=\"0\" align=\"right\" /></a>";
//						}
//						else {
							$opcAdicional = "";
//						}
					
						$info = "$opcAdicional
						<b>"._("Posted By:")."</b>" . "&nbsp;" . ( empty( $nomeGrupo ) ? _($loginUsuario) : $nomeGrupo ) . "<br />
						<b>"._("Date:")."</b> $data<br />
						<b>"._("Hour:")."</b> $hora<br />
						";
						$corpo = "<b>"._("Grade:")." $nota</b><br>" . nl2br( $texto );
						itemLinhaTabela( $info, 'left', '30%', "tabfundo$fundo" );
						itemLinhaNOURL( $corpo, 'left', $corFundo, 0, "tabfundo$fundo2" );
					fechaLinhaTabela();
				}
				novaLinhaTabela( $corFundo, '100%');
					$media = number_format($acumuladorNotas / contaConsulta( $consulta ), 2, ',', '.');
					itemLinhaNOURL(_("Average Grade:")." <b>$media</b>", "right", $corFundo, 2, "tabfundo1");
				fechaLinhaTabela();		
			}
		fechaTabela();	
	
		echo "<br />";
		
		novaTabela2SH( 'left', '100%', 0, 0, 0, $corFundo, $corBorda, 0 );
		htmlAbreLinha( $corFundo );
		htmlAbreColuna('100%', 'left', $corFundo, 0, 'normal10');
			mostraTicketUE( $registro, 0 );
		htmlFechaColuna();
		htmlFechaLinha();
		fechaTabela();
	}
}


?>