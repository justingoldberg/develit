<?

################################################################################
#  Data de cria��o: 15/05/2006
# Ultima altera��o: 15/05/2006
#    Altera��o No.: 001
#
# Fun��o:
#    Painel - Fun��es para consulta de programas


/**
 * Busca programas
 *
 * @param unknown_type $texto
 * @param unknown_type $campo
 * @param unknown_type $tipo
 * @param unknown_type $ordem
 * @return unknown
 */
function buscaProgramas( $texto, $campo, $tipo, $ordem ) {
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if( $tipo == 'todos' ) {
		$sql = "SELECT * FROM $tb[Programas] ORDER BY $ordem";
	}
	elseif( $tipo == 'contem' ) {
		$sql = "SELECT * FROM $tb[Programas] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif( $tipo == 'igual' ) {
		$sql = "SELECT * FROM $tb[Programas] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif( $tipo == 'custom' ) {
		$sql = "SELECT * FROM $tb[Programas] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if( $sql ){
		$consulta = consultaSQL( $sql, $conn );
		# Retornvar consulta
		return( $consulta );
	}
	else {	
		# Mensagem de aviso
		$msg="Consulta n�o pode ser realizada por falta de par�metros";
		$url="?modulo=$modulo&sub=$sub";
		aviso( "Aviso: Ocorr�ncia de erro", $msg, $url, 760 );
	}
	
} # fecha fun��o de busca

/**
 * Lista os programas relacionados a maquina
 *
 * @param unknown_type $idMaquina
 * @return unknown
 */
function verProgramas( $idMaquina ){
	
	# busca os programas
	$dados = buscaProgramas( $idMaquina, 'idMaquina', 'igual', 'nome' );
	
	$retorno = "";
	
	# se encontrado um ou mais programas, ent�o eles s�o listados
	if( mysql_num_rows( $dados ) > 0 ) {
		while($programa = mysql_fetch_object( $dados ) ){
			$retorno .= " - " . $programa->nome . " - Vers�o: " . $programa->versao . "<br />";
		}
	}


	return ( $retorno ? $retorno : false );
}

?>