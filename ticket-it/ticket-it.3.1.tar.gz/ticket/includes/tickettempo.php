<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 08/03/2004
# Ultima altera��o: 18/08/2006
#    Altera��o No.: 003
#
# Fun��o:
#    Painel - Fun��es para processos de tickets

# Controle tempo por ticket
function tickettempo($modulo, $sub, $acao, $registro, $matriz) {
	
	global $sessTempo;

	$data=dataSistema();
	# Iniciar Sess�o

	$matriz[ticket]=$registro;
	
	if($acao == 'listar') {
		# Listar Atendimentos do ticket
		listarTempoTicket($matriz[ticket]);
		echo "<br>";
		mostraTicket($matriz[ticket], 0);
		
	}
	elseif($acao=='excluir' || $acao=='alterar') {
		$matriz[ticket]=idTicketTicketTempo($registro);
		mostraTicketTempo($matriz, $registro, $matriz[ticket],$acao);
		echo "<br>";
		# Buscar ID do Tickete
		mostraTicket($matriz[ticket],0);
	}
	elseif(!$acao || $acao=='adicionar' || $acao=='atualizar') {
		
		if((!$matriz[bntConfirmar] && !$matriz[bntFinalizar] && $acao!='atualizar') || $matriz[bntIniciar] ) {
			$sessTempo[dtInicial][$registro]=$data[timestamp];
			$matriz[tempoatendimento]=_("Initiated attendance");
		}
		
		# Iniciar refresh
		if($acao=='atualizar' && $sessTempo[dtInicial][$registro] != $data[timestamp]) {
			$tmpTempo=converteData($data[timestamp]-$sessTempo[dtInicial][$registro],'timestamp','formhora');
			//echo "<span class=txtaviso>Tempo de atendimento: $tmpTempo</span><br>";
			$matriz[tempoatendimento]=$tmpTempo;
		}
		echo "<meta http-equiv=refresh content=10;URL=?modulo=$modulo&sub=tempoticket&acao=atualizar&registro=$registro&$matriz[bntIninciar]=''>";
		
		if($matriz[bntFinalizar]) {
			$sessTempo[dtFinal][$registro]=$data[timestamp];
			$matriz[duracao]=$sessTempo[dtFinal][$registro]-$sessTempo[dtInicial][$registro];
			$grava=dbFinalizacoesTicket($matriz, 'incluir');
			$sessTempo[dtInicial][$registro]=$data[timestamp];
			
			# Fechar janela
		}
		
		if($matriz[bntConfirmar] && $matriz[tempo]) {
			$matriz[duracao]=$matriz[tempo] * 60;
			$grava=dbFinalizacoesTicket($matriz, 'incluir');
		}
		elseif($matriz[bntConfirmar]) {
			$tmpTempo=converteData($data[timestamp]-$sessTempo[dtInicial][$registro],'timestamp','formhora');
			$matriz[tempoatendimento]=_("Inform time to add!.")."&nbsp;"._("Time of attendance:")." $tmpTempo";
		}
		
		if($grava) {
			$matriz[tempoatendimento]=_("Added time:")."&nbsp;".converteData($matriz[duracao],'timestamp','formhora');
		}
		
		# Mostrar Form de inclus�o de tempo
		formTicketTempo($modulo, $sub, $acao, $registro, $matriz);
		
		echo "<br>";
		mostraTicket($registro,0);
	}

}

# Formul�rio de Inclus�o de Tempo
function formTicketTempo($modulo, $sub, $acao, $registro, $matriz) {

	global $corFundo, $corBorda, $sessLogin;
	
	$data=dataSistema();
	
	# Motrar tabela de busca
	$opcListar="
		<table border=0 cellpadding=0 cellspacing=0 width=100%>
		<tr><td width=50% align=left class=tabtitulo>"._("Ticket in process")."<td><td width=50% align=right>
	";
	$opcListar.=htmlMontaOpcao("<a href=?modulo=ticket&sub=tempoticket&acao=listar&registro=$registro class=titulo>"._("List")."</a>",'listar');
	$opcListar.="</td></tr></table>";
	
	novaTabela2("$opcListar","left", '100%', 0, 2, 1, $corFundo, $corBorda, 4);
		#fim das opcoes adicionais
		novaLinhaTabela($corFundo, '100%');
		$texto="			
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=adicionar>
			<input type=hidden name=registro value=$registro>";
			itemLinhaNOURL($texto, 'right', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();

		novaLinhaTabela($corFundo, '100%');
			itemLinhaTMNOURL('<b class=bold10>'._("Time of Attendance:").'</b>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
			# Buscar Total de Tempo registrado
			$texto=$matriz[tempoatendimento];
			itemLinhaForm("<span class=txtaviso>$texto</span>", 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		
		novaLinhaTabela($corFundo, '100%');
			itemLinhaTMNOURL('<b class=bold10>'._("Registered time:").'</b>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
			# Buscar Total de Tempo registrado
			$texto=converteData(tempoAtendimento($registro),'timestamp','formhora');
			itemLinhaForm("<span class=txtaviso>$texto</span>", 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		
		novaLinhaTabela($corFundo, '100%');
			itemLinhaTMNOURL('<b class=bold10>'._("Minutes:").'</b>', 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
			$texto="<input type=text name=matriz[tempo] size=5>&nbsp;";
			$texto.="&nbsp;&nbsp;<input type=submit name=matriz[bntConfirmar] value="._("Add")." class=submit2>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		
		novaLinhaTabela($corFundo, '100%');
				( $matriz[expediente] != 'N' ? $check = "CHECKED" : $check1 = "CHECKED" );
				itemLinhaTMNOURL("<b class=bold10>"._("Service period")."</b>",  'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
				$texto = "<input id=durante type=radio name=matriz[expediente] value=S $check >" .
						 	"<label for=durante>"._("During expedient time")."</label>&nbsp;" ;
				$texto .= "&nbsp;<input id=fora type=radio name=matriz[expediente] value=N $check1 >" .
						 	"<label for=fora>"._("Out of expedient time")."</label>" ;
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	
		novaLinhaTabela($corFundo, '100%');
			$texto="<input type=submit name=matriz[bntIniciar] value="._("Start Attendance")." class=submit>";
			$texto.="&nbsp;&nbsp;<input type=submit name=matriz[bntFinalizar] value="._("Finish Attendance")." class=submit2>";
			itemLinhaForm($texto, 'center', 'top', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();
}


# Somar tempo de atendimento registrado
function tempoAtendimento($idTicket) {
	global $conn, $tb;
	
	if(is_numeric($idTicket)) {
		$sql="
			SELECT
				sum(segundos) segundos
			FROM
				$tb[TicketFinalizacoes]
			WHERE
				idTicket=$idTicket
		";
		
		$consulta=consultaSQL($sql, $conn);
		
		if($consulta && contaConsulta($consulta)>0) {
			$retorno=resultadoSQL($consulta,0,'segundos');
			
			if(!is_numeric($retorno)) $retorno=0;
		}
		else {
			$retorno=0;
		}
		
		return($retorno);
	}
}


# Listar tempos de atendimeto
function listarTempoTicket($idTicket) {
	global $conn, $tb, $corBorda, $corFundo, $sessLogin;
	
	$consulta=buscaRegistro($idTicket, 'idTicket', 'igual', '', "$tb[TicketFinalizacoes]");
	
	# Motrar tabela de busca
	$opcListar="
		<table border=0 cellpadding=0 cellspacing=0 width=100%>
		<tr><td width=50% align=left class=tabtitulo>"._("Attendances")."<td><td width=50% align=right>
	";
	$opcListar.=htmlMontaOpcao("<a href=?modulo=ticket&sub=tempoticket&registro=$idTicket class=titulo>"._("Assist")."</a>",'relogio');
	$opcListar.="</td></tr></table>";
	
	novaTabela2("$opcListar","left", '100%', 0, 2, 1, $corFundo, $corBorda, 5);
	novaLinhaTabela($corFundo, '100%');
		itemLinhaTMNOURL('<b>'._("Date").'</b>', 'center', 'middle', '20%', $corFundo, 0, 'tabfundo1');
		itemLinhaTMNOURL('<b>'._("User").'</b>', 'center', 'middle', '20%', $corFundo, 0, 'tabfundo1');
		itemLinhaTMNOURL('<b>'._("Time").'</b>', 'center', 'middle', '30%', $corFundo, 0, 'tabfundo1');
		itemLinhaTMNOURL('<b>'._("Expedient").'</b>', 'center', 'middle', '10', $corFundo, 0, 'tabfundo1');
		itemLinhaTMNOURL('<b>'._("Options").'</b>', 'center', 'middle', '30%', $corFundo, 0, 'tabfundo1');
	fechaLinhaTabela();

	if($consulta && contaConsulta($consulta)>0) {
		# Listar
		for($a=0;$a<contaConsulta($consulta);$a++) {
			
			$id=resultadoSQL($consulta, $a, 'id');
			$idTicket=resultadoSQL($consulta, $a, 'idTicket');
			$idUsuario=resultadoSQL($consulta, $a, 'idUsuario');
			$data=resultadoSQL($consulta, $a, 'data');
			$segundos=resultadoSQL($consulta, $a, 'segundos');
			$expediente=resultadoSQL($consulta, $a, 'expediente');
			
			$opc=htmlMontaOpcao("<a class=normal8 href=?modulo=ticket&sub=tempoticket&acao=alterar&registro=$id>"._("Change")."</a>",'alterar');
			$opc.=htmlMontaOpcao("<a class=normal8 href=?modulo=ticket&sub=tempoticket&acao=excluir&registro=$id>"._("Delete")."</a>",'excluir');
			
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL(converteData($data,'banco','form'), 'center', 'middle', '20%', $corFundo, 0, 'normal8');
				itemLinhaTMNOURL(buscaLoginUsuario($idUsuario,'id','igual','id'), 'center', 'middle', '20%', $corFundo, 0, 'normal10');
				itemLinhaTMNOURL(converteData($segundos,'timestamp','formhora'), 'center', 'middle', '30%', $corFundo, 0, 'normal10');
				itemLinhaTMNOURL($expediente, 'center', 'middle', '10', $corFundo, 0, 'normal10');
				itemLinhaTMNOURL($opc, 'left', 'middle', '30%', $corFundo, 0, 'normal10');
			fechaLinhaTabela();

		}
	}
	else {
		# sem registros
		novaLinhaTabela($corFundo, '100%');
				itemLinhaTMNOURL(_("No attendance records was found"), 'center', 'middle', '100%', $corFundo, 5, 'txtaviso');
			fechaLinhaTabela();
	}
	
	
	fechaTabela();
}


# Mostrar Ticket Tempo - Form de Exclus�o e Altera��o
function mostraTicketTempo($matriz, $id, $idTicket, $acao) {
	
	global $corFundo, $corBorda,$sessLogin, $tb;
	
	# Mostar informa��es sobre Servidor
	$consulta=buscaRegistro($id, 'id','igual','',"$tb[TicketFinalizacoes]");

	if($consulta && contaConsulta($consulta)>0) {
		
		$id=resultadoSQL($consulta, 0, 'id');
		$idTicket=resultadoSQL($consulta, 0, 'idTicket');
		$data=resultadoSQL($consulta, 0, 'data');
		$segundos=resultadoSQL($consulta, 0, 'segundos');
		$expediente=resultadoSQL($consulta, 0, 'expediente');
	
		#nova tabela para mostrar informa��es
		if($acao=='excluir') {
			if($matriz[bntConfirmar] && $id) {
				# Excluir
				$matriz[id]=$id;
				dbFinalizacoesTicket($matriz,'excluir');
				# Listar
				listarTempoTicket($idTicket);
			}
			else {
				
				# Motrar tabela de busca
				$opcListar="
					<table border=0 cellpadding=0 cellspacing=0 width=100%>
					<tr><td width=50% align=left class=tabtitulo>"._("Delete Attendance")."<td><td width=50% align=right>
				";
				$opcListar.=htmlMontaOpcao("<a href=?modulo=ticket&sub=tempoticket&acao=alterar&registro=$id class=titulo>"._("Change")."</a>",'alterar');
				$opcListar.=htmlMontaOpcao("<a href=?modulo=ticket&sub=tempoticket&acao=listar&registro=$idTicket class=titulo>"._("List")."</a>",'listar');
				$opcListar.=htmlMontaOpcao("<a href=?modulo=ticket&sub=tempoticket&registro=$idTicket class=titulo>"._("Assist")."</a>",'relogio');
				$opcListar.="</td></tr></table>";
				
				novaTabela2("$opcListar","left", '100%', 0, 2, 1, $corFundo, $corBorda, 4);
					novaLinhaTabela($corFundo, '100%');
					$texto="			
						<form method=post name=matriz action=index.php>
						<input type=hidden name=modulo value=ticket>
						<input type=hidden name=sub value=tempoticket>
						<input type=hidden name=acao value=excluir>
						<input type=hidden name=registro value=$id>";
						itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						itemLinhaTMNOURL("<b>"._("Date:")."</b>", 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
						itemLinhaTMNOURL(converteData($data,'banco','form'), 'left', 'middle', '70%', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						itemLinhaTMNOURL("<b>"._("Time:")."</b>", 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
						itemLinhaTMNOURL(converteData($segundos,'timestamp','formhora'), 'left', 'middle', '70%', $corFundo, 0, 'tabfundo1');
					novaLinhaTabela($corFundo, '100%');
						itemLinhaTMNOURL("<b>"._("Expedient:")."</b>", 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
						itemLinhaTMNOURL($expediente, 'left', 'middle', '70%', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						$texto="<input type=submit name=matriz[bntConfirmar] value="._("Delete")." class=submit>";
						itemLinhaForm($texto, 'center', 'top', $corFundo, 2, 'tabfundo1');
					fechaLinhaTabela();
				fechaTabela();
			}
		}
		elseif($acao=='alterar') {
			if($matriz[bntConfirmar] && $id && is_numeric($matriz[duracao]) && $matriz[data]) {
				# Alterar
				$matriz[id]=$id;
				$matriz[duracao]=($matriz[duracao]*60);
				$matriz[data]=converteData(formatarData($matriz[data]),'form','bancodata');
				dbFinalizacoesTicket($matriz,'alterar');
				# Listar
				listarTempoTicket($idTicket);
			}
			else {
				# Motrar tabela de busca
				$opcListar="
					<table border=0 cellpadding=0 cellspacing=0 width=100%>
					<tr><td width=50% align=left class=tabtitulo>"._("Delete Attendance")."<td><td width=50% align=right>
				";
				$opcListar.=htmlMontaOpcao("<a href=?modulo=ticket&sub=tempoticket&acao=excluir&registro=$id class=titulo>"._("Delete")."</a>",'excluir');
				$opcListar.=htmlMontaOpcao("<a href=?modulo=ticket&sub=tempoticket&acao=listar&registro=$idTicket class=titulo>"._("List")."</a>",'listar');
				$opcListar.=htmlMontaOpcao("<a href=?modulo=ticket&sub=tempoticket&registro=$idTicket class=titulo>"._("Assist")."</a>",'relogio');
				$opcListar.="</td></tr></table>";
				
				novaTabela2("$opcListar","left", '100%', 0, 2, 1, $corFundo, $corBorda, 4);
					novaLinhaTabela($corFundo, '100%');
					$texto="			
						<form method=post name=matriz action=index.php>
						<input type=hidden name=modulo value=ticket>
						<input type=hidden name=sub value=tempoticket>
						<input type=hidden name=acao value=alterar>
						<input type=hidden name=registro value=$id>";
						itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						itemLinhaTMNOURL("<b>"._("Date:")."</b>", 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
						$data=converteData($data,'banco','formdata');
						$texto="<input type=text size=10 name=matriz[data] value='$data' onBlur=verificaData(this.value,4)>";
						itemLinhaTMNOURL($texto, 'left', 'middle', '70%', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						itemLinhaTMNOURL("<b>"._("Minutes:")."</b>", 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
						$minutos=intval($segundos/60);
						$texto="<input type=text name=matriz[duracao] size=5 value='$minutos'>";
						itemLinhaTMNOURL($texto, 'left', 'middle', '70%', $corFundo, 0, 'tabfundo1');
					novaLinhaTabela($corFundo, '100%');
						itemLinhaTMNOURL("<b>"._("Expedient:")."</b>", 'right', 'middle', '30%', $corFundo, 0, 'tabfundo1');
						itemLinhaTMNOURL(formSelectSimNao($expediente, 'expediente','form'), 'left', 'middle', '70%', $corFundo, 0, 'tabfundo1');
					fechaLinhaTabela();
					novaLinhaTabela($corFundo, '100%');
						$texto="<input type=submit name=matriz[bntConfirmar] value="._("Change")." class=submit>";
						itemLinhaForm($texto, 'center', 'top', $corFundo, 2, 'tabfundo1');
					fechaLinhaTabela();
				fechaTabela();
			}
		}
	}
}


# Buscar ID TicketTempo
function idTicketTicketTempo($id) {
	
	global $tb;
	
	$consulta=buscaRegistro($id, 'id', 'igual','',"$tb[TicketFinalizacoes]");
	
	if($consulta && contaConsulta($consulta)) {
		$idTicket=resultadoSQL($consulta, 0, 'idTicket');
		
		return($idTicket);
	}
	else {
		return(0);
	}
	
}

?>