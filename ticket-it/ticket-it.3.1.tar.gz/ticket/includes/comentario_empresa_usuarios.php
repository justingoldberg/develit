<?

# Fun��o para grava��o em banco de dados
function dbComentarioEmpresaUsuarios($matriz, $tipo) {

	global $conn, $tb, $modulo, $sub, $acao;

	$data=dataSistema();

	# Sql de inclus�o
	if( $tipo == 'relacionar' ) {

		# Checar se ticket j� esta relacionado
		if( isCommentRelatedWithCompanyUser( $matriz['idComentario']) ) {
			$sql = "UPDATE {$tb['ComentarioEmpresaUsuarios']} ".
				"SET idComentario='{$matriz['idComentario']}', idEmpresaUsuario='{$matriz['idEmpresaUsuario']}'".
				"WHERE idComentario='".(int)$matriz['idComentario']."'";
		}
		else {
			$sql =	"INSERT INTO ".
						"{$tb['ComentarioEmpresaUsuarios']} ".
					"VALUES ".
					"(0, '{$matriz['idComentario']}', '{$matriz['idEmpresaUsuario']}');";
		}
	} #fecha inclusao
	elseif( $tipo=='excluir' ) {
		$sql="DELETE FROM {$tb['ComentarioEmpresaUsuarios']} WHERE idComentario='".(int)$matriz['idComentario']."'";
	}
	
	if( $sql ) {
		$retorno=consultaSQL($sql, $conn);
		return($retorno);
	}

} # fecha fun��o de grava��o em banco de dados

function buscaComentarioEmpresaUsuario( $texto, $campo, $tipo, $ordem ){
	global $tb;
	return buscaRegistro($texto, $campo, $tipo, $ordem, $tb['ComentarioEmpresaUsuarios']);
}

/**
 * Checa se comentario j� possui relacionamento com algum us�rio da empresa
 *
 * @param $idComentario
 * @return boolean
 */
function isCommentRelatedWithCompanyUser( $idComentario ) {
	$consulta=buscaComentarioEmpresaUsuario($idComentario, 'idComentario', 'igual','id');
	return ( $consulta && contaConsulta($consulta) > 0 );
}

?>