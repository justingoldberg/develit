<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 20/01/2005
# Ultima altera��o: 20/01/2005
#    Altera��o No.: 001
#
# Fun��o:
#    Fun��es para manipula��o de banco de dados - Ticket-Empresa


# Fun��o para grava��o em banco de dados
function dbTicketEmpresa($matriz, $tipo) {

	global $conn, $tb, $modulo, $sub, $acao, $sessLogin;

	$data=dataSistema();

	# Sql de inclus�o
	if( $tipo=='relacionar' ) {

		# Checar se ticket j� esta relacionado
		if(checkTicketRelacionado($matriz[idTicket])) {
			$sql="
				UPDATE 
					$tb[TicketEmpresa] 
				SET
					idMaquina='$matriz[maquina]', 
					idEmpresa='$matriz[empresa]', 
					titulo='$matriz[titulo]',
					data='$matriz[data]'
				WHERE 
					idTicket='$matriz[idTicket]'";
		}
		else {
			$sql="
				INSERT INTO 
					$tb[TicketEmpresa] 
				VALUES (0,
					'$matriz[maquina]',
					'$matriz[empresa]',
					'$matriz[idTicket]',
					'$matriz[titulo]',
					'$data[dataBanco]'
				)";
		}
	} #fecha inclusao
	elseif( $tipo=='excluir' ) {
		$sql="DELETE FROM $tb[TicketEmpresa] WHERE idTicket='$matriz[idTicket]'";
	}
	
	if( $sql ) {
		$retorno = consultaSQL($sql, $conn);
		
		// by nash 2007-04-16 - se for de um usuario de empresa, ent�o o mesmo � relacionado.
		if( $retorno && $sessLogin['isCompanyUser'] ){
			$userEmpresa = buscaUsuariosEmpresas( $sessLogin['login'], 'login', 'igual', 'id' );
			if( $userEmpresa && contaConsulta($userEmpresa) ) {
				$dados['idTicket'] = $matriz['idTicket'];
				$dados['idEmpresaUsuario'] = resultadoSQL($userEmpresa, 0, 'id');
				dbTicketEmpresaUsuarios( $dados, $tipo );
			}
		}
		return($retorno);
	}

} # fecha fun��o de grava��o em banco de dados



# Fun��o para busca de tickets da empresa
function buscaTicketEmpresa($texto, $campo, $tipo, $ordem){
	global $conn, $tb, $corFundo, $modulo, $sub;

	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[TicketEmpresa] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[TicketEmpresa] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[TicketEmpresa] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[TicketEmpresa] WHERE $texto ORDER BY $ordem";
	}

	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}

} # fecha fun��o de busca



/**
 * Checar se ticket j� possui relacionamento
 *
 * @param $idTicket
 * @return 0=n�o relacionado 1=relacionado
 */
function checkTicketRelacionado($idTicket) {

	$consulta=buscaTicketEmpresa($idTicket, 'idTicket', 'igual','id');

	if($consulta && contaConsulta($consulta)>0) {
		return(1);
	}
	else {
		return(0);
	}
}



/**
 * Retorna todos os campos do BD para o ticket informado, caso esteja relacionado
 *
 * @param $idTicket
 * @return matriz contendo os campos do BD
 */
function dadosTicketEmpresa($idTicket) {
	$consulta=buscaTicketEmpresa($idTicket, 'idTicket', 'igual','id');

	if($consulta && contaConsulta($consulta)>0) {
		$retorno[id]=resultadoSQL($consulta, 0, 'id');
		$retorno[idMaquina]=resultadoSQL($consulta, 0, 'idMaquina');
		$retorno[idEmpresa]=resultadoSQL($consulta, 0, 'idEmpresa');
		$retorno[idTicket]=resultadoSQL($consulta, 0, 'idTicket');
		$retorno[titulo]=resultadoSQL($consulta, 0, 'titulo');
		$retorno[data]=resultadoSQL($consulta, 0, 'data');
	}

	return($retorno);
}

function dadosRelacionamentoTicket($idTicket) {
	global $conn;
	if(verificaIntegracaoTicketInvent()) {
	
		$sql="
			SELECT
				ticket.id,
				ticket.data,
				Maquinas.nome maquina,
				Maquinas.ip ip,
				Maquinas.idEmpresa idEmpresa,
				Empresas.nome empresa
			FROM
				ticket,
				ticket_empresa,
				Empresas,
				Maquinas
			WHERE
				ticket.id = ticket_empresa.idTicket
				AND ticket_empresa.idEmpresa = Empresas.id
				AND ticket.id = $idTicket
				AND Maquinas.id=ticket_empresa.idMaquina
		";
	} else {
		$sql="
			SELECT
				ticket.id,
				ticket.data,
				Empresas.nome empresa
			FROM
				ticket,
				ticket_empresa,
				Empresas
			WHERE
				ticket.id = ticket_empresa.idTicket
				AND ticket_empresa.idEmpresa = Empresas.id
				AND ticket.id = $idTicket
		";
	}
	
	$consulta=consultaSQL($sql, $conn);

	if($consulta && @contaConsulta($consulta)>0) {
		$retorno[idTicket]=resultadoSQL($consulta,0,'id');
		$retorno[data]=resultadoSQL($consulta,0,'data');
		$retorno[empresa]=resultadoSQL($consulta,0,'empresa');
		if(verificaIntegracaoTicketInvent()) {
			$retorno[maquina]=resultadoSQL($consulta,0,'maquina');
			$retorno[ip]=resultadoSQL($consulta,0,'ip');
			$retorno[idEmpresa]=resultadoSQL($consulta,0,'idEmpresa');
		}
	}
	
	return($retorno);
	
}


/**
 * Fun��o para relacionamento de ticket a empresa e maquina (opcional)
 *
 * @param $modulo
 * @param $sub
 * @param $acao
 * @param $matriz
 * @param $registro
 *
 * @return Tela de fun��o de relacionamento de ticket
 */
function relacionarTicket($modulo, $sub, $acao, $matriz, $registro) {
	
	global $conn, $corFundo, $corBorda, $tb, $html, $sessLogin;
	
	$data=dataSistema();
	
	# Checar permiss�o do usuario
	# Buscar informa��es sobre usuario - permiss�es
	$permissao=buscaPermissaoUsuario($sessLogin[login]);

	if(!$permissao[abrir] && !$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
	
		if(!$matriz[bntRelacionar] || !$matriz['empresa'] || !$matriz['maquina']) {
			if($matriz[bntRelacionar]) {
				$msg=_("ATTENTION: All the fields should be filled out!");
				$url="?modulo=$modulo&sub=$sub&acao=abrir&registro=$idTicket";
				aviso(_("Warning"), $msg, $url, 760);
				echo "<br>";
			}

			mostraTicket($registro);
			echo "<br>";
			
			# Form de abertura de Ticket
			formRelacionarTicket($modulo, $sub, $acao, $matriz, $registro);
		}
		else {
			# Gravar
// nash 2007-04-25 est� usando a rotina gravaRelacionamentoTicket() para gravar
//			$tmpDadosTicket=dadosTicket($registro);
//			$matriz[idTicket]=$registro;
//			$matriz[data]=$tmpDadosTicket[data];
//			$matriz[descricao]=$tmpDadosTicket[texto];
//			if( !$matriz[maquinacheck] ) {
//				$matriz[maquina]=0;
//			}
//			$matriz[id] = $registro;
//			$matriz[assunto]=$matriz[titulo];
//			$gravaTicket = dbTicket( $matriz, 'alterar_relacionar' );//'alterar'
//			$grava = dbTicketEmpresa( $matriz, 'relacionar' );
//			
//			if( $grava && $gravaTicket ) {
			if( gravaRelacionamentoTicket( $matriz, $registro ) ) {
				avisoNOURL(_("Warning"), _("Ticket Related successfully!!!"), 400);
				echo "<BR>";
				if( $matriz[agendar] ) {
					$matriz[bntAgendar]="";
					eventoAgendar($modulo, $sub, 'agendar', $matriz, $registro);
				}
				else {
					verTicket($modulo, $sub, 'ver', $matriz, $registro);
				}
			}

		}
	}
}

/**
 * Grava o relacionametno do ticket
 *
 * @since 2007-04-25
 * @param array $matriz
 * @param integer $registro
 * @return boolean
 */
function gravaRelacionamentoTicket( $matriz, $registro ){
	# Gravar
	$tmpDadosTicket = dadosTicket($registro);
	$matriz['idTicket']=$registro;
	$matriz['data']=$tmpDadosTicket['data'];
	$matriz['descricao']=$tmpDadosTicket['texto'];
	if( !$matriz['maquinacheck'] ) {
		$matriz['maquina'] = 0;
	}
	$matriz['id'] = $registro;
	$matriz['assunto']=$matriz['titulo'];
	$gravaTicket = dbTicket( $matriz, 'alterar_relacionar' );//'alterar'
	$grava = dbTicketEmpresa( $matriz, 'relacionar' );
	return( $grava && $gravaTicket );
}

/**
 * Fun��o para Form de relacinoamento de ticket com empresa e m�quina(opcional)
 *
 * @param $modulo
 * @param $sub
 * @param $acao
 * @param $matriz
 * @param $registro
 * 
 * @return Formul�rio HTML
 */

function formRelacionarTicket($modulo, $sub, $acao, $matriz, $registro) {
	global $html, $corFundo, $corBorda;
	
	# Buscar Assunto
	$consulta=buscaTicket($registro, 'id','igual','id');
	$assunto=resultadoSQL($consulta, 0, 'assunto');
	
	if(!$matriz[titulo] && !$matriz[bntRelacionar]) {
		$matriz[titulo]=$assunto;
	}
	
	novaTabela2(_("Relate Ticket:")." $assunto", 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		# Opcoes Adicionais
		menuOpcAdicional($modulo, $sub, $acao, $registro);				
		#fim das opcoes adicionais
		novaLinhaTabela($corFundo, '100%');
		$acao = ( $acao == 'abrir' ? $acao : 'relacionar' );
		$texto="			
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=acao value=$acao>
			<input type=hidden name=registro value=$registro>
			<input type=hidden name=matriz[ticket] value=$registro>
			<input type=hidden name=matriz[titulo] value='$matriz[titulo]'>";
			itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();

		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold>"._("Company:")."</b><br>
				<span class=normal10>"._("Company which the ticket will be related")."</span>";
			htmlFechaColuna();
			itemLinhaForm(selectEmpresas('empresa', $matriz), 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		
		if($matriz['empresa']) {
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold>"._("Host:")."</b><br>
							<span class=normal10>"._("Relate Ticket to a host")."</span>";
					htmlFechaColuna();
					//$texto="<input type=checkbox checked name=matriz[maquinacheck] value='S'><span class=txtaviso>"._("(Relate to this host)")."</span>";
					$texto= "<input type=hidden name=matriz[maquinacheck] value='S'>";
					$form = formSelectMaquinasEmpresa($matriz[maquina], $matriz[empresa],'maquina', 'form');
					if($form) $texto="$form $texto";
					else $texto=_("There is no host related with this company");
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			}
		getBotao('matriz[bntRelacionar]', _("Relate Ticket"));
				
	fechaTabela();		
}

/**
 * retoruna uma linha com um combobox das empresas cadastradas
 *
 * @since 2007-04-23
 * @author Nash
 * @param integer $empresa
 * @return string
 */
function formRelacionarEmpresa($ajax=false) {
	global $html, $corFundo, $corBorda;
	$matriz['empresa'] = $empresa;
	
	$isIntegratedInvent = verificaIntegracaoTicketInvent();
	
	$evento = ( $isIntegratedInvent ? ' onchange="callComboHost(this.value)" onblur="callComboHost(this.value)"' : '' );

	novaLinhaTabela('"'.$corFundo.'" id="comboEmpresaLayer" class="invisible"', '100%');
	htmlAbreColuna( '40%', 'right', $corFundo, 0, 'tabfundo1' );
	echo '<b class="bold">'._("Company:") . "</b><br />\n" .
		'<span class="normal10">' . _("Company which the ticket will be related") . "</span>\n";
	htmlFechaColuna();
	itemLinhaForm( getEmptyCombo('empresa', 'comboEmpresa', $evento), 'left', 'top', $corFundo, 0, 'tabfundo1');
	fechaLinhaTabela();

	if( $isIntegratedInvent ){
		echo formRelacionarMaquina(0);
	}
}

/**
 * retoruna uma linha com um combobox das maquinas cadastradas para empresa $empresa.
 *
 * @since 2007-04-24
 * @author Nash
 * @param integer $empresa
 * @return string
 */
function formRelacionarMaquina( $empresa, $maquina=0 ) {
	$checkbox = "<input type=\"checkbox\" checked=\"checked\" name=\"matriz[maquinacheck]\" value=\"S\">\n".
			 "<span class=\"txtaviso\">"._("(Relate to this host)")."</span>\n";
	$form = getEmptyCombo('maquina', 'comboMaquina');
	$texto = '<div id="hostField">'.$form.' '.$checkbox.'</div><div id="hostMessage" style="display: none">'.
			_("There is no host related with this company")."</div>\n";

	$ret =	novaLinhaTabela('"'.$corFundo.'" id="comboMaquinaLayer" class="invisible"', '100%', false ) .
			htmlAbreColuna( '40%', 'right', $corFundo, 0, 'tabfundo1', false ) .
			"<b class=\"bold\">" . _("Host:") . "</b><br />\n".
			"<span class=\"normal10\">" . _("Relate Ticket to a host") . "</span>".
			htmlFechaColuna( false ) .
			itemLinhaForm( $texto, 'left', 'top', $corFundo, 0, 'tabfundo1', false ) .
			fechaLinhaTabela(false);
	return $ret;
}

/**
 * Returns the username (for commons users) or company's name (when it's created by a common user) . 
 *
 * @author Nash
 * @since 2007-05-04
 * @param integer $idUsuario
 * @param integer $idTicket
 * @return string
 */
function getUserOrCompany( $idUsuario, $idTicket ){
	/*
	Steps:
	1- search the username
	2- if this username is a company user, then look for the company name
	3- return the $identification
	*/
	
	
	global $tb, $conn;

	$consulta = buscaUsuarios($idUsuario,'id','igual','login');
	$identification = resultadoSQL($consulta,0,'login');

	if( $identification == 'company_user' ){
		$sql = "SELECT ".
					"{$tb['Empresas']}.nome nome ".
				"FROM ".
					"{$tb['TicketEmpresa']} INNER JOIN {$tb['Empresas']} ".
					"ON ({$tb['TicketEmpresa']}.idEmpresa={$tb['Empresas']}.id) ".
				"WHERE ".
					"{$tb['TicketEmpresa']}.idTicket='$idTicket'";
		$consulta = consultaSQL($sql, $conn);
		if( $consulta && contaConsulta($consulta) > 0 ){
			$identification = resultadoSQL($consulta, 0, 'nome');
		}
	}
	return $identification;
}

?>
