<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 18/04/2003
# Ultima altera��o: 17/08/2006
#    Altera��o No.: 008
#
# Fun��o:
#    Painel - Fun��es para comentarios de ticket

# fun��o de busca 
function buscaComentariosTicket($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[ComentariosTicket] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[ComentariosTicket] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[ComentariosTicket] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[ComentariosTicket] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg=_("Consultation cannot be accomplished by lack of parameters");
		$url="?modulo=$modulo";
		aviso(_("Warning: An error has been ocurred"), $msg, $url, 760);
	}
	
} # fecha fun��o de busca


# Fun��o para visualizar as informa��es do servidor
function adicionarComentario($modulo, $sub, $acao, $matriz, $registro) {

	global $conn, $corFundo, $corBorda, $tb, $html, $sessLogin;
	
	# Checar permiss�o do usuario
	# Buscar informa��es sobre usuario - permiss�es
	$permissao=buscaPermissaoUsuario($sessLogin[login]);

	if(!$permissao[visualizar] && !$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
	
		# Mostar informa��es sobre Servidor
		$consulta=buscaTicket($registro, 'id','igual','id');
		
		$idTicket=resultadoSQL($consulta, 0, 'id');
		$assunto=resultadoSQL($consulta, 0, 'assunto');
		$data=resultadoSQL($consulta, 0, 'data');
		$descricao=resultadoSQL($consulta, 0, 'texto');
		$idUsuario=resultadoSQL($consulta, 0, 'idUsuario');
		$nomeUsuario=resultadoSQL(buscaUsuarios($sessLogin[login],'login','igual','login'),0,'login');
		$idPrioridade=resultadoSQL($consulta, 0, 'idPrioridade');
		$protocolo=resultadoSQL($consulta, 0, 'protocolo');
		$idCategoria=resultadoSQL($consulta, 0, 'idCategoria');
		
		# Processos do Ticket
		$processosTicket=buscaProcessosTicket($idTicket, 'idTicket','igual','data DESC LIMIT 1');
		
		if($processosTicket && contaConsulta($processosTicket)>0) {
			$statusTicket=resultadoSQL($processosTicket, 0, 'idStatus');
			$status=checaStatusTicket($statusTicket);

			if(!$matriz[descricao] && !$matriz[bntComentar]) {
				mostraTicket($idTicket);
				echo "<br>";
			}
			
			# Op��o de abertura de ticket
			if($acao=='adicionar') {
				# Form de abertura de Ticket
				
				if(!$matriz[bntComentar] || !$matriz[descricao]) {

					if($matriz[bntComentar]) {
						$msg=_("ATTENTION: All the fields should be filled out!");
						$url="?modulo=$modulo&sub=$sub&acao=abrir&registro=$idTicket";
						aviso(_("Warning"), $msg, $url, 760);
						echo "<br>";
					}
					
					# Form
					formComentarTicket($modulo, $sub, $acao, $matriz, $idTicket);

				}
				else {
					# Gravar
					$grava=dbComentariosTicket($matriz, 'incluir');
					
					if( $grava ) {
						/*
						$msg="Coment�rio postado com sucesso!";
						$url="?modulo=$modulo&sub=&acao=ver&registro=$idTicket";
						aviso("Aviso", $msg, $url, 760);
						*/
						verTicket('ticket', $sub, 'ver', $matriz, $registro);
						
						# Enviar mensagem alertando sobre novo ticket Criado
						mailTicket($idTicket, $idUsuario, 'comentario');
						
						# Enviar mensagem para autor da mensagem - verificando detalhes
						$detalhesTicket=detalhesTicket($idTicket);
						if($detalhesTicket) {
							$matriz[email]=$detalhesTicket;
							$matriz[idTicket]=$idTicket;
							$matriz[protocolo]=$protocolo;
							mailTicketProtocolo($matriz, $idUsuario, 'comentar_origem');						
						}

					}
				}
			}
			
		}
	
		//htmlFechaColuna();
		//fechaLinhaTabela();
		# fecha linha

	}
	
} #fecha visualizacao




/**
 * Exclus�o de coment�rios de tickets
 *
 * @param $modulo
 * @param $sub
 * @param $acao
 * @param $matriz
 * @param $registro
 *
 * @return Formul�rio e fun��o de exclus�o de coment�rios
 */
function excluirComentario($modulo, $sub, $acao, $matriz, $registro) {

	global $conn, $corFundo, $corBorda, $tb, $html, $sessLogin;
	
	# Checar permiss�o do usuario
	# Buscar informa��es sobre usuario - permiss�es
	$permissao=buscaPermissaoUsuario($sessLogin[login]);

	if(!$permissao[excluir] && !$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
	
		# Buscar comentario
		$consulta=buscaComentariosTicket($registro, 'id','igual','id');
		
		if($consulta && contaConsulta($consulta)>0) {
			$id=resultadoSQL($consulta, 0, 'id');
			$idTicket=resultadoSQL($consulta, 0, 'idTicket');
			$idUsuario=resultadoSQL($consulta, 0, 'idUsuario');
			$data=resultadoSQL($consulta, 0, 'data');
			$comentario=resultadoSQL($consulta, 0, 'texto');
			
			$ticket=dadosTicket($idTicket);
			$assunto=$ticket[assunto];
			$statusTicket=$ticket[status];
			$idPrioridade=$ticket[idPrioridade];
			$idCategoria=$ticket[idCategoria];
			$idUsuario=$ticket[idUsuario];
			$nomeUsuario=resultadoSQL(buscaUsuarios($idUsuario,'id','igual','id'),0,'login');
			
			# Processos do Ticket
			$processosTicket=buscaProcessosTicket($idTicket, 'idTicket','igual','data DESC LIMIT 1');
		
			if($processosTicket && contaConsulta($processosTicket)>0) {
				$statusTicket=resultadoSQL($processosTicket, 0, 'idStatus');
				$status=checaStatusTicket($statusTicket);
				
				if(!$matriz[bntExcluir]) {
					
					mostraTicket($idTicket);
					echo "<br>";
				
					# Form de exclus�o
					$matriz[id]=$id;
					$matriz[idTicket]=$idTicket;
					$matriz[comentario]=$comentario;
					$matriz[data]=$data;
					formExcluirComentario($modulo, $sub, $acao, $matriz, $registro);
				}
				else {
					# Excluir
					$matriz[id]=$id;
					$matriz[idTicket]=$idTicket;
					$matriz[data]=$data;
					dbComentariosTicket($matriz, 'excluir');
					
					# Listagem de Processos do Ticket
					verTicket($modulo, $sub, 'ver', $matriz, $idTicket);
				}
				
			}
		}
		
	}
	
}


/**
 * Altera��o de coment�rios de tickets
 *
 * @param $modulo
 * @param $sub
 * @param $acao
 * @param $matriz
 * @param $registro
 *
 * @return Formul�rio e fun��o de altera��o de coment�rios
 */
function alterarComentario($modulo, $sub, $acao, $matriz, $registro) {

	global $conn, $corFundo, $corBorda, $tb, $html, $sessLogin;
	
	# Checar permiss�o do usuario
	# Buscar informa��es sobre usuario - permiss�es
	$permissao=buscaPermissaoUsuario($sessLogin[login]);

	if(!$permissao[alterar] && !$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
	
		# Buscar comentario
		$consulta=buscaComentariosTicket($registro, 'id','igual','id');
		
		if($consulta && contaConsulta($consulta)>0) {
			$id=resultadoSQL($consulta, 0, 'id');
			$idTicket=resultadoSQL($consulta, 0, 'idTicket');
			$idUsuario=resultadoSQL($consulta, 0, 'idUsuario');
			$data=resultadoSQL($consulta, 0, 'data');
			$comentario=resultadoSQL($consulta, 0, 'texto');
			
			$ticket=dadosTicket($idTicket);
			$assunto=$ticket[assunto];
			$statusTicket=$ticket[status];
			$idPrioridade=$ticket[idPrioridade];
			$idCategoria=$ticket[idCategoria];
			$idUsuario=$ticket[idUsuario];
			$nomeUsuario=resultadoSQL(buscaUsuarios($idUsuario,'id','igual','id'),0,'login');
			
			# Processos do Ticket
			$processosTicket=buscaProcessosTicket($idTicket, 'idTicket','igual','data DESC LIMIT 1');
		
			if($processosTicket && contaConsulta($processosTicket)>0) {
				$statusTicket=resultadoSQL($processosTicket, 0, 'idStatus');
				$status=checaStatusTicket($statusTicket);

				if(!$matriz[bntAlterar]) {

					mostraTicket($idTicket);
					echo "<br>";

					# Form de exclus�o
					$matriz[id]=$id;
					$matriz[idTicket]=$idTicket;
					$matriz[comentario]=$comentario;
					$matriz[data]=$data;
					formAlterarComentario($modulo, $sub, $acao, $matriz, $registro);
				}
				else {
					$matriz[id]=$id;
					dbComentariosTicket($matriz, 'alterar');
					
					# Listagem de Processos do Ticket
					$registro=$idTicket;
					verTicket($modulo, $sub, 'ver', $matriz, $registro);
				}
				
			}
		}
		
	}
	
} 



# Fun��o para Form de comentario de ticket
function formComentarTicket($modulo, $sub, $acao, $matriz, $registro) {
	global $html, $corFundo, $corBorda;
	
	novaTabela2(_('Comment of Ticket'), 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		# Opcoes Adicionais
		menuOpcAdicional($modulo, $sub, $acao, $registro);				
		#fim das opcoes adicionais
		novaLinhaTabela($corFundo, '100%');
		$texto="
		  <form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=$acao>
			<input type=hidden name=registro value=$registro>
			<input type=hidden name=matriz[ticket] value=$registro>";
			itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold>"._("Commentary:")."</b>&nbsp;<br>
				<span class=normal10>"._("Comments on Ticket")."</span>";
			htmlFechaColuna();
			$texto="<textarea name=matriz[descricao] rows=15 cols=60></textarea>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "&nbsp;";
			htmlFechaColuna();
			$texto="<input type=submit name=matriz[bntComentar] value="._("Comment Ticket")." class=submit>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();		
}


# Fun��o para Form de altera��o de comentario
function formAlterarComentario($modulo, $sub, $acao, $matriz, $registro) {
	global $html, $corFundo, $corBorda;
	
	novaTabela2(_("Change comment of Ticket "), 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		#fim das opcoes adicionais
		novaLinhaTabela($corFundo, '100%');
		$texto="			
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=$acao>
			<input type=hidden name=registro value=$registro>
			<input type=hidden name=matriz[ticket] value=$registro>";
			itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold>"._("Commentary:")."</b>&nbsp;<br>
				<span class=normal10>"._("Comments on Ticket")."</span>";
			htmlFechaColuna();
			$texto="<textarea name=matriz[descricao] rows=15 cols=60>$matriz[comentario]</textarea>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "&nbsp;";
			htmlFechaColuna();
			$texto="<input type=submit name=matriz[bntAlterar] value="._("Change Comment")." class=submit>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();		
}



# Fun��o para Form de abertura de ticket
function formExcluirComentario($modulo, $sub, $acao, $matriz, $registro) {
	global $html, $corFundo, $corBorda;
	
	novaTabela2(_('Delete Comment'), 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		# Opcoes Adicionais
		menuOpcAdicional($modulo, '', $acao, $matriz[idTicket]);				
		#fim das opcoes adicionais
		novaLinhaTabela($corFundo, '100%');
		$texto="			
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=$acao>
			<input type=hidden name=registro value=$registro>";
			itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			itemLinhaForm('&nbsp;', 'left', 'top', $corFundo, 2, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold>"._("Commentary:")."</b>&nbsp;";
			htmlFechaColuna();
			itemLinhaForm(nl2br($matriz[comentario]), 'left', 'top', $corFundo, 0, 'tabfundo3');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold>"._("Date:")."</b>&nbsp;";
			htmlFechaColuna();
			itemLinhaForm(converteData($matriz[data],'banco','form'), 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "&nbsp;";
			htmlFechaColuna();
			$texto="<input type=submit name=matriz[bntExcluir] value="._("Delete Comment")." class=submit>";
			itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();		
}



# Fun��o para grava��o em banco de dados
function dbComentariosTicket($matriz, $tipo)
{
	global $conn, $tb, $modulo, $acao, $sessLogin;
	
	# Data do sistema 
	$data=dataSistema();
	# Busca o ID do usu�rio logado
	if( $sessLogin['login'] ){
		$idUser=buscaIDUsuario( ( $sessLogin['isCompanyUser'] ? 'company_user' : $sessLogin['login'] ), 'login', 'igual', 'login');
	}	
	else {
		$idUser = buscaIDUsuario( 'guest', 'login', 'igual', 'login' );
	}
		
	# Incluir Comentarios
	if($tipo=='incluir') {
		# por Felipe Assis - 19/05/2008 - Tratamento para evitar SQL Injection
        $descricao = addslashes($matriz['descricao']);
        $sql="INSERT INTO $tb[ComentariosTicket] VALUES (
                0,
                $matriz[ticket],
                $idUser,
                '$data[dataBanco]',
                '$descricao'
        )";

	} #fecha abertura
	
	elseif($tipo=='excluirtodos') {
		$sql="DELETE FROM $tb[ComentariosTicket] WHERE idTicket=$matriz[id]";
	}
	
	elseif($tipo=='excluirusuario') {
		$sql="DELETE FROM $tb[ComentariosTicket] WHERE idUsuario=$matriz[id]";
	}
	
	elseif($tipo=='excluir') {
		$sql="DELETE FROM $tb[ComentariosTicket] WHERE id='$matriz[id]'";
	}
	
	elseif($tipo=='alterar') {
		$sql="UPDATE $tb[ComentariosTicket] SET texto='$matriz[descricao]' WHERE id='$matriz[id]'";
	}
	
	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
	
} # fecha fun��o de grava��o em banco de dados



# Listagem de comentarios
function listarComentariosTicket($modulo, $sub, $acao, $matriz, $registro) {
	global $html, $corFundo, $corBorda, $sessLogin;
	
	$sqlOPC="";
	if( !$sessLogin['isCompanyUser'] ){
		$perfil=dadosPerfilUsuario( buscaIDUsuario($sessLogin[login],'login','igual','id') );
		if($perfil[ordemComentarios]=='D') {
			$sqlOPC="DESC";
		}
	}

	# Verificar coment�rios j� postados
	$consulta=buscaComentariosTicket($registro, 'idTicket','igual',"data $sqlOPC");
	$contaConsulta = contaConsulta($consulta);
	#nova tabela para mostrar informa��es
	novaTabela(_("Commentaries"), 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);

		if(!$contaConsulta) {
			novaLinhaTabela($corFundo, '100%');
				itemLinhaNOURL(_("There is no comments for this Ticket"), 'left', $corFundo, 2, 'txtaviso');
			fechaLinhaTabela();
		}
		else {
			$idTicket = $registro;
			
			for( $i = 0; $i < $contaConsulta; $i++ ) {
				$usuario=resultadoSQL($consulta, $i, 'idUsuario');
				$id=resultadoSQL($consulta, $i, 'id');
				//$idTicket=resultadoSQL($consulta, $i, 'idTicket');
				$data=converteData(resultadoSQL($consulta, $i, 'data'),'banco','formdata');
				$hora=converteData(resultadoSQL($consulta, $i, 'data'),'banco','formhora');
				$texto=resultadoSQL($consulta, $i, 'texto');
				
				# Informa��es do usuario
				$consultaUsuario=buscaUsuarios($usuario, 'id','igual','id');
				$loginUsuario=resultadoSQL($consultaUsuario, 0, 'login');
				$isCompanyUser = isCommentRelatedWithCompanyUser($id);
				$loginUsuario = getUsername( $usuario, $id, 'idComentario' );
				# Pegar o nome do grupo de acordo com o perfil				
				$nomeGrupo = comentarNomeGrupo( resultadoSQL( $consultaUsuario, 0, 'id' ) );
				if( $sessLogin['isCompanyUser'] ){
					$nomeGrupo = comentarNomeGrupo( resultadoSQL( $consultaUsuario, 0, 'id' ), 'sim' );
				}
				
				# Atribuir Valores
				$fundo=$i%2+1;
				$fundo2=$i%2+3;
				
				$tmpData=converteData(resultadoSQL($consulta, $i, 'data'),'banco','timestamp');
				novaLinhaTabela($corFundo, '100%');
					if( $modulo=='ticket' && !$sessLogin['isCompanyUser'] ) {
						$opcAdicional="<a href=?modulo=ticket&sub=comentario&acao=excluir&registro=$id><img title="._("Delete")." src=".$html[imagem][fechar]." border=0 align=right></a>";
						$opcAdicional.="<a href=?modulo=ticket&sub=comentario&acao=alterar&registro=$id><img title="._("Change")." src=".$html[imagem][alterar]." border=0 align=right></a>";
					}
					else $opcAdicional='';
					
					$info="$opcAdicional
					<b>"._("Posted By:")."</b>" . "&nbsp;" . ( empty( $nomeGrupo ) | $isCompanyUser ? _($loginUsuario) : $nomeGrupo ) . "<br>
					<b>"._("Date:")."</b> $data<br>
					<b>"._("Hour:")."</b> $hora</br>";
					itemLinhaTabela($info, 'left', '30%', "tabfundo$fundo");
					itemLinhaNOURL(nl2br($texto), 'left', $corFundo, 0, "tabfundo$fundo2");
				fechaLinhaTabela();
			}
		}
		
	fechaTabela();	
	# fim da tabela
}


# fun��o de busca 
function buscaUltimoComentarioTicket($idTicket)
{
	global $conn, $tb;
	
	$sql="SELECT * from $tb[ComentariosTicket] WHERE idTicket=$idTicket ORDER BY data DESC LIMIT 1";

	$consulta=consultaSQL($sql, $conn);
	
	if($consulta && contaConsulta($consulta)>0) {
		# retonar o primeiro registro, quer 
		$retorno[idTicket]=resultadoSQL($consulta, 0, 'idTicket');
		$retorno[data]=resultadoSQL($consulta, 0, 'data');
		$retorno[idUsuario]=resultadoSQL($consulta, 0, 'idUsuario');
		$retorno[login]=buscaLoginUsuario($retorno[idUsuario],'id','igual','id');
		$retorno[texto]=resultadoSQL($consulta, 0, 'texto');
	}
	
	return($retorno);
	
	
} # fecha fun��o de busca


#############################################################################################################################
###############################																			  ###################
###############################		SISTEMA DE LOGIN PARA USUARIO_EMPRESA		#############################################
###############################																			  ###################
#############################################################################################################################

# Fun��o para visualizar as informa��es do servidor
function adicionarComentarioUE($modulo, $sub, $acao, $matriz, $registro) {

	global $conn, $corFundo, $corBorda, $tb, $html, $sessLogin;
	
	# Checar permiss�o do usuario
	# Buscar informa��es sobre usuario - permiss�es
//	$permissao=buscaPermissaoUsuario($sessLogin[login]);
	if (!$sessLogin){
//	if(!$permissao[visualizar] && !$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg=_("WARNING: You don't have permission to execute this function");
		$url="?modulo=$modulo&sub=$sub";
		aviso(_("Access Denied"), $msg, $url, 760);
	}
	else {
	
		# Mostar informa��es sobre Servidor
		$consulta=buscaTicket($registro, 'id','igual','id');
		
		$idTicket=resultadoSQL($consulta, 0, 'id');
		$assunto=resultadoSQL($consulta, 0, 'assunto');
		$data=resultadoSQL($consulta, 0, 'data');
		$descricao=resultadoSQL($consulta, 0, 'texto');
		$idUsuario=resultadoSQL($consulta, 0, 'idUsuario');
		//$nomeUsuario=resultadoSQL( buscaUsuarios( $idUsuario, 'id', 'igual', 'id' ), 0, 'login' );
		$nomeUsuario= getUsername( $idUsuario, $idTicket );
//		$nomeUsuario=resultadoSQL(buscaUsuariosEmpresas($sessLogin[login],'login','igual','login'),0,'login');
		$idPrioridade=resultadoSQL($consulta, 0, 'idPrioridade');
		$protocolo=resultadoSQL($consulta, 0, 'protocolo');
		$idCategoria=resultadoSQL($consulta, 0, 'idCategoria');
		
		# Processos do Ticket
		$processosTicket=buscaProcessosTicket($idTicket, 'idTicket','igual','data DESC LIMIT 1');
		
		if($processosTicket && contaConsulta($processosTicket)>0) {
			$statusTicket=resultadoSQL($processosTicket, 0, 'idStatus');
			$status=checaStatusTicket($statusTicket);

			if(!$matriz[descricao] && !$matriz[bntComentar]) {
				mostraTicketUE($idTicket);
				echo "<br>";
			}
			
			# Op��o de abertura de ticket
			if($acao=='adicionarUE') {
				# Form de abertura de Ticket
				
				if(!$matriz[bntComentar] || !$matriz[descricao]) {

					if($matriz[bntComentar]) {
						$msg=_("ATTENTION: All the fields should be filled out!");
						$url="?modulo=$modulo&sub=$sub&acao=abrir&registro=$idTicket";
						aviso(_("Warning"), $msg, $url, 760);
						echo "<br>";
					}
					
					# Form
					formComentarTicket($modulo, $sub, $acao, $matriz, $idTicket);

				}
				else {

					# Gravar
					$grava=dbComentariosTicket($matriz, 'incluir');
					
					if( $grava ) {
						$dados['idComentario'] = getLastId();
						$dados['idEmpresaUsuario'] = $sessLogin['id'];
						dbComentarioEmpresaUsuarios( $dados, 'relacionar' );
						
						/*
						$msg="Coment�rio postado com sucesso!";
						$url="?modulo=$modulo&sub=&acao=ver&registro=$idTicket";
						aviso("Aviso", $msg, $url, 760);
						*/
						verTicketUE('ticket', $sub, 'verUE', $matriz, $registro);
						
						# Enviar mensagem alertando sobre novo ticket Criado
						mailTicket($idTicket, $idUsuario, 'comentario');
						# Enviar mensagem para autor da mensagem - verificando detalhes
						$detalhesTicket=detalhesTicket($idTicket);
						if($detalhesTicket) {
							$matriz[email]=$detalhesTicket;
							$matriz[idTicket]=$idTicket;
							$matriz[protocolo]=$protocolo;
							mailTicketProtocolo($matriz, $idUsuario, 'comentar_origem');						
						}

					}
				}
			}
			
		}
		# fecha linha
	
	}
	
} #fecha visualizacao

?>
