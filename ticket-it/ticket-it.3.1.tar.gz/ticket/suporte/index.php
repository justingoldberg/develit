<?
header('Location: ../index.php?modulo=protocolo&acao=incluir&categoria=1');
?>
