<?php
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 10/01/2005
# Ultima altera��o: 10/01/2005
#    Altera��o No.: 001
#
# Fun��o:
# Configura��es do ISP-IT

$isp[host]="localhost";
$isp[db]="isp";
$isp[user]="root";
$isp[pass]="";

?>
