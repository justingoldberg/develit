<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 11/01/2005
# Ultima altera��o: 11/01/2005
#    Altera��o No.: 001
#
# Fun��o:
#    Configura��es do Ticket-IT

$ticket[host]='localhost';
$ticket[db]='ticket';
$ticket[user]='root';
$ticket[pass]='';
?>
