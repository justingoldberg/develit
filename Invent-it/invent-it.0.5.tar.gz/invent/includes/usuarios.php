<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 12/03/2003
# Ultima altera��o: 11/01/2005
#    Altera��o No.: 011
#
# Fun��o:
#    Fun��es de autentica��o e valida��o de usuario

# Formul�rio de valida��o
function validacao($sessLogin, $modulo, $sub, $acao, $registro) {
	# Carregar vari�veis de autentica��o
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Formulario de login
	if(!$sessLogin[login] || !$sessLogin[senha] || !$modulo || $modulo=='logoff' || $modulo=='login') {
		# Formul�rio de login
		$modulo='';
		$sub='';
		$acao='';
		$registro='';
		
		# Motrar tabela de busca
		novaTabela2SH("center", '100%', 0, 2, 0, $corFundo, $corBorda, 2);
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('60%', 'center', $corFundo, 0, 'normal10');
					echo "<img src=".$html[imagem][logoPrincipal].">";
				htmlFechaColuna();
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'normal10');
					novaTabela2("[Login de Acesso]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
						# Opcoes Adicionais
						//menuOpcAdicional($modulo, $sub, $acao, $registro);				
						
						#fim das opcoes adicionais
						novaLinhaTabela($corFundo, '100%');
							$texto="<form method=post name=matriz action=index.php>
							<input type=hidden name=modulo value=$modulo>
							<input type=hidden name=sub value=$sub>
							<input type=hidden name=acao value=$acao>
							<input type=hidden name=registro value=$registro>
							<br>
							<center><b class=bold10>$configAppName - $configAppVersion</b><br>
							<br>
							<span class=txtaviso>Informe Usu�rio e Senha de Acesso</span></center><br>";
							itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
						fechaLinhaTabela();
						novaLinhaTabela($corFundo, '100%');
							htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
								echo "<b class=bold10>Usuario: </b>";
							htmlFechaColuna();
							$texto="<input type=text name=matValida[login] size=20>";
							itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
						fechaLinhaTabela();
						novaLinhaTabela($corFundo, '100%');
							htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
								echo "<b class=bold10>Senha: </b>";
							htmlFechaColuna();
							$texto="<input type=password name=matValida[senha] size=20>";
							itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
						fechaLinhaTabela();
						
						# Bot�o de confirma��o
						novaLinhaTabela($corFundo, '100%');
							htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
								echo "&nbsp;";
							htmlFechaColuna();
							$texto="<input type=submit name=matValida[bntOK] value=OK class=submit>";
							itemLinhaForm($texto, 'left', 'top', $corFundo, 2, 'tabfundo1');
						fechaLinhaTabela();
						
					fechaTabela();
				htmlFechaColuna();
			fechaLinhaTabela();
		fechaTabela();
	} #fecha formulario
	# Conferir usuario
	elseif($sessLogin[login] && $sessLogin[senha]) {
		# Conferir campos
		$usuario=strtoupper($usuario);
		$consulta=buscaUsuarios("upper(login)='$sessLogin[login]'", 'login','custom','id');
		
		if($consulta && contaConsulta($consulta)>0) {
			# Verificar usuario
			$usuario=resultadoSQL($consulta, 0, 'login');
			$id=resultadoSQL($consulta, 0, 'id');
			$senhaBanco=resultadoSQL($consulta, 0, 'senha');
			$status=resultadoSQL($consulta, 0, 'status');

			# conferir senha	
			if($senhaBanco <> crypt($sessLogin[senha], $senhaBanco)) {
				# Mensagem
				$msg="Usu�rio ou Senha inv�lidos!";
				$url="?modulo=login";
				aviso("ERRO: Login de acesso", $msg, $url, 760);
				
				$sessLogin[usuario]='';
				$sessLogin[senha]='';
			}
			else {
			
				if($modulo=='logoff') echo aeeee;
				home($modulo, $sub, $acao, $registro, $matriz);
				/*
				# Mensagem
				$msg="Login executado com sucesso!";
				$url="?modulo=";
				aviso("Login de acesso", $msg, $url, 760);
				*/

			}
		}
		else {
			# Mensagem
			$msg="Usu�rio ou Senha inv�lidos!";
			$url="?modulo=login";
			aviso("ERRO: Login de acesso", $msg, $url, 760);
			
			$sessLogin[usuario]='';
			$sessLogin[senha]='';
		}
	
	}
} #fecha funcao de valida��o



# Fun��o para checagem de formul�rio de valida��o
function usuariosValidaForm($matriz) {

	if($matriz[login]) $retorno[login]=$matriz[login];
	if($matriz[senha]) $retorno[senha]=$matriz[senha];
	
	if($retorno) return($retorno);
	
} #fecha valida��o de formul�rio de login



# Fun��o para checagem de login
function checaLogin($matriz, $modulo, $sub, $acao, $registro) {
	# Carregar vari�veis de autentica��o
	global $corFundo, $corBorda, $sessLogin;
	
	if($matriz[login] && $matriz[senha]) {
		# Conferir campos
		$usuario=strtoupper($usuario);
		$consulta=buscaUsuarios("upper(login)='$matriz[login]'", 'login','custom','id');
		
		if($consulta && contaConsulta($consulta)>0) {
			# Verificar usuario
			$usuario=resultadoSQL($consulta, 0, 'login');
			$id=resultadoSQL($consulta, 0, 'id');
			$senhaBanco=resultadoSQL($consulta, 0, 'senha');
			$status=resultadoSQL($consulta, 0, 'status');

			# conferir senha	
			if($senhaBanco <> crypt($matriz[senha], $senhaBanco)) {
				# Mensagem
				$msg="Usu�rio ou Senha inv�lidos!";
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				
				if($opcao) aviso("ERRO: Login de acesso", $msg, $url, 760);
			}
			else {
				#Login executado com sucesso
				return(1);
			}
		}
		else {
			//validacao($sessLogin, $modulo, $sub, $acao, $registro, $matriz);
			/*
			# Mensagem
			$msg="Usu�rio ou Senha inv�lidos!";
			$url="?modulo=login";
			
			if($opcao) aviso("ERRO: Login de acesso", $msg, $url, 760);			
			*/
		}
	
	}

}



# fun��o de busca 
function buscaUsuarios($texto, $campo, $tipo, $ordem)
{
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Usuarios] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[Usuarios] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg="Consulta n�o pode ser realizada por falta de par�metros";
		$url="?modulo=$modulo&sub=$sub";
		aviso("Aviso: Ocorr�ncia de erro", $msg, $url, 760);
	}
	
} # fecha fun��o de busca de usuarios






# Buscar infoma��es do grupo e retornar matriz
function buscaInfoGrupo($idGrupo) {

	if($idGrupo) {
		$consultaGrupo=buscaGrupos($idGrupo, 'id','igual','id');
	}

	if($consultaGrupo && contaConsulta($consultaGrupo)>0) {
		# Informa��es do grupo	
		$infoGrupo[admin]=resultadoSQL($consultaGrupo, 0, 'admin');
		$infoGrupo[incluir]=resultadoSQL($consultaGrupo, 0, 'incluir');
		$infoGrupo[alterar]=resultadoSQL($consultaGrupo, 0, 'alterar');
		$infoGrupo[excluir]=resultadoSQL($consultaGrupo, 0, 'excluir');
		$infoGrupo[buscar]=resultadoSQL($consultaGrupo, 0, 'buscar');
	}
	
	return($infoGrupo);
} #fecha funcao de informa��es do grupo



# Fun��o para busca de ID de usuario
function buscaIDUsuario($texto, $campo, $tipo, $ordem) {
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Usuarios] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[Usuarios] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta		
		if($consulta && contaConsulta($consulta)>0) return(resultadoSQL($consulta,0,'id'));
	}
	else {	
		# Mensagem de aviso
		$msg="Consulta n�o pode ser realizada por falta de par�metros";
		$url="?modulo=$modulo&sub=$sub";
		aviso("Aviso: Ocorr�ncia de erro", $msg, $url, 760);
	}
	
} # fecha busca por ID de usu�rio



# Fun��o para busca de ID de usuario
function buscaLoginUsuario($texto, $campo, $tipo, $ordem) {
	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Usuarios] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[Usuarios] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[Usuarios] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta		
		return(resultadoSQL($consulta,0,'login'));
	}
	else {	
		# Mensagem de aviso
		$msg="Consulta n�o pode ser realizada por falta de par�metros";
		$url="?modulo=$modulo&sub=$sub";
		aviso("Aviso: Ocorr�ncia de erro", $msg, $url, 760);
	}
	
} # fecha busca por ID de usu�rio


# Buscar infoma��es do grupo e retornar matriz
function buscaPermissaoUsuario($login) {

	# Checar informa��o sobre usuarios - localizar grupos
	
	if($login) {
		# Buscar o ID do usuario
		$idUsuario=buscaIDUsuario($login, 'login','igual','login');
		$consulta=buscaUsuariosGrupos($idUsuario, 'idUsuario','igual','idUsuario');
	}

	# Zerar permiss�es
	$permissao[admin]="";
	$permissao[incluir]="";
	$permissao[alterar]="";
	$permissao[excluir]="";
	$permissao[visualizar]="";
	$permissao[abrir]="";
	$permissao[fechar]="";
	$permissao[comentar]="";

	# Caso encontrado grupo
	if($consulta && contaConsulta($consulta)>0) {
	
		# Atualizar permiss�es
		$i=0;
		while($i < contaConsulta($consulta)) {
			# Verificar permiss�es
			$idGrupo=resultadoSQL($consulta, $i, 'idGrupo');
			
			# Buscar informa��es sobre este grupo
			$consultaGrupo=buscaGrupos($idGrupo, 'id','igual','id');
			
			# atualizar informa��es do usuario
			if(resultadoSQL($consultaGrupo, 0, 'admin')) $permissao[admin]=resultadoSQL($consultaGrupo, 0, 'admin');
			if(resultadoSQL($consultaGrupo, 0, 'incluir')) $permissao[adicionar]=resultadoSQL($consultaGrupo, 0, 'incluir');
			if(resultadoSQL($consultaGrupo, 0, 'alterar')) $permissao[alterar]=resultadoSQL($consultaGrupo, 0, 'alterar');
			if(resultadoSQL($consultaGrupo, 0, 'excluir')) $permissao[excluir]=resultadoSQL($consultaGrupo, 0, 'excluir');
			if(resultadoSQL($consultaGrupo, 0, 'visualizar')) $permissao[visualizar]=resultadoSQL($consultaGrupo, 0, 'visualizar');
			if(resultadoSQL($consultaGrupo, 0, 'abrir')) $permissao[abrir]=resultadoSQL($consultaGrupo, 0, 'abrir');
			if(resultadoSQL($consultaGrupo, 0, 'fechar')) $permissao[fechar]=resultadoSQL($consultaGrupo, 0, 'fechar');
			if(resultadoSQL($consultaGrupo, 0, 'comentar')) $permissao[comentar]=resultadoSQL($consultaGrupo, 0, 'comentar');
			
			# Incrementar contador
			$i++;
		} #fecha atualiza��o de permiss�es
	}

	return($permissao);
	
} #fecha funcao de informa��es do grupo



# Menu principal
function acesso($modulo, $sub, $acao, $registro, $matriz) {

	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	$sessLogin = $_SESSION["sessLogin"];
	
	# Buscar informa��es sobre usuario - permiss�es
	$permissao=buscaPermissaoUsuario($sessLogin[login]);

	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg="ATEN��O: Voc� n�o tem permiss�o para executar esta fun��o";
		$url="?modulo=$modulo&sub=$sub";
		aviso("Acesso Negado", $msg, $url, 760);
	}
	else {

		# Menu principal de acesso
		if(!$sub) {
			# Mostrar menu
			novaTabela2("[Acesso]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 4);
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('55%', 'left', $corFundo, 0, 'tabfundo1');
						echo "<br><img src=".$html[imagem][cadastro]." border=0 align=left>
						<b class=bold>Acesso</b><br>
						<br><span class=normal10>Utilize a se��o de Acesso para controlar
						os Usuarios e grupos, utilizadores do $configAppName.</span>";
					htmlFechaColuna();
					htmlAbreColuna('5%', 'left', $corFundo, 0, 'normal');
						echo "&nbsp;";
					htmlFechaColuna();									
					$texto=htmlMontaOpcao("<br>Usuarios", 'usuario');
					itemLinha($texto, "?modulo=$modulo&sub=usuarios", 'center', $corFundo, 0, 'normal');
					$texto=htmlMontaOpcao("<br>Grupos", 'grupo');
					itemLinha($texto, "?modulo=$modulo&sub=grupos", 'center', $corFundo, 0, 'normal');
				fechaLinhaTabela();
			fechaTabela();
		}
		
		# Modulos
		elseif($sub=='usuarios') {
			# Menu de modulos
			cadastroUsuarios($modulo, $sub, $acao, $registro, $matriz);	
		}
		
		# Par�metros
		elseif($sub=='grupos') {
			# Menu de parametros
			cadastroGrupos($modulo, $sub, $acao, $registro, $matriz);
		}
	}
}


# Menu principal de usuarios
# Fun��o para cadastro de usuarios
function cadastroUsuarios($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;

	# Buscar informa��es sobre usuario - permiss�es
	$sessLogin=$_SESSION["sessLogin"];	
	$permissao=buscaPermissaoUsuario($sessLogin[login]);

	if(!$permissao[admin]) {
		# SEM PERMISS�O DE EXECUTAR A FUN��O
		$msg="ATEN��O: Voc� n�o tem permiss�o para executar esta fun��o";
		$url="?modulo=$modulo&sub=$sub";
		aviso("Acesso Negado", $msg, $url, 760);
	}
	else {

		# Topo da tabela - Informa��es e menu principal do Cadastro
		novaTabela2("[Cadastro de Usuarios]", "center", '100%', 0, 3, 1, $corFundo, $corBorda, 4);
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('65%', 'left', $corFundo, 0, 'tabfundo1');
					echo "<br><img src=".$html[imagem][cadastro]." border=0 align=left><b class=bold>Usuarios</b>
					<br><span class=normal10>O cadastro de usu�rios prov� o controle de usuarios que ter�o
					acesso ao $configAppName.</span>";
				htmlFechaColuna();			
				$texto=htmlMontaOpcao("<br>Adicionar", 'incluir');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=adicionar", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>Procurar", 'procurar');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=procurar", 'center', $corFundo, 0, 'normal');
				$texto=htmlMontaOpcao("<br>Listar", 'listar');
				itemLinha($texto, "?modulo=$modulo&sub=$sub&acao=listar", 'center', $corFundo, 0, 'normal');
			fechaLinhaTabela();
		fechaTabela();
		
		# Mostrar Status para n�o seja informada a a��o
		if(!$acao) {
			# Mostrar Status
			echo "<br>";
			listarUsuarios($modulo, $sub, $acao, $matriz, $registro);
		}
	
		# Inclus�o
		elseif($acao=="adicionar") {
			echo "<br>";
			adicionarUsuarios($modulo, $sub, $acao, $registro, $matriz);
		}
		# Lista
		elseif($acao=="listar") {
			echo "<br>";
			listarUsuarios($modulo, $sub, $acao, $registro, $matriz);
		}
		# Procurar
		elseif($acao=="procurar") {
			echo "<br>";
			procurarUsuarios($modulo, $sub, $acao, $registro, $matriz);
		}
		# Lista
		elseif($acao=="alterar") {
			echo "<br>";
			alterarUsuarios($modulo, $sub, $acao, $registro, $matriz);
		}
		# Lista
		elseif($acao=="excluir") {
			echo "<br>";
			excluirUsuarios($modulo, $sub, $acao, $registro, $matriz);
		}
	}
}


# Fu��o para visualiza��o de status
function verStatusUsuarios()
{
	global $conn, $tb, $corFundo, $corBorda, $html;

	# Motrar tabela de busca
	novaTabela2("[Informa��es sobre Cadastro de Usuarios]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('60%', 'left', $corFundo, 0, 'tabfundo1');
			echo "<br><img src=".$html[imagem][status]." border=0 align=left><b class=bold>Status dos Usu�rios</b><br>
			<span class=normal10>Status e informa��es sobre o cadastro de usu�rios.";
			htmlFechaColuna();
			htmlAbreColuna('10', 'left', $corFundo, 0, 'normal');
			echo "&nbsp;";
			htmlFechaColuna();
			
			
			htmlAbreColuna('40%', 'left', $corFundo, 0, 'normal');
				# Mostrar status dos servi�os
				$consulta=buscaUsuarios($texto, $campo, 'todos', 'id');
				if($consulta) {
					$numConsulta=contaConsulta($consulta);
				}
				else {
					$numConsulta=0;
				}
				
				htmlAbreTabelaSH('left', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				novaLinhaTabela($corFundo, '100%');
					itemLinhaNOURL('N�mero de Registros:', 'right', $corFundo, $colunas, 'bold10');
					itemLinhaNOURL("$numConsulta usuarios cadastrados", 'left', $corFundo, $colunas, 'normal10');
				fechaLinhaTabela();
				
			
			htmlFechaColuna();
		fechaLinhaTabela();
	fechaTabela();	
} #fecha status do cadastro de usuarios



# Funcao para cadastro de usuarios
function adicionarUsuarios($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	
	if($modulo=='logoff') $modulo='';
	
	# Form de inclusao
	if(!$matriz[bntAdicionar]) {
		# Motrar tabela de busca
		novaTabela2("[Adicionar]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);				
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
			$texto="			
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=$acao>&nbsp;";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold>Login: </b><br>
					<span class=normal10>Login de acesso do usu�rio</span>";
				htmlFechaColuna();
				$texto="<input type=text name=matriz[login] size=20>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold>Senha: </b><br>
					<span class=normal10>Senha de acesso do usu�rio</span>";
				htmlFechaColuna();
				$texto="<input type=password name=matriz[senha] size=20>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold>Confirma��o de Senha: </b><br>
					<span class=normal10>Confirma��o de de Senha de acesso do usu�rio</span>";
				htmlFechaColuna();
				$texto="<input type=password name=matriz[confirma_senha] size=20>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "&nbsp;";
				htmlFechaColuna();
				$texto="<input type=submit name=matriz[bntAdicionar] value=Adicionar>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
		fechaTabela();
	} #fecha form
	elseif($matriz[bntAdicionar]) {
		# Conferir campos
		if($matriz[login] && $matriz[senha] && $matriz[confirma_senha]) {
			# conferir senha e confirma��o
			if( $matriz[senha] != $matriz[confirma_senha]){
				# Erro - campo inv�lido
				# Mensagem de aviso
				$msg="Senha informada n�o � igual a confirma��o de senha. Tente novamente";
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				aviso("Aviso: Dados incorretos", $msg, $url, 760);
			}
			# continuar - campos OK
			else {
				# Cadastrar em banco de dados
				$grava=dbUsuario($matriz, 'incluir');
				
				# Verificar inclus�o de registro
				if($grava) {
					# acusar falta de parametros
					# Mensagem de aviso
					$msg="Registro Gravado com Sucesso!";
					$url="?modulo=$modulo&sub=$sub&acao=$acao";
					aviso("Aviso", $msg, $url, 760);
				}
				
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg="Falta de par�metros necess�rios. Informe os campos obrigat�rios e tente novamente";
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso("Aviso: Ocorr�ncia de erro", $msg, $url, 760);
		}
	}
} # fecha funcao de inclusao de usuarios


# Fun��o para grava��o em banco de dados
function dbUsuario($matriz, $tipo)
{
	global $conn, $tb, $modulo, $sub, $acao;
	
	# Sql de inclus�o
	if($tipo=='incluir') {
		$tmpLogin=strtoupper($matriz[login]);
		# Verificar se servi�o existe
		$tmpBusca=buscaUsuarios("upper(login)='$tmpLogin'", $campo, 'custom', 'id');
		
		# Registro j� existe
		if($tmpBusca && contaConsulta($tmpBusca)>0) {
			# Mensagem de aviso
			$msg="Registro j� existe no banco de dados";
			avisoNOURL("Aviso: Erro ao incluir registro", $msg, 400);
		}
		else {
			# Criptograma senha
			$senhaBanco=crypt($matriz[senha]);
			$sql="INSERT INTO $tb[Usuarios] VALUES (0, '$matriz[login]', '$senhaBanco', 'A')";
		}
	} #fecha inclusao
	
	elseif($tipo=='alterar') {
		# Verificar se servi�o existe
		$tmpBusca=buscaUsuarios($matriz[id], 'id', 'igual', 'id');
				
		# Registro j� existe
		if(!$tmpBusca || contaConsulta($tmpBusca)==0) {
			# Mensagem de aviso
			$msg="Registro n�o encontrado no banco de dados";
			avisoNOURL("Aviso: Erro ao incluir registro", $msg, 400);
		}
		else {
			$senhaBanco=crypt($matriz[senha]);
			$sql="UPDATE $tb[Usuarios] SET senha='$senhaBanco' WHERE id=$matriz[id]";
		}
	}

	elseif($tipo=='excluir') {
		# Verificar se servi�o existe
		$tmpServico=buscaUsuarios($matriz[id], 'id', 'igual', 'id');
		
		# Registro j� existe
		if(!$tmpServico || contaConsulta($tmpServico)==0) {
			# Mensagem de aviso
			$msg="Registro n�o existe no banco de dados";
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso("Aviso: Erro ao alterar registro", $msg, $url, 760);
		}
		else {
			$sql="DELETE FROM $tb[Usuarios] WHERE id=$matriz[id]";
		}
	}

	
	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
	
} # fecha fun��o de grava��o em banco de dados


# Listar usuarios
function listarUsuarios($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $limite;

	# Cabe�alho		
	# Motrar tabela de busca
	novaTabela("[Listar]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
		# Sele��o de registros
		$consulta=buscaUsuarios($texto, $campo, 'todos','login');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# N�o h� registros
			itemTabelaNOURL('N�o h� registros cadastrados', 'left', $corFundo, 3, 'txtaviso');
		}
		else {
		
			# Paginador
			paginador($consulta, contaConsulta($consulta), $limite[lista][usuarios], $registro, 'normal', 3, $urlADD);
		
			# Cabe�alho
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela('Login', 'center', '40%', 'tabfundo0');
				itemLinhaTabela('Status', 'center', '20%', 'tabfundo0');
				itemLinhaTabela('Op��es', 'center', '40%', 'tabfundo0');
			fechaLinhaTabela();

			# Setar registro inicial
			if(!$registro) {
				$i=0;
			}
			elseif($registro && is_numeric($registro) ) {
				$i=$registro;
			}
			else {
				$i=0;
			}
			
			$limite=$i+$limite[lista][usuarios];
			
			while($i < contaConsulta($consulta) && $i < $limite) {
				# Mostrar registro
				$id=resultadoSQL($consulta, $i, 'id');
				$login=resultadoSQL($consulta, $i, 'login');
				$status=resultadoSQL($consulta, $i, 'status');
				
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$id>Alterar</a>",'alterar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>Excluir</a>",'excluir');
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($login, 'left', '40%', 'normal');
					itemLinhaTabela(checaStatus($status), 'center', '20%', 'normal');
					itemLinhaTabela($opcoes, 'center', '40%', 'normal');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem

	fechaTabela();

} # fecha fun��o de listagem


# Funcao para alteracao de usuarios
function alterarUsuarios($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Form de inclusao
	if(!$matriz[bntAlterar]) {
		# Buscar informa��es do usuario
		$consulta=buscaUsuarios($registro, 'id','igual','id');
		
		#verificar consulta
		if($consulta && contaConsulta($consulta)>0) {
			# receber valores
			$id=resultadoSQL($consulta, 0, 'id');
			$login=resultadoSQL($consulta, 0, 'login');
			$senha=resultadoSQL($consulta, 0, 'senha');
			$status=resultadoSQL($consulta, 0, 'status');
		
			# Motrar tabela de busca
			novaTabela2("[Alterar]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=matriz[id] value=$id>
					<input type=hidden name=acao value=$acao>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>Login: </b><br>
						<span class=normal10>Login de acesso do usu�rio</span>";
					htmlFechaColuna();					
					itemLinhaForm($login, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>Senha: </b><br>
						<span class=normal10>Senha de acesso do usu�rio</span>";
					htmlFechaColuna();
					$texto="<input type=password name=matriz[senha] size=20>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>Confirma��o de Senha: </b><br>
						<span class=normal10>Confirma��o de de Senha de acesso do usu�rio</span>";
					htmlFechaColuna();
					$texto="<input type=password name=matriz[confirma_senha] size=20>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntAlterar] value=Alterar>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		}
		# registro nao encontrado
		else {
			# Mensagem de aviso
			$msg="Registro n�o foi encontrado!";
			$url="?modulo=$modulo&sub=$sub&acao=listar";
			aviso("Aviso", $msg, $url, 760);
		}
	} #fecha form
	elseif($matriz[bntAlterar]) {
		# Conferir campos
		if($matriz[senha] && $matriz[confirma_senha]) {
			# conferir senha e confirma��o
			if( $matriz[senha] != $matriz[confirma_senha]){
				# Erro - campo inv�lido
				# Mensagem de aviso
				$msg="Senha informada n�o � igual a confirma��o de senha. Tente novamente";
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				aviso("Aviso: Dados incorretos", $msg, $url, 760);
			}
			# continuar - campos OK
			else {
				# Cadastrar em banco de dados
				$grava=dbUsuario($matriz, 'alterar');
				
				# Verificar inclus�o de registro
				if($grava) {
					# acusar falta de parametros
					# Mensagem de aviso
					$msg="Registro Gravado com Sucesso!";
					$url="?modulo=$modulo&sub=$sub&acao=listar";
					aviso("Aviso", $msg, $url, 760);
				}
				
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg="Falta de par�metros necess�rios. Informe os campos obrigat�rios e tente novamente";
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso("Aviso: Ocorr�ncia de erro", $msg, $url, 760);
		}
	}
} # fecha funcao de alteracao de usuarios


# Funcao para exclusao de usuarios
function excluirUsuarios($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Form de inclusao
	if(!$matriz[bntExcluir]) {
		# Buscar informa��es do usuario
		$consulta=buscaUsuarios($registro, 'id','igual','id');
		
		#verificar consulta
		if($consulta && contaConsulta($consulta)>0) {
			# receber valores
			$id=resultadoSQL($consulta, 0, 'id');
			$login=resultadoSQL($consulta, 0, 'login');
			$senha=resultadoSQL($consulta, 0, 'senha');
			$status=resultadoSQL($consulta, 0, 'status');
		
			# Motrar tabela de busca
			novaTabela2("[excluir]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=matriz[id] value=$id>
					<input type=hidden name=acao value=$acao>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold>Login: </b></span>";
					htmlFechaColuna();					
					itemLinhaForm($login, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntExcluir] value=Excluir>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		}
		# registro nao encontrado
		else {
			# Mensagem de aviso
			$msg="Registro n�o foi encontrado!";
			$url="?modulo=$modulo&sub=$sub&acao=listar";
			aviso("Aviso", $msg, $url, 760);
		}
	} #fecha form
	elseif($matriz[bntExcluir]) {
		# Conferir campos
		# Cadastrar em banco de dados
		$grava=dbUsuario($matriz, 'excluir');
		
		# Verificar inclus�o de registro
		if($grava) {
			# Apagar usuarios dos grupos
			$gravaUsuariosGrupos=dbUsuarioGrupo($matriz, 'excluirtodos');
			
			# acusar falta de parametros
			# Mensagem de aviso
			$msg="Registro Gravado com Sucesso!";
			$url="?modulo=$modulo&sub=$sub&acao=listar";
			aviso("Aviso", $msg, $url, 760);
		}
	}
} # fecha funcao de exclusao de usuarios


# Fun��o para procura de servi�o
function procurarUsuarios($modulo, $sub, $acao, $registro, $matriz)
{
	global $conn, $tb, $corFundo, $corBorda, $html, $limite, $textoProcurar;
	
	# Atribuir valores a vari�vel de busca
	if(!$matriz) {
		$matriz[bntProcurar]=1;
		$matriz[txtProcurar]=$textoProcurar;
	} #fim da atribuicao de variaveis
	
	# Motrar tabela de busca
	novaTabela2("[Procurar]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('30%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b>Procurar por:</b>";
			htmlFechaColuna();
			$texto="
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=procurar>
			<input type=text name=matriz[txtProcurar] size=40 value='$matriz[txtProcurar]'>
			<input type=submit name=matriz[bntProcurar] value=Procurar>";
			itemLinhaForm($texto, 'left','middle', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();
	echo "<BR>";
	
	# Caso bot�o procurar seja pressionado
	if( $matriz[bntProcurar] && $matriz[txtProcurar] ) {
		#buscar registros
		$consulta=buscaUsuarios("upper(login) like '%$matriz[txtProcurar]%'",$campo, 'custom','login');
		
		novaTabela("[Listar]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 3);
	
		if(!$consulta || contaConsulta($consulta)==0 ) {
			# N�o h� registros
			itemTabelaNOURL('N�o foram encontrados registros cadastrados', 'left', $corFundo, 3, 'txtaviso');
		}
		elseif($consulta && contaConsulta($consulta)>0 && (is_numeric($registro) || !$registro)) {	
		
			itemTabelaNOURL('Registros encontrados procurando por ('.$matriz[txtProcurar].'): '.contaConsulta($consulta).' registro(s)', 'left', $corFundo, 3, 'txtaviso');

			# Paginador
			$urlADD="&textoProcurar=".$matriz[txtProcurar];
			paginador($consulta, contaConsulta($consulta), $limite[lista][usuarios], $registro, 'normal', 3, $urlADD);

			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela('Login', 'center', '40%', 'tabfundo0');
				itemLinhaTabela('Status', 'center', '20%', 'tabfundo0');
				itemLinhaTabela('Op��es', 'center', '40%', 'tabfundo0');
			fechaLinhaTabela();

			# Setar registro inicial
			if(!$registro) {
				$i=0;
			}
			elseif($registro && is_numeric($registro) ) {
				$i=$registro;
			}
			else {
				$i=0;
			}
			
			
			$limite=$i+$limite[lista][usuarios];
			
			while($i < contaConsulta($consulta) && $i < $limite) {
				# Mostrar registro
				$id=resultadoSQL($consulta, $i, 'id');
				$login=resultadoSQL($consulta, $i, 'login');
				$status=resultadoSQL($consulta, $i, 'status');				
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=alterar&registro=$id>Alterar</a>",'alterar');
				$opcoes.="&nbsp;&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>Excluir</a>",'excluir');
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($login, 'left', '40%', 'normal');
					itemLinhaTabela(checaStatus($status),'center', '20%', 'normal');
					itemLinhaTabela($opcoes, 'center', '40%', 'normal');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem
	} # fecha bot�o procurar
} #fecha funcao de  procura de usuarios





# Fun��o para montar campo de formulario
function formListaUsuarios($idUsuario)
{
	global $conn, $tb;
	
	$consulta=buscaUsuarios($idUsuario, $campo, 'todos', 'login');
	
	$item="<select name=matriz[usuario]>\n";
	
	# Listargem
	$i=0;
	while($i < contaConsulta($consulta)) {
		# Valores dos campos
		$login=resultadoSQL($consulta, $i, 'login');
		$id=resultadoSQL($consulta, $i, 'id');
		
		# Verificar se deve selecionar o usuario na lista
		if($idUsuario==$id) $opcSelect="selected";
		else $opcSelect="";

		# Mostrar servi�o		
		$item.= "<option value=$id $opcSelect>$login\n";

		#Incrementar contador
		$i++;
	}
	
	$item.="</select>";
	
	return($item);
	
} #fecha funcao de montagem de campo de form



# Fun��o para checagem de grupo
function checaUsuario($idUsuario) {
	
	$consulta=buscaUsuarios($idUsuario, 'id','igual','id');
	
	if($consulta && contaConsulta($consulta)==1) {
		$retorno=resultadoSQL($consulta, 0, 'login');
	}
	else 	$retorno=$consulta;
	
	return($retorno);
}


?>
