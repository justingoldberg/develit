<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 18/08/2003
# Ultima altera��o: 14/04/2004
#    Altera��o No.: 004
#
# Fun��o:
# Fun��es para relat�rios




?>