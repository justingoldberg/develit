<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 15/10/2003
# Ultima altera��o: 12/01/2004
#    Altera��o No.: 006
#
# Fun��o:
#    Painel - Fun��es para controle de servi�o de radius (grupos)


# fun��o de busca de grupos
function buscaDominios($texto, $campo, $tipo, $ordem) {

	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Dominios] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[Dominios] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[Dominios] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[Dominios] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return($consulta);
	}
	else {	
		# Mensagem de aviso
		$msg="Consulta n�o pode ser realizada por falta de par�metros";
		$url="?modulo=$modulo&sub=$sub";
		aviso("Aviso: Ocorr�ncia de erro", $msg, $url, 760);
	}
	
} # fecha fun��o de busca de grupos



# fun��o de busca de grupos
function buscaIDDominio($texto, $campo, $tipo, $ordem) {

	global $conn, $tb, $corFundo, $modulo, $sub;
	
	if($tipo=='todos') {
		$sql="SELECT * FROM $tb[Dominios] ORDER BY $ordem";
	}
	elseif($tipo=='contem') {
		$sql="SELECT * from $tb[Dominios] WHERE $campo LIKE '%$texto%' ORDER BY $ordem";
	}
	elseif($tipo=='igual') {
		$sql="SELECT * from $tb[Dominios] WHERE $campo='$texto' ORDER BY $ordem";
	}
	elseif($tipo=='custom') {
		$sql="SELECT * from $tb[Dominios] WHERE $texto ORDER BY $ordem";
	}
	
	# Verifica consulta
	if($sql){
		$consulta=consultaSQL($sql, $conn);
		# Retornvar consulta
		return(resultadoSQL($consulta,0,'id'));
	}
	else {	
		# Mensagem de aviso
		$msg="Consulta n�o pode ser realizada por falta de par�metros";
		$url="?modulo=$modulo&sub=$sub";
		aviso("Aviso: Ocorr�ncia de erro", $msg, $url, 760);
	}
	
} # fecha fun��o de busca de grupos




# fun��o de busca de grupos
function buscaIDNovoDominio() {

	global $conn, $tb, $corFundo, $modulo, $sub;
	
	$sql="SELECT MAX(id)+1 id FROM $tb[Dominios]";
	
	$consulta=consultaSQL($sql, $conn);
	
	if($consulta && contaConsulta($consulta)>0) $id=resultadoSQL($consulta, 0, 'id');
	else $id=1;
	
	if(!is_numeric($id)) $id=1;
	
	return($id);
	
} # fecha fun��o de busca de grupos


# Funcao para cadastro de usuarios
function adicionarDominios($modulo, $sub, $acao, $registro, $matriz) {

	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Form de inclusao
	if(!$matriz[bntAdicionar] || !$matriz[nome] || !$matriz[descricao]) {
		# Motrar tabela de busca
		novaTabela2("[Adicionar]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
			# Opcoes Adicionais
			menuOpcAdicional($modulo, $sub, $acao, $registro);				
			#fim das opcoes adicionais
			novaLinhaTabela($corFundo, '100%');
			$texto="			
				<form method=post name=matriz action=index.php>
				<input type=hidden name=modulo value=$modulo>
				<input type=hidden name=sub value=$sub>
				<input type=hidden name=acao value=$acao>
				<input type=hidden name=registro>
				&nbsp;";
				itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold10>Dom�nio: </b><br>
					<span class=normal10>Nome do dom�nio</span>";
				htmlFechaColuna();
				$texto="<input type=text name=matriz[nome] size=60>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold10>Descri��o: </b><br>
					<span class=normal10>Identifica��o detalhada do dom�nio</span>";
				htmlFechaColuna();
				$texto="<textarea name=matriz[descricao] rows=3 cols=60></textarea>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold10>Status: </b><br>
					<span class=normal10>Status do dom�nio</span>";
				htmlFechaColuna();
				itemLinhaForm(formSelectStatusDominios('A','status','form'), 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
						novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "<b class=bold10>Dom�nio Padr�o: </b><br>
					<span class=normal10>Considerar dom�nio como padr�o</span>";
				htmlFechaColuna();
				itemLinhaForm(formSelectSimNao('N','padrao','form'), 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
			novaLinhaTabela($corFundo, '100%');
				htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
					echo "&nbsp;";
				htmlFechaColuna();
				$texto="<input type=submit name=matriz[bntAdicionar] value=Adicionar class=submit>";
				itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
			fechaLinhaTabela();
		fechaTabela();
	} #fecha form
	elseif($matriz[bntAdicionar]) {
		# Conferir campos
		if($matriz[nome] && $matriz[descricao]) {
			# Cadastrar em banco de dados
			$grava=dbDominio($matriz, 'incluir');
			
			# Verificar inclus�o de registro
			if($grava) {
				# acusar falta de parametros
				# Mensagem de aviso
				$msg="Registro Gravado com Sucesso!";
				$url="?modulo=$modulo&sub=$sub&acao=$acao";
				avisoNOURL("Aviso", $msg, 400);
				
				echo "<br>";
				listarDominios($modulo, $sub, 'listar', $registro, $matriz);
			}
		}
		
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg="Falta de par�metros necess�rios. Informe os campos obrigat�rios e tente novamente";
			avisoNOURL("Aviso: Ocorr�ncia de erro", $msg, $url, 400);
		}
	}
} # fecha funcao de inclusao de grupos




# Funcao para exclusao de usuarios
function excluirDominios($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html;
	
	# Form de inclusao
	if(!$matriz[bntExcluir]) {
	
		# Buscar informa��es sobre registro
		$consulta=buscaDominios($registro, 'id','igual','id');
		
		if($consulta && contaConsulta($consulta)>0) {
		
			# receber valores
			$id=resultadoSQL($consulta, 0, 'id');
			$nome=resultadoSQL($consulta, 0, 'nome');
			$descricao=resultadoSQL($consulta, 0, 'descricao');
			$dtCadastro=resultadoSQL($consulta, 0, 'dtCadastro');
			$dtAtivacao=resultadoSQL($consulta, 0, 'dtAtivacao');
			$dtCongelamento=resultadoSQL($consulta, 0, 'dtCongelamento');
			$dtBloqueio=resultadoSQL($consulta, 0, 'dtBloqueio');
			$status=resultadoSQL($consulta, 0, 'status');
			
			# Motrar tabela de busca
			novaTabela2("[Excluir]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
				# Opcoes Adicionais
				menuOpcAdicional($modulo, $sub, $acao, $registro);				
				#fim das opcoes adicionais
				novaLinhaTabela($corFundo, '100%');
				$texto="			
					<form method=post name=matriz action=index.php>
					<input type=hidden name=modulo value=$modulo>
					<input type=hidden name=sub value=$sub>
					<input type=hidden name=id value=$id>
					<input type=hidden name=matriz[id] value=$id>
					<input type=hidden name=acao value=$acao>&nbsp;";
					itemLinhaNOURL($texto, 'left', $corFundo, 2, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>Dom�nio: </b>";
					htmlFechaColuna();
					itemLinhaForm($nome, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>Descri��o: </b>";
					htmlFechaColuna();
					itemLinhaForm($descricao, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>Status: </b>";
					htmlFechaColuna();
					itemLinhaForm(formSelectStatusDominios('A','status','check'), 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
							novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "<b class=bold10>Dom�nio Padr�o: </b>";
					htmlFechaColuna();
					itemLinhaForm(formSelectSimNao('N','padrao','check'), 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
				novaLinhaTabela($corFundo, '100%');
					htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
						echo "&nbsp;";
					htmlFechaColuna();
					$texto="<input type=submit name=matriz[bntExcluir] value=Excluir class=submit>";
					itemLinhaForm($texto, 'left', 'top', $corFundo, 0, 'tabfundo1');
				fechaLinhaTabela();
			fechaTabela();
		}
		# registro nao encontrado
		else {
			# Mensagem de aviso
			$msg="Registro n�o foi encontrado!";
			$url="?modulo=$modulo&sub=$sub&acao=listar";
			aviso("Aviso", $msg, $url, 760);
		}
	} #fecha form
	elseif($matriz[bntExcluir]) {
		# Cadastrar em banco de dados
		$grava=dbDominio($matriz, 'excluir');
		
		# Verificar exclusao de registro
		if($grava) {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg="Registro Exclu�do!";
			avisoNOURL("Aviso", $msg, 400);
			
			echo "<br>";
			listarDominios($modulo, $sub, 'listar', 0, $matriz);
		}
		# falta de parametros
		else {
			# acusar falta de parametros
			# Mensagem de aviso
			$msg="Erro ao gravar registro!";
			avisoNOURL("Aviso: Ocorr�ncia de erro", $msg, 760);

			echo "<br>";
			listarDominios($modulo, $sub, 'listar', 0, $matriz);
		}
	}
} # fecha funcao de exclus�o de grupos



# Fun��o para grava��o em banco de dados
function dbDominio($matriz, $tipo)
{
	global $conn, $tb, $modulo, $sub, $acao;
	
	$data=dataSistema();
	
	# Sql de inclus�o
	if($tipo=='incluir') {
		$tmpNome=strtoupper($matriz[nome]);
		# Verificar se servi�o existe
		$tmpBusca=buscaDominios("upper(nome)='$tmpNome'", $campo, 'custom', 'id');
		
		# Registro j� existe
		if($tmpBusca && contaConsulta($tmpBusca)>0) {
			# Mensagem de aviso
			$msg="Registro j� existe no banco de dados";
			avisoNOURL("Aviso: Erro ao incluir registro", $msg, 400);
			
			echo "<br>";
			listarDominios($modulo, $sub, 'listar', $registro, $matriz);

		}
		
		else {
			
			$matriz[dtCadastro]=$data[dataBanco];
			
			if($matriz[status]=='A') $matriz[dtAtivacao]=$matriz[dtCadastro];
		
			$sql="INSERT INTO $tb[Dominios] VALUES (
				'$matriz[id]', 
				'$matriz[nome]', 
				'$matriz[descricao]', 
				'$matriz[dtCadastro]', 
				'$matriz[dtAtivacao]', 
				'$matriz[dtBloqueio]',
				'$matriz[dtCongelamento]',
				'$matriz[status]',
				'$matriz[padrao]'
			)";
		}
	} #fecha inclusao
	
	# Excluir
	elseif($tipo=='excluir') {
		# Verificar se servi�o existe
		$tmpServico=buscaDominios($matriz[id], 'id', 'igual', 'id');
		
		# Registro j� existe
		if(!$tmpServico || contaConsulta($tmpServico)==0) {
			# Mensagem de aviso
			$msg="Registro n�o existe no banco de dados";
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso("Aviso: Erro ao alterar registro", $msg, $url, 760);
		}
		else {
			$sql="DELETE FROM $tb[Dominios] WHERE id=$matriz[id]";
		}
	}
	
	# Alterar
	elseif($tipo=='alterar') {
		# Verificar se servi�o existe
		$tmpServico=buscaDominios($matriz[id], 'id', 'igual', 'id');
		
		# Registro j� existe
		if(!$tmpServico || contaConsulta($tmpServico)==0) {
			# Mensagem de aviso
			$msg="Registro n�o existe no banco de dados";
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso("Aviso: Erro ao alterar registro", $msg, $url, 760);
		}
		else {
			$sql="
				UPDATE 
					$tb[Dominios] 
				SET 
					dtCadastro='$matriz[dtCadastro]',
					dtAtivacao='$matriz[dtAtivacao]'
				WHERE 
					id=$matriz[id]";
		}
	}

	# Inativar
	elseif($tipo=='inativar') {
		# Verificar se servi�o existe
		$tmpServico=buscaDominios($matriz[id], 'id', 'igual', 'id');
		
		# Registro j� existe
		if(!$tmpServico || contaConsulta($tmpServico)==0) {
			# Mensagem de aviso
			$msg="Registro n�o existe no banco de dados";
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso("Aviso: Erro ao alterar registro", $msg, $url, 760);
		}
		else {
			$sql="UPDATE $tb[Dominios] SET status='I' WHERE id=$matriz[id]";
		}
	}
	
	# Ativar
	elseif($tipo=='ativar') {
		# Verificar se servi�o existe
		$tmpServico=buscaDominios($matriz[id], 'id', 'igual', 'id');
		
		# Registro j� existe
		if(!$tmpServico || contaConsulta($tmpServico)==0) {
			# Mensagem de aviso
			$msg="Registro n�o existe no banco de dados";
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso("Aviso: Erro ao alterar registro", $msg, $url, 760);
		}
		else {
			$sql="UPDATE $tb[Dominios] SET status='A' WHERE id=$matriz[id]";
		}
	}
	
	
	# cancelar
	elseif($tipo=='cancelar') {
		# Verificar se servi�o existe
		$tmpServico=buscaDominios($matriz[id], 'id', 'igual', 'id');
		
		# Registro j� existe
		if(!$tmpServico || contaConsulta($tmpServico)==0) {
			# Mensagem de aviso
			$msg="Registro n�o existe no banco de dados";
			$url="?modulo=$modulo&sub=$sub&acao=$acao";
			aviso("Aviso: Erro ao alterar registro", $msg, $url, 760);
		}
		else {
			$sql="UPDATE $tb[Dominios] SET status='C' WHERE id=$matriz[id]";
		}
	}
	
	
	if($sql) { 
		$retorno=consultaSQL($sql, $conn);
		return($retorno); 
	}
	
} # fecha fun��o de grava��o em banco de dados


# Listar grupos
function listarDominios($modulo, $sub, $acao, $registro, $matriz)
{
	global $configAppName, $configAppVersion, $corFundo, $corBorda, $html, $limite;

	# Cabe�alho
	# Motrar tabela de busca
	novaTabela("[Listar]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 6);
	
		$opcoes=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=adicionar>Adicionar</a>",'incluir');
		$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=listar>Listar</a>",'listar');
		itemTabelaNOURL($opcoes, 'right', $corFundo, 6, 'tabfundo1');
	
		# Sele��o de registros
		$consulta=buscaDominios($texto, $campo, 'todos','padrao DESC, nome ASC');
		
		if(!$consulta || contaConsulta($consulta)==0) {
			# N�o h� registros
			itemTabelaNOURL('N�o h� registros cadastrados', 'left', $corFundo, 6, 'txtaviso');
		}
		else {
		
			# Paginador
			paginador($consulta, contaConsulta($consulta), $limite[lista][dominios], $registro, 'normal', 5, $urlADD);
		
			# Cabe�alho
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela('Nome', 'center', '30%', 'tabfundo0');
				itemLinhaTabela('Data de Cadastro', 'center', '20%', 'tabfundo0');
				itemLinhaTabela('Status', 'center', '15%', 'tabfundo0');
				itemLinhaTabela('Padr�o', 'center', '10%', 'tabfundo0');
				itemLinhaTabela('Op��es', 'center', '25%', 'tabfundo0');
			fechaLinhaTabela();
			
			# Setar registro inicial
			if(!$registro) {
				$i=0;
			}
			elseif($registro && is_numeric($registro) ) {
				$i=$registro;
			}
			else {
				$i=0;
			}
			
			$limite=$i+$limite[lista][dominios];
			
			while($i < contaConsulta($consulta) && $i < $limite) {
				# Mostrar registro
				$id=resultadoSQL($consulta, $i, 'id');
				$nome=resultadoSQL($consulta, $i, 'nome');				
				$dtCadastro=resultadoSQL($consulta, $i, 'dtCadastro');
				$status=resultadoSQL($consulta, $i, 'status');
				$padrao=resultadoSQL($consulta, $i, 'padrao');
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=ver&registro=$id>Detalhes</a>",'ver');
				$opcoes.="&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=parametros&registro=$id>Par�metros</a>",'config');
				$opcoes.="&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>Excluir</a>",'excluir');
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($nome, 'left', '30%', 'normal10');
					itemLinhaTabela(converteData($dtCadastro,'banco','form'), 'center', '20%', 'normal10');
					itemLinhaTabela(formSelectStatusDominios($status,'','check'), 'center', '15%', 'normal10');
					itemLinhaTabela(formSelectSimNao($padrao,'','check'), 'center', '10%', 'normal10');
					itemLinhaTabela($opcoes, 'center', '25%', 'normal8');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem

	fechaTabela();

} # fecha fun��o de listagem



# Fun��o para procura 
function procurarDominios($modulo, $sub, $acao, $registro, $matriz)
{
	global $conn, $tb, $corFundo, $corBorda, $html, $limite, $textoProcurar;
	
	# Atribuir valores a vari�vel de busca
	if(!$matriz) {
		$matriz[bntProcurar]=1;
		$matriz[txtProcurar]=$textoProcurar;
	} #fim da atribuicao de variaveis
	
	# Motrar tabela de busca
	novaTabela2("[Procurar]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 2);
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('30%', 'right', $corFundo, 0, 'tabfundo1');
			echo "<b>Procurar por:</b>";
			htmlFechaColuna();
			$texto="
			<form method=post name=matriz action=index.php>
			<input type=hidden name=modulo value=$modulo>
			<input type=hidden name=sub value=$sub>
			<input type=hidden name=acao value=procurar>
			<input type=text name=matriz[txtProcurar] size=40 value='$matriz[txtProcurar]'>
			<input type=submit name=matriz[bntProcurar] value=Procurar class=submit>";
			itemLinhaForm($texto, 'left','middle', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	fechaTabela();

	# Caso bot�o procurar seja pressionado
	if( $matriz[bntProcurar] && $matriz[txtProcurar] ) {
		#buscar registros
		$consulta=buscaDominios("upper(nome) like '%$matriz[txtProcurar]%' OR upper(descricao) like '%$matriz[txtProcurar]%'",$campo, 'custom','padrao DESC, nome ASC');

		echo "<br>";

		novaTabela("[Listar]", "center", '100%', 0, 2, 1, $corFundo, $corBorda, 10);
	
		if(!$consulta || contaConsulta($consulta)==0 ) {
			# N�o h� registros
			itemTabelaNOURL('N�o foram encontrados registros cadastrados', 'left', $corFundo, 10, 'txtaviso');
		}
		elseif($consulta && contaConsulta($consulta)>0 && (is_integer($registro) || !$registro)) {	
		
			itemTabelaNOURL('Registros encontrados procurando por ('.$matriz[txtProcurar].'): '.contaConsulta($consulta).' registro(s)', 'left', $corFundo, 10, 'txtaviso');

			# Paginador
			$urlADD="&textoProcurar=".$matriz[txtProcurar];
			# Paginador
			paginador($consulta, contaConsulta($consulta), $limite[lista][dominios], $registro, 'normal', 5, $urlADD);
		
			# Cabe�alho
			novaLinhaTabela($corFundo, '100%');
				itemLinhaTabela('Nome', 'center', '30%', 'tabfundo0');
				itemLinhaTabela('Data de Cadastro', 'center', '20%', 'tabfundo0');
				itemLinhaTabela('Status', 'center', '15%', 'tabfundo0');
				itemLinhaTabela('Padr�o', 'center', '10%', 'tabfundo0');
				itemLinhaTabela('Op��es', 'center', '25%', 'tabfundo0');
			fechaLinhaTabela();
			
			# Setar registro inicial
			if(!$registro) {
				$i=0;
			}
			elseif($registro && is_numeric($registro) ) {
				$i=$registro;
			}
			else {
				$i=0;
			}
			
			$limite=$i+$limite[lista][dominios];
			
			while($i < contaConsulta($consulta) && $i < $limite) {
				# Mostrar registro
				$id=resultadoSQL($consulta, $i, 'id');
				$nome=resultadoSQL($consulta, $i, 'nome');				
				$dtCadastro=resultadoSQL($consulta, $i, 'dtCadastro');
				$status=resultadoSQL($consulta, $i, 'status');
				$padrao=resultadoSQL($consulta, $i, 'padrao');
				
				$opcoes="";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=ver&registro=$id>Detalhes</a>",'ver');
				$opcoes.="&nbsp;";
				$opcoes.=htmlMontaOpcao("<a href=?modulo=$modulo&sub=$sub&acao=excluir&registro=$id>Excluir</a>",'excluir');
				
				novaLinhaTabela($corFundo, '100%');
					itemLinhaTabela($nome, 'left', '30%', 'normal10');
					itemLinhaTabela(converteData($dtCadastro,'banco','form'), 'center', '20%', 'normal10');
					itemLinhaTabela(formSelectStatusDominios($status,'','check'), 'center', '15%', 'normal10');
					itemLinhaTabela(formSelectSimNao($padrao,'','check'), 'center', '10%', 'normal10');
					itemLinhaTabela($opcoes, 'center', '25%', 'normal8');
				fechaLinhaTabela();
				
				# Incrementar contador
				$i++;
			} #fecha laco de montagem de tabela
		} #fecha listagem
	} # fecha bot�o procurar
} #fecha funcao de  procura


# Fun��o para visualizar as informa��es do servidor
function verDominios($modulo, $sub, $acao, $registro, $matriz) {

	global $conn, $corFundo, $corBorda, $tb, $html;
	
	# Mostar informa��es sobre Servidor
	$consulta=buscaDominios($registro, 'id','igual','id');
	
	#nova tabela para mostrar informa��es
	novaTabela2('Informa��es sobre Dom�nio', 'center', '100%', 0, 2, 1, $corFundo, $corBorda, 2);
	
	if($consulta && contaConsulta($consulta)>0) {
		# receber valores
		$id=resultadoSQL($consulta, 0, 'id');
		$nome=resultadoSQL($consulta, 0, 'nome');
		$descricao=resultadoSQL($consulta, 0, 'descricao');
		$dtCadastro=resultadoSQL($consulta, 0, 'dtCadastro');
		$dtAtivacao=resultadoSQL($consulta, 0, 'dtAtivacao');
		$dtCongelamento=resultadoSQL($consulta, 0, 'dtCongelamento');
		$dtBloqueio=resultadoSQL($consulta, 0, 'dtBloqueio');
		$status=resultadoSQL($consulta, 0, 'status');
		$padrao=resultadoSQL($consulta, 0, 'padrao');
		
		# Opcoes Adicionais
		//menuOpcAdicional($modulo, $sub, $acao, $registro);
		
		#fim das opcoes adicionais
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold10>Dom�nio: </b>";
			htmlFechaColuna();
			itemLinhaForm($nome, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold10>Descri��o: </b>";
			htmlFechaColuna();
			itemLinhaForm($descricao, 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold10>Status: </b>";
			htmlFechaColuna();
			itemLinhaForm(formSelectStatusDominios('A','status','check'), 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
		novaLinhaTabela($corFundo, '100%');
			htmlAbreColuna('40%', 'right', $corFundo, 0, 'tabfundo1');
				echo "<b class=bold10>Dom�nio Padr�o: </b>";
			htmlFechaColuna();
			itemLinhaForm(formSelectSimNao($padrao,'padrao','check'), 'left', 'top', $corFundo, 0, 'tabfundo1');
		fechaLinhaTabela();
	}
	else {
		itemTabelaNOURL('Registro n�o encontrado!', 'left', $corFundo, 2, 'txtaviso');		
	}
	
	fechaTabela();	
	# fim da tabela
	
} #fecha visualizacao




# Fun��o para campo select de dominios
function formSelectDominioEmail($idDominio, $campo, $tipo) {

	global $conn, $tb;
	
	if($tipo=='form') {
		$sql="
			SELECT
				$tb[Dominios].id, 
				$tb[Dominios].nome 
			FROM
				$tb[Dominios]
			WHERE
				$tb[Dominios].padrao='S' 
				OR $tb[Dominios].id=$idDominio
			ORDER BY
				$tb[Dominios].padrao DESC
			";
		
		$consulta=consultaSQL($sql, $conn);
		
		$item="<select name=matriz[$campo]>\n";
		
		# Listargem
		$i=0;
		while($i < contaConsulta($consulta)) {
			# Valores dos campos
			$nome=resultadoSQL($consulta, $i, 'nome');
			$id=resultadoSQL($consulta, $i, 'id');
			
			# Verificar se deve selecionar o usuario na lista
			if($idDominio==$id) $opcSelect="selected";
			else $opcSelect="";
	
			# Mostrar servi�o		
			$item.= "<option value=$id $opcSelect>$nome\n";
	
			#Incrementar contador
			$i++;
		}
	
		$item.="</select>";
	}
	elseif($tipo=='check') {
		$sql="
			SELECT
				$tb[Dominios].id, 
				$tb[Dominios].nome 
			FROM
				$tb[Dominios]
			WHERE
				$tb[Dominios].id=$idDominio
			ORDER BY
				$tb[Dominios].padrao DESC
			";
		
		
		$consulta=consultaSQL($sql, $conn);
		
		if($consulta && contaConsulta($consulta)>0) {
			$item=resultadoSQL($consulta, 0, 'nome');
		}
		else $item="Dom�nio inv�lido!";
	}
	
	return($item);
}


# Fun��o para buscar Dados do dominio
function dadosDominio($idDominio) {

	$consulta=buscaDominios($idDominio,'id','igual','id');
	
	if($consulta && contaConsulta($consulta)>0) {
		$retorno[id]=resultadoSQL($consulta, 0, 'id');
		$retorno[nome]=resultadoSQL($consulta, 0, 'nome');
		$retorno[descricao]=resultadoSQL($consulta, 0, 'descricao');
		$retorno[dtCadastro]=resultadoSQL($consulta, 0, 'dtCadastro');
		$retorno[dtAtivacao]=resultadoSQL($consulta, 0, 'dtAtivacao');
		$retorno[dtBloqueio]=resultadoSQL($consulta, 0, 'dtBloqueio');
		$retorno[dtCongelamento]=resultadoSQL($consulta, 0, 'dtCongelamento');
		$retorno[status]=resultadoSQL($consulta, 0, 'status');
		$retorno[padrao]=resultadoSQL($consulta, 0, 'padrao');
		
		
		if($retorno[padrao] != 'S') {
			# Procurar idPessoasTipos do Dominio
			$dadosDominio=buscaDadosDominioServico($idDominio);
			
			$retorno[idPessoasTipos]=$dadosDominio[idPessoasTipos];
			$retorno[idServicosPlanos]=$dadosDominio[idServicosPlanos];
		}
	}

	return($retorno);
}
/**
 *      Seleciona todos os dom�nios de determinado cliente e retorna o
 * idDominio, idServicosPlanos, status e nome do dominio, concatenados
 * em um array, separados por ":" em cada �ndice.
 *
 * @author Jo�o Petrelli
 * @since 18-02-2009
 * 
 * @param int $idPessoaTipo
 * @return array
 */
function selecionaDominioCliente($idPessoaTipo) {
	global $conn;
	
	$sql = "SELECT 
				DominiosServicosPlanos.idDominio, 
				DominiosServicosPlanos.idServicosPlanos,
				Dominios.status,
				Dominios.nome
			FROM 
				PlanosPessoas, 
				ServicosPlanos, 
				DominiosServicosPlanos,
				Dominios 
			WHERE 
				PlanosPessoas.idPessoaTipo = '".$idPessoaTipo."'
				AND ServicosPlanos.idPlano = PlanosPessoas.id 
				AND DominiosServicosPlanos.idServicosPlanos = ServicosPlanos.id
				AND Dominios.id = DominiosServicosPlanos.idDominio";
	
	$consulta = consultaSQL($sql, $conn);

	for ($i = 0; $i < contaConsulta($consulta); $i++) {
		$retorno[$i] = resultadoSQL($consulta, $i, 'idDominio').":".resultadoSQL($consulta, $i, 'idServicosPlanos').":".resultadoSQL($consulta, $i, 'status').":".resultadoSQL($consulta, $i, 'nome');
	}
	
	return $retorno;
}

function preparaArrayDominio($dominios = array()) {
	$i = 0;
	if ($dominios) {
		foreach ($dominios as $dominio) {
			$explode = explode(":",$dominio);
			$retorno[$i]['idDominio'] = $explode[0];
			$retorno[$i]['idServicosPlanos'] = $explode[1];
			$retorno[$i]['status'] = $explode[2];
			$retorno[$i]['nome'] = $explode[3];
			$i++;
		}
	}
	return $retorno;
}
?>
