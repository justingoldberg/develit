<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 03/10/2003
# Ultima altera��o: 11/03/2004
#    Altera��o No.: 002
#
# Fun��o:
#    Configura��es de arquivos

# Arquivo Remessa
$arquivo[tmpDir]="tmp/remessa/";

# Arquivos tempor�rios HTML
$arquivo[tmpHTML]="tmp/html/";

# Arquivos tempor�rios PDF
$arquivo[tmpPDF]="tmp/pdf/";

# Arquivos tempor�rios NOTAS FISCAIS
$arquivo[tmpNota] = "tmp/nota/";

# Arquivos tempor�rios CSV
$arquivo[tmpCSV]="tmp/csv/";
?>
