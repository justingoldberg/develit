<?

global $TRIBUTOS;

$TRIBUTOS['tipos']   = array('simples', 'real');
$TRIBUTOS['valores'] = array('SIMPLES', 'Lucro Real');

?>
