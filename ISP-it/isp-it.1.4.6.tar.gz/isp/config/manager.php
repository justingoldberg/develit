<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 10/12/2003
# Ultima altera��o: 07/01/2004
#    Altera��o No.: 002
#
# Fun��o:
#    Configura��es do Manager
# 

# Configura��es MySQL
/*$manager[host]='host';
$manager[user]='user';
$manager[passwd]='senha';
$manager[db]='bd_manager';

# Tabelas Utilizadas
$manager[queue]='manager_queue';

# Senha padr�o
$manager[senha_padrao]="XFkwus9**l.";
$manager[quota_padrao]="30000000" 	# 30Mb
*/

?>
