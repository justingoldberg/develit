<?php
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 27/02/2003
# Ultima altera��o: 20/10/2003
#    Altera��o No.: 005
#
# Fun��o:
#    Configura��es utilizadas pela aplica��o

# Configura��es para Conex�o com banco de dados
/*$radius[host]="host";
$radius[user]="user";
$radius[passwd]="senha";
$radius[db]="bd_radius";*/

?>
