<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 03/08/2004
# Ultima altera��o: 03/08/2004
#    Altera��o No.: 003
#
# Fun��o:
#    Configura��es do Vpopmail
# 

include('config.php');
include('db.php');
include('html.php');
include('cobranca.php');
include('pessoas.php');
include('arquivo.php');
//include('radius.php');
//include('manager.php');
include('ocorrencias.php');
include('pdf.php');
include('custom.php');
//include('vpopmail.php');
include('ticket.php');
include('tributos.php');
?>
