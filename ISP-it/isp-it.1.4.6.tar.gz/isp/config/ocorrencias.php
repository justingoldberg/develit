<?php
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 23/12/2003
# Ultima altera��o: 23/12/2003
#    Altera��o No.: 001
#
# Fun��o:
#    Configura��es utilizadas pela aplica��o - ocorrencias

$ocorrencias[tipo]="ticket"; // ticket = Ticket-IT, isp = ISP-IT



?>
