<?
################################################################################
# Criado por: Felipe dos Santos Assis - felipeassis@devel-it.com.br
# Data de cria��o: 29/10/2007
# Ultima altera��o: 29/10/2007
# Altera��o No.: 000
#
# Fun��o:
#    Configura��es utilizadas pela aplica��o

# Configura��es para Conex�o com banco de dados do Ticket-IT

$ticket['db'] = "ticket";

?>
