<?
################################################################################
#       Criado por: Jos� Roberto Kerne - joseroberto@kerne.org
#  Data de cria��o: 03/08/2004
# Ultima altera��o: 03/08/2004
#    Altera��o No.: 003
#
# Fun��o:
#    Configura��es do Vpopmail
# 

# Configura��es MySQL
/*$vpopmail[host]='host';
$vpopmail[user]='user';
$vpopmail[passwd]='senha';
$vpopmail[db]='bd_vpopmail';*/

?>
