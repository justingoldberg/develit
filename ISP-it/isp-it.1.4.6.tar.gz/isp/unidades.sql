INSERT INTO Unidades VALUES (1,'UN','Unidade', 'A', 'N');
INSERT INTO Unidades VALUES (2,'MB','Mega Bytes', 'A', 'N');
INSERT INTO Unidades VALUES (3,'Kbps','KBits por segundo', 'A', 'N');
INSERT INTO Unidades VALUES (4,'Mbps','MegaBits por segundo', 'A', 'N');
INSERT INTO Unidades VALUES (5,'R$','Reais', 'A', 'N');
INSERT INTO Unidades VALUES (6,'horas','Horas', 'A', 'N');

