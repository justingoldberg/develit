-- Consultas SQL para confirgurar o funcionamento da integração entre ISP e WT
-- por Felipe Assis - 18/08/2008
INSERT INTO Parametros (descricao, tipo, idUnidade, parametro) VALUES ('Bases de IVR', 'nr', 1, 'qtde');
INSERT INTO Modulos (descricao, modulo) VALUES('IVR - Internet via Radio', 'ivr');