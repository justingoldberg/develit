ALTER TABLE Pessoas ADD COLUMN `instrucaoBoleto` varchar(255) DEFAULT NULL;
