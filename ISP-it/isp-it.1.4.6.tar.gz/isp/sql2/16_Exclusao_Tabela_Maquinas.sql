-- SQL de exclusão da tabela máquinas
DROP TABLE Maquinas;
