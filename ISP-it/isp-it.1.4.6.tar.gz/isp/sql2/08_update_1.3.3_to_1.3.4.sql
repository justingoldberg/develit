ALTER TABLE Pop ADD COLUMN `tipoTributo` varchar(100) NOT NULL default 'simples' AFTER `nome`;

